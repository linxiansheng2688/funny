<?php
include('sava/inc.php');
//session_start();
$_SESSION['verifycode'];
include('templets/'.$yycms_a_mb.'/gbook.php');
?>