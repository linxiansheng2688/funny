<?
include('sava/inc.php');
include('sava/zby.php');
$seach='https://www.360kan.com/dianying/index.html';
$rurl=gett($seach);
$szz1='#<a class="" href="https://www.360kan.com/m/(.*?)" >[\s\S]+?<span class="b-topslidernew-img js-slide-img" style="background-image:url\((.*?)\);"></span>#';
preg_match_all($szz1,$rurl,$sarr1);
preg_match_all($szz2,$rurl,$sarr2);
$one=$sarr1[1];//链接
$two=$sarr1[2];//图片
include('templets/'.$yycms_a_mb.'/index.php');
?>