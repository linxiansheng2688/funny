<?php
include('sava/inc.php');
include 'data/bangdan.php';
include('templets/'.$yycms_a_mb.'/searchqw.php');
?>