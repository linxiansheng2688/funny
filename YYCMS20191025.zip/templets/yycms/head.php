<meta name="renderer" content="webkit|ie-comp|ie-stand">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />					
<link rel="stylesheet" href="/templets/<?php echo $yycms_a_mb;?>/css/mytheme-font.css?v=2.3" type="text/css" />
<link rel="stylesheet" href="/templets/<?php echo $yycms_a_mb;?>/css/mytheme-ui.css?v=2.3" type="text/css" />
<link rel="stylesheet" href="/templets/<?php echo $yycms_a_mb;?>/css/mytheme-site.css?v=2.5" type="text/css" />
<link rel="stylesheet" href="/templets/<?php echo $yycms_a_mb;?>/css/mytheme-color.css?v=2.3" type="text/css" name="default" />
<link rel="stylesheet" href="/templets/<?php echo $yycms_a_mb;?>/css/mytheme-color.css?v=2.3" type="text/css" name="skin" disabled/>
<link rel="stylesheet" href="/templets/<?php echo $yycms_a_mb;?>/css/mytheme-color1.css?v=2.3" type="text/css" name="skin" disabled/>
<link rel="stylesheet" href="/templets/<?php echo $yycms_a_mb;?>/css/mytheme-color2.css?v=2.3" type="text/css" name="skin" disabled/>
<link rel="stylesheet" href="/templets/<?php echo $yycms_a_mb;?>/css/mytheme-color3.css?v=2.3" type="text/css" name="skin" disabled/>
<link rel="stylesheet" href="/templets/<?php echo $yycms_a_mb;?>/css/hlstyle.css">
<script src="/templets/<?php echo $yycms_a_mb;?>/js/iconfont.js"></script>
<script type="text/javascript" src="/templets/<?php echo $yycms_a_mb;?>/js/jquery.min.js?v=3.3.1"></script>
<script type="text/javascript" src="/templets/<?php echo $yycms_a_mb;?>/js/layer.js?v3.1.1"></script>
<script type="text/javascript" src="/templets/<?php echo $yycms_a_mb;?>/js/yycms.js"></script>
<script type="text/javascript" src="/templets/<?php echo $yycms_a_mb;?>/js/mytheme-site.js?v=1.0.0"></script>
<script type="text/javascript" src="/templets/<?php echo $yycms_a_mb;?>/js/mytheme-ui.js?v=1.0.0"></script>
<script type="text/javascript" src="/templets/<?php echo $yycms_a_mb;?>/js/mytheme-cms.js?v=1.1.0"></script>
<style type="text/css">[class*=col-],.myui-panel_hd,.myui-content__list li{ padding: 10px}.btn{ border-radius: 5px;}.myui-vodlist__thumb{ border-radius:5px; padding-top:150%; background: url(<?php echo $yycms_a_jzt;?>) no-repeat;box-shadow: 4px 3px 8px 0px rgba(0, 0, 0, 0.32);}.myui-vodlist__thumb.square{ padding-top: 100%; background: url(https://mytheme-cdn.oss-cn-hangzhou.aliyuncs.com/v/load_f.png) no-repeat;}.myui-vodlist__thumb.wide{ padding-top: 60%; background: url(https://mytheme-cdn.oss-cn-hangzhou.aliyuncs.com/v/load_w.png) no-repeat;}.myui-vodlist__thumb.actor{ padding-top: 140%;}.flickity-prev-next-button.previous{ left: 10px;}.flickity-prev-next-button.next{ right: 10px;}.myui-sidebar{ padding: 0 0 0 20px;}.myui-panel{ padding: 10px; margin-bottom: 20px; border-radius: 5px;}.myui-layout{ margin: -10px -10px 20px;}.myui-panel-mb{ margin-bottom: 20px;}.myui-panel-box{ padding: 10px;}.myui-panel-box.active{ margin: -10px;}.myui-player__item .fixed{ width: 500px;}.myui-vodlist__text li a{ padding: 10px 15px 10px 0;}.myui-vodlist__media li { padding: 10px 0 10px;}.myui-screen__list{ padding: 10px 10px 0;}.myui-screen__list li{ margin-bottom: 10px; margin-right: 10px;}.myui-page{ padding: 0 10px;}.myui-extra{ right: 20px; bottom: 30px;}@media (min-width: 1200px){.container{ max-width: 1920px;}.container{ padding-left: 120px;  padding-right: 120px;}.container.min{ width: 1200px; padding: 0;}}@media (max-width: 1400px){.myui-layout{ margin: 0;}}@media (max-width: 767px){body,body.active{ padding-bottom: 50px;}[class*=col-],.myui-content__list li{ padding: 5px}.flickity-prev-next-button.previous{ left: 5px;}.flickity-prev-next-button.next{ right: 5px;}.myui-panel{ padding: 0; border-radius: 0;}.myui-vodlist__text li a{ padding: 10px 15px 10px 0;}.myui-vodlist__media li { padding: 5px 0 5px;}.myui-screen__list{ padding: 10px 5px 0;}.myui-screen__list li{ margin-bottom: 5px; margin-right: 5px;}.myui-extra{ right: 20px; bottom: 80px;}.myui-page{ padding: 0 5px;}}
.iconf {
    overflow: hidden;
    width: 1em;
    height: 1em;
    vertical-align: -.15em;
    font-size: 42px;
    fill: currentColor;
}
.iconf {
    margin-right: 8px;
    vertical-align: middle;
}
.myui-player__item .tips {
    position: relative;
    height: 40px;
    line-height: 40px;
    overflow: hidden;
    padding: 0 20px;
    color: #fff;
}
.xianlucss{border: 1px solid #FF9900;background-color:#FF9900;color: white;}
.stui-pannel-box {
    padding: 10px;
}
.stui-index__screen li:first-child {
    border-left: 0;
    padding-left: 0;
}
.stui-index__screen li {
    position: relative;
    float: left;
    width: 25%;
    padding-left: 20px;
    border-left: 1px solid #333;
    text-align: center;
}
.stui-index__screen dt, .stui-index__screen li a:hover {
    color: #ff6600;
}

</style>
<style type="text/css">.myui-user__head .btn-default{padding:15px}.myui-user__head .fa{font-size:16px;vertical-align:-1px}.myui-user__name{border-radius:5px;margin-bottom:20px;position:relative;padding:50px 30px;background-image:linear-gradient(135deg,#f761a1 10%,#8c1bab 100%)}.myui-user__name dt{float:left}.myui-user__name dd{margin-left:70px;padding-top:5px}.myui-user__name .logout{position:absolute;top:0;right:15px;margin-top:20px}.myui-user__form p{margin:0;padding:15px 0}.myui-user__form .xiang{display:inline-block;width:120px;padding-right:15px;text-align:right;color:#999}.myui-user__form input.form-control{display:inline-block;width:200px;margin-right:10px}.myui-login__form{width:350px;padding:30px;margin: 80px auto; box-shadow:0 2px 5px rgba(0,0,0,.1)}.myui-login__form li{margin:20px 0}@media (max-width:767px){.myui-user__head .btn-default{padding:15px 5px}.myui-user__name{padding:20px}.myui-user__name h3{margin:3px 0 5px;font-size:15px}.myui-user__head li a,.myui-vodlist__text li a{font-size:14px}.stui_login__form,.stui_login__form.active{width:100%;margin:0;padding:0}.myui-user__form p{padding:10px;font-size:14px}.myui-user__form .xiang{display:none}.myui-user__form .xiang.active{display:inline-block;width:auto;text-align:left}.myui-user__form input.form-control{width:100%;height:40px}.myui-user__form p .btn{width:120px}.myui-user__form .btn_unbind{display:inline-block;margin-top:5px}}</style>
