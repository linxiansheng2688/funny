<?
include('sava/inc.php');
include('templets/'.$yycms_a_mb.'/dongman.php');
?>