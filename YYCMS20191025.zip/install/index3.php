<?php 
 unlink(dirname(__DIR__) . '/sava/1.txt')   
    ?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>YYCMS安装向导 - 安装成功</title>
	<link href="css/install2.css" type="text/css" rel="stylesheet" />
	<script type="text/javascript" src="js/jquery.min.js"></script>
	<script type="text/javascript" src="js/common.js"></script>
	<style>.input-note{color: #999; font-size: 12px; padding-top: 2px; line-height: 12px; }</style>
</head>
<body>
<div class="wrap">
  <div class="header">
YYCMS安装成功
</div> 
  <div  style="width:0;height:0;overflow:hidden;"> <img src="./images/pop_loading.gif"> </div>
</div>
<div class="mainBody">
	<div class="note">
		<div class="complete"><strong>现在您可以：</strong><br />
			<a href="/">访问网站首页</a><span>或</span><a href="/admin/">登录后台</a><p class="input-note">为安全起见请手动修改后台文件夹名字/防止被入侵</p></div>
			
	</div>
	
</div>
</body>
</html>
