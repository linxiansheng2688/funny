/*
Navicat MySQL Data Transfer

Source Server         : 123
Source Server Version : 50553
Source Host           : localhost:3306
Source Database       : yycms

Target Server Type    : MYSQL
Target Server Version : 50553
File Encoding         : 65001

Date: 2019-10-17 22:57:37
*/

SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Table structure for `yycms_gg`
-- ----------------------------
DROP TABLE IF EXISTS `yycms_gg`;
CREATE TABLE `yycms_gg` (
  `gg_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `gg_pingtai` varchar(12) DEFAULT NULL,
  `gg_gg1` text,
  `gg_gg2` text,
  `gg_gg3` text,
  `gg_gg4` text,
  `gg_gg5` text,
  `gg_gg6` text,
  `gg_gg7` text,
  `gg_gg8` text,
  `gg_gg9` text,
  `gg_gg10` text,
  `gg_gg11` text,
  PRIMARY KEY (`gg_id`)
) ENGINE=MyISAM AUTO_INCREMENT=38 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of yycms_gg
-- ----------------------------
INSERT INTO `yycms_gg` VALUES ('1', '1', '', '', '', '', '', '', '', '', '', '', '');

-- ----------------------------
-- Table structure for `yycms_hy`
-- ----------------------------
DROP TABLE IF EXISTS `yycms_hy`;
CREATE TABLE `yycms_hy` (
  `ug_id` smallint(6) NOT NULL AUTO_INCREMENT,
  `ug_name` varchar(32) NOT NULL DEFAULT '',
  `ug_type` varchar(255) NOT NULL DEFAULT '',
  `ug_popedom` varchar(32) NOT NULL DEFAULT '',
  `ug_upgrade` smallint(6) NOT NULL DEFAULT '0',
  `ug_popvalue` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ug_id`),
  KEY `ug_upgrade` (`ug_upgrade`),
  KEY `ug_popvalue` (`ug_popvalue`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of yycms_hy
-- ----------------------------
INSERT INTO `yycms_hy` VALUES ('1', '普通会员', '', '', '0', '1');
INSERT INTO `yycms_hy` VALUES ('2', '超级会员', '', '', '500', '0');

-- ----------------------------
-- Table structure for `yycms_hytc`
-- ----------------------------
DROP TABLE IF EXISTS `yycms_hytc`;
CREATE TABLE `yycms_hytc` (
  `tc_id` smallint(6) NOT NULL AUTO_INCREMENT,
  `tc_name` varchar(32) NOT NULL DEFAULT '',
  `tc_jf` varchar(255) NOT NULL DEFAULT '',
  `tc_na` varchar(32) NOT NULL DEFAULT '',
  `tc_type` varchar(10) NOT NULL,
  PRIMARY KEY (`tc_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of yycms_hytc
-- ----------------------------
INSERT INTO `yycms_hytc` VALUES ('1', 'VIP月卡会员', '10', '包月', '30');
INSERT INTO `yycms_hytc` VALUES ('2', 'VIP季卡会员', '50', '包季', '180');
INSERT INTO `yycms_hytc` VALUES ('3', 'VIP年卡会员', '100', '包年', '365');

-- ----------------------------
-- Table structure for `yycms_km`
-- ----------------------------
DROP TABLE IF EXISTS `yycms_km`;
CREATE TABLE `yycms_km` (
  `km_id` int(11) NOT NULL AUTO_INCREMENT,
  `km_name` text,
  `km_tc` varchar(255) DEFAULT NULL,
  `km_zt` varchar(5) DEFAULT NULL,
  `km_syz` varchar(255) DEFAULT NULL,
  `km_time` datetime DEFAULT NULL,
  `km_bs` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`km_id`)
) ENGINE=MyISAM AUTO_INCREMENT=281 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of yycms_km
-- ----------------------------

-- ----------------------------
-- Table structure for `yycms_kmadd`
-- ----------------------------
DROP TABLE IF EXISTS `yycms_kmadd`;
CREATE TABLE `yycms_kmadd` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `sl` varchar(255) DEFAULT NULL,
  `tc` varchar(255) DEFAULT NULL,
  `bs` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of yycms_kmadd
-- ----------------------------

-- ----------------------------
-- Table structure for `yycms_ly`
-- ----------------------------
DROP TABLE IF EXISTS `yycms_ly`;
CREATE TABLE `yycms_ly` (
  `ly_id` int(11) NOT NULL AUTO_INCREMENT,
  `ly_name` varchar(10) NOT NULL,
  `ly_nr` text NOT NULL,
  `ly_time` datetime NOT NULL,
  PRIMARY KEY (`ly_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1006 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of yycms_ly
-- ----------------------------
INSERT INTO `yycms_ly` VALUES ('3', '豆豆1', '豆豆', '2019-09-28 20:01:14');
INSERT INTO `yycms_ly` VALUES ('4', '豆豆2', '豆豆', '2019-09-28 20:01:17');
INSERT INTO `yycms_ly` VALUES ('999', '游客', '你在啊', '2019-10-08 10:55:57');
INSERT INTO `yycms_ly` VALUES ('1000', '游客', '你在干嘛', '2019-10-08 10:56:31');
INSERT INTO `yycms_ly` VALUES ('1001', '游客', '哈哈你在干嘛啊', '2019-10-08 10:58:06');
INSERT INTO `yycms_ly` VALUES ('1002', '游客', '你在干嘛啊', '2019-10-08 11:00:31');
INSERT INTO `yycms_ly` VALUES ('1003', '游客', '你在啊', '2019-10-08 11:01:28');
INSERT INTO `yycms_ly` VALUES ('1004', '游客', '的大幅度', '2019-10-08 11:20:08');
INSERT INTO `yycms_ly` VALUES ('1005', '游客', 'yycms到此一游', '2019-10-08 11:51:08');

-- ----------------------------
-- Table structure for `yycms_pintai`
-- ----------------------------
DROP TABLE IF EXISTS `yycms_pintai`;
CREATE TABLE `yycms_pintai` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `a_bt` varchar(50) DEFAULT NULL,
  `a_name` varchar(80) DEFAULT NULL,
  `a_url` varchar(80) DEFAULT NULL,
  `a_keywords` varchar(80) DEFAULT NULL,
  `a_description` varchar(250) DEFAULT NULL,
  `a_bfqgg` varchar(5) DEFAULT NULL,
  `a_jzt` varchar(250) DEFAULT NULL,
  `a_hckg` smallint(6) DEFAULT NULL,
  `a_dbdh` varchar(5) DEFAULT NULL,
  `a_dst` varchar(250) DEFAULT NULL,
  `a_dylb` varchar(5) DEFAULT NULL,
  `a_hcsj` varchar(10) DEFAULT NULL,
  `a_logo` varchar(250) DEFAULT NULL,
  `a_fhkg` smallint(6) DEFAULT NULL,
  `a_mrjx` varchar(50) DEFAULT NULL,
  `a_jxjk` text,
  `a_zyjk` text,
  `a_ggkg` varchar(2) DEFAULT NULL,
  `a_gg` text,
  `a_qqsp` text,
  `a_tj` text,
  `a_bq` text,
  `a_mb` varchar(10) DEFAULT NULL,
  `a_uare` varchar(10) DEFAULT NULL,
  `a_pass` varchar(10) DEFAULT NULL,
  `gg_gg1` text,
  `gg_gg2` text,
  `gg_gg3` text,
  `gg_gg4` text,
  `gg_gg5` text,
  `gg_gg6` text,
  `gg_gg7` text,
  `gg_gg8` text,
  `gg_gg9` text,
  `gg_gg10` text,
  `gg_gg11` text,
  `zf_kg` varchar(5) DEFAULT NULL,
  `zf_user` varchar(10) DEFAULT NULL,
  `zf_pass` varchar(150) DEFAULT NULL,
  `zf_pay` text,
  `a_user_user` varchar(20) DEFAULT NULL,
  `a_user_pass` varchar(20) DEFAULT NULL,
  `a_sfkg` varchar(10) DEFAULT NULL,
  `a_wximg` varchar(255) DEFAULT NULL,
  `s_bftitle` text,
  `s_bfkeywords` text,
  `s_bfdescription` text,
  `a_kg1` varchar(5) DEFAULT NULL,
  `a_kg2` varchar(5) DEFAULT NULL,
  `a_kg3` varchar(5) DEFAULT NULL,
  `a_kg4` varchar(5) DEFAULT NULL,
  `a_kg5` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=42 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of yycms_pintai
-- ----------------------------
INSERT INTO `yycms_pintai` VALUES ('1', '雨雨cms影视-全网免费在线观看-在线播放付费-神马影院', '雨雨cms影视', '127.0.0.1', '雨雨cms影视在线观看', '雨雨cms影视全网免费看', '1', '/uploadfile/load.png', '1', '1', '/uploadfile/image/20191011/20191011175729_62281.png', '1', '5', '/uploadfile/image/20190928/20190928230208_12287.png', '0', 'http://jx.saonantv.com/jiexi/jx/?url=', '线路一$http://www.ddqtv.com/ck/jx.php?url=', 'http://zy.bajieziyuan.com/inc//feifei3bjm3u8/index.php\r\nhttp://cj.okzy.tv/inc/feifei3/\r\nhttp://www.zdziyuan.com/inc/s_feifei3.4/', '2', '2', 'X战警：黑凤凰,银河补习班,哪吒之魔童降世,亿万第二季,护宝风云,小白菜奇案,星火云雾街,战狼,', '<script type=\"text/javascript\">var cnzz_protocol = ((\"https:\" == document.location.protocol) ? \"https://\" : \"http://\");document.write(unescape(\"%3Cspan id=\'cnzz_stat_icon_1277817436\'%3E%3C/span%3E%3Cscript src=\'\" + cnzz_protocol + \"s96.cnzz.com/z_stat.php%3Fid%3D1277817436%26online%3D1%26show%3Dline\' type=\'text/javascript\'%3E%3C/script%3E\"));</script>', '责任声明：本网站为非赢利性站点，本网站所有内容均来源于互联网相关站点自动搜索采集信息，版权归原创者所有，相关链接已经注明来源。本站只提供web页面服务,并不提供影片资源存储,也不参与录制、上传若本站收录的节目无意侵犯了贵司版权，www.ddqtv.com不承担任何由于内容的合法性及健康性所引起的争议和法律责任。 如有侵权请联系站长，站长会第一时间删除。 邮箱：798701067#qq.com<br >\r\nCopyright ©  yycms影视 ', 'yycms', 'admin', 'admin12', null, null, '', '', '', '', '', '', '', '', '', null, null, null, null, 'admin', 'admin', '0', '/uploadfile/image/20191014/20191014124116_75640.png', '{$timu}-在线观看-{$lx}-{$yycms_a_name}', '{$timu},{$timu}在线观看,{$timu}免费在线播放,{$timu}完整版', '{$timu}在线观看,{$jian}', '1', '0', '0', '0', '0');

-- ----------------------------
-- Table structure for `yycms_sc`
-- ----------------------------
DROP TABLE IF EXISTS `yycms_sc`;
CREATE TABLE `yycms_sc` (
  `sc_id` int(11) NOT NULL AUTO_INCREMENT,
  `sc_user` varchar(10) DEFAULT NULL,
  `sc_name` varchar(10) NOT NULL,
  `sc_url` text NOT NULL,
  `sc_time` datetime NOT NULL,
  PRIMARY KEY (`sc_id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of yycms_sc
-- ----------------------------
INSERT INTO `yycms_sc` VALUES ('1', '798701067', '送我上青云', '/vod/m/gqLnaBH5RXn6TB.html', '2019-10-12 02:49:53');
INSERT INTO `yycms_sc` VALUES ('2', '798701067', '送我上青云', '/vod/m/gqLnaBH5RXn6TB.html', '2019-10-12 02:55:17');
INSERT INTO `yycms_sc` VALUES ('3', '798701067', '送我上青云', '/vod/m/gqLnaBH5RXn6TB.html', '2019-10-12 02:55:20');
INSERT INTO `yycms_sc` VALUES ('4', '798701067', '送我上青云', '/vod/m/gqLnaBH5RXn6TB.html', '2019-10-12 02:55:38');
INSERT INTO `yycms_sc` VALUES ('5', '798701067', '送我上青云', '/vod/m/gqLnaBH5RXn6TB.html', '2019-10-12 02:56:07');
INSERT INTO `yycms_sc` VALUES ('6', '798701067', '送我上青云', '/vod/m/gqLnaBH5RXn6TB.html', '2019-10-12 02:56:51');
INSERT INTO `yycms_sc` VALUES ('7', '798701067', '送我上青云', '/vod/m/gqLnaBH5RXn6TB.html', '2019-10-12 02:57:51');
INSERT INTO `yycms_sc` VALUES ('8', '798701067', '送我上青云', '/vod/m/gqLnaBH5RXn6TB.html', '2019-10-12 02:57:56');
INSERT INTO `yycms_sc` VALUES ('9', '798701067', '送我上青云', '/vod/m/gqLnaBH5RXn6TB.html', '2019-10-12 02:58:10');
INSERT INTO `yycms_sc` VALUES ('10', '798701067', '送我上青云', '/vod/m/gqLnaBH5RXn6TB.html', '2019-10-12 02:58:17');
INSERT INTO `yycms_sc` VALUES ('16', '798701067', '超级兵王之战狼归来', '/qxplay/69.html', '2019-10-12 07:30:54');

-- ----------------------------
-- Table structure for `yycms_shoufei`
-- ----------------------------
DROP TABLE IF EXISTS `yycms_shoufei`;
CREATE TABLE `yycms_shoufei` (
  `sf_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `sf_pingtai` int(10) DEFAULT NULL,
  `sf_kg` varchar(11) NOT NULL DEFAULT '',
  `sf_cs` varchar(11) NOT NULL DEFAULT '',
  `sf_bl` varchar(11) DEFAULT '',
  `sf_zc` varchar(11) DEFAULT '',
  `sf_gk` varchar(11) DEFAULT '',
  `sf_km` text NOT NULL,
  `zf_kg` varchar(10) DEFAULT NULL,
  `zf_user` varchar(10) DEFAULT NULL,
  `zf_pass` varchar(255) DEFAULT NULL,
  `zf_pay` text,
  PRIMARY KEY (`sf_id`),
  KEY `d_letter` (`sf_zc`),
  KEY `d_name` (`sf_kg`),
  KEY `d_enname` (`sf_bl`)
) ENGINE=MyISAM AUTO_INCREMENT=38 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of yycms_shoufei
-- ----------------------------
INSERT INTO `yycms_shoufei` VALUES ('1', '1', '0', '6', '500', '6', '1', '', '1', '2507', 'BAhV7SvsBtQqc78Taa7q9Ww7S8ZBA997', '2');

-- ----------------------------
-- Table structure for `yycms_user`
-- ----------------------------
DROP TABLE IF EXISTS `yycms_user`;
CREATE TABLE `yycms_user` (
  `b_id` int(11) NOT NULL AUTO_INCREMENT,
  `b_pingtai` int(11) DEFAULT NULL,
  `b_user` varchar(30) DEFAULT NULL,
  `b_pass` varchar(50) DEFAULT NULL,
  `b_email` varchar(20) DEFAULT NULL,
  `b_ip` varchar(50) DEFAULT NULL,
  `b_jf` varchar(10) DEFAULT NULL,
  `b_hy` varchar(6) DEFAULT NULL,
  `b_zt` varchar(6) DEFAULT NULL,
  `b_cs` varchar(6) DEFAULT NULL,
  `b_tg` varchar(6) DEFAULT NULL,
  `b_start` datetime DEFAULT NULL,
  `b_end` datetime DEFAULT NULL,
  `b_type` datetime DEFAULT NULL,
  PRIMARY KEY (`b_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1036 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of yycms_user
-- ----------------------------
INSERT INTO `yycms_user` VALUES ('1023', '1', '798701067', 'e10adc3949ba59abbe56e057f20f883e', null, null, '10', '2', '0', '0', '0', '2019-10-03 01:42:06', '0000-00-00 00:00:00', '2020-07-13 05:29:50');
INSERT INTO `yycms_user` VALUES ('1034', '1', 'yycmscs', 'aec0627369c2690bd5e43e60d6635d9e', null, null, '10', '1', null, null, '0', '2019-10-16 07:24:00', null, '2019-10-17 07:23:53');

-- ----------------------------
-- Table structure for `yycms_user_pay`
-- ----------------------------
DROP TABLE IF EXISTS `yycms_user_pay`;
CREATE TABLE `yycms_user_pay` (
  `p_id` int(11) NOT NULL AUTO_INCREMENT,
  `p_pingtai` varchar(10) DEFAULT NULL,
  `p_dd` varchar(255) NOT NULL DEFAULT '0',
  `p_user` varchar(255) NOT NULL DEFAULT '0',
  `p_jf` varchar(255) NOT NULL DEFAULT '0',
  `p_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `p_lx` varchar(255) NOT NULL DEFAULT '0',
  `p_zt` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`p_id`),
  KEY `p_order` (`p_dd`),
  KEY `p_uid` (`p_user`),
  KEY `p_status` (`p_zt`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of yycms_user_pay
-- ----------------------------
INSERT INTO `yycms_user_pay` VALUES ('1', '1', '123456', '798701067', '100', '2019-10-11 21:09:29', '0', '1');

-- ----------------------------
-- Table structure for `yycms_vod`
-- ----------------------------
DROP TABLE IF EXISTS `yycms_vod`;
CREATE TABLE `yycms_vod` (
  `b_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `b_name` varchar(255) NOT NULL DEFAULT '',
  `b_tp` varchar(255) NOT NULL DEFAULT '',
  `b_zy` varchar(255) DEFAULT '',
  `b_jf` varchar(11) DEFAULT '',
  `b_hy` varchar(11) DEFAULT '',
  `b_fl` varchar(255) DEFAULT '',
  `b_tj` varchar(255) DEFAULT '',
  `b_pass` varchar(0) DEFAULT NULL,
  `b_url` text,
  `b_jj` text,
  `b_time` datetime DEFAULT NULL,
  PRIMARY KEY (`b_id`),
  KEY `d_letter` (`b_jf`),
  KEY `d_name` (`b_name`),
  KEY `d_enname` (`b_zy`)
) ENGINE=MyISAM AUTO_INCREMENT=83 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of yycms_vod
-- ----------------------------
INSERT INTO `yycms_vod` VALUES ('66', '哪吒之魔童降世', 'https://tu.tianzuida.com/pic/upload/vod/2019-07-26/201907261564124474.jpg', '吕艳婷,囧森瑟夫,瀚墨,陈浩,绿绮,张珈铭,杨卫', '0', '0', '8', '0', '', 'HD1280高清国语中字版$http://wuji.zhulong-zuida.com/20191010/10591_98f58691/index.m3u8', '天地灵气孕育出一颗能量巨大的混元珠，元始天尊将混元珠提炼成灵珠和魔丸，灵珠投胎为人，助周伐纣时可堪大用；而魔丸则会诞出魔王，为祸人间。元始天尊启动了天劫咒语，3年后天雷将会降临，摧毁魔丸。太乙受命将灵珠托生于陈塘关李靖家的儿子哪吒身上。然而阴差阳错，灵珠和魔丸竟然被掉包。本应是灵珠英雄的哪吒却成了混世大魔王。调皮捣蛋顽劣不堪的哪吒却徒有一颗做英雄的心。然而面对众人对魔丸的误解和即将来临的天雷的降临，哪吒是否命中注定会立地成魔？他将何去何从？', '0000-00-00 00:00:00');
INSERT INTO `yycms_vod` VALUES ('67', '战狼特攻队', 'http://pic.bjssmd.net/img/p1246206015.jpg', '主演: A.J. Drave, Steven Bauer ', '0', '0', '3', '0', '', 'HD$http://v3.bjssmd.net/20190902/VTFmZIAq/index.m3u8', 'None', '0000-00-00 00:00:00');
INSERT INTO `yycms_vod` VALUES ('68', '战狼传说', 'http://pic.bjssmd.net/img/p2256886816.jpg', '主演:甄子丹/黄子华/李若彤/林国斌', '0', '0', '1', '0', '', 'HD$http://v2.bjssmd.net/20190328/sVMt7UKG/index.m3u8', '                    \r\n                        \r\n                                　　青年阿Ben（梁汉文 饰）通过网络试图寻找最著名的杀手战狼，终于得到战狼搭档威叔（黄子华 饰）的引见，在熟睡的战狼面前，威叔向阿Ben讲述他们年轻时的故事——战乱年代，阿威生活的小村中闯入了一个失忆陌生人冯文轩（甄子丹 饰），阿威为冯文轩引路，半途遇上山贼，冯文轩大开杀戒，令阿威折服，拜其为师。山贼一伙并未善罢甘休，对冯文轩展开连番追杀，冯文轩伤重之时，因阿威而与旧日恋人惠怡（李若彤 饰）重逢，冯文轩寻回了失去了记忆，发现自己曾经竟也是山贼的一员，而越来越严酷的杀伐令他与恋人深陷险境……阿Ben听了二人的讲述后，并未改变心意，并揭露了自己寻找冯文轩的真正目的……\r\n                        \r\n                        \r\n', '0000-00-00 00:00:00');
INSERT INTO `yycms_vod` VALUES ('69', '超级兵王之战狼归来', 'http://pic.bjssmd.net/img/p2504470350.jpg', '主演:吴建国/金久哲/齐欣', '0', '0', '2', '0', '', '第1集$http://v1.bjssmd.net/20190714/mOrx52o1/index.m3u8\r\n第2集$http://v1.bjssmd.net/20190714/zF0hA8L1/index.m3u8\r\n第3集$http://v1.bjssmd.net/20190714/vUmxACaG/index.m3u8\r\n第4集$http://v1.bjssmd.net/20190714/gxc1vpqw/index.m3u8\r\n第5集$http://v1.bjssmd.net/20190714/ciru7Y2v/index.m3u8\r\n第6集$http://v1.bjssmd.net/20190714/3Nxq08ho/index.m3u8\r\n第7集$http://v1.bjssmd.net/20190714/0yKocfLu/index.m3u8\r\n第8集$http://v1.bjssmd.net/20190714/KBDXFoEQ/index.m3u8\r\n第9集$http://v1.bjssmd.net/20190714/Ap0ZG9si/index.m3u8\r\n第10集$http://v1.bjssmd.net/20190714/03SMckav/index.m3u8\r\n第11集$http://v1.bjssmd.net/20190714/6J0pNztW/index.m3u8\r\n第12集$http://v1.bjssmd.net/20190714/gWrl9IOw/index.m3u8\r\n第13集$http://v1.bjssmd.net/20190714/NBNc50RS/index.m3u8\r\n第14集$http://v1.bjssmd.net/20190714/r9GLkCzd/index.m3u8\r\n第15集$http://v1.bjssmd.net/20190714/ytJK1Fuv/index.m3u8\r\n第16集$http://v1.bjssmd.net/20190714/eXNyj3i4/index.m3u8', '何勇是侦察连退伍兵，讲义气，身手不凡，用复员费买了辆二手中巴车跑城乡线路，在营运中女朋友遇到了流氓调戏敲诈，何勇被迫出手，吃亏的流氓深夜进村烧车报复，何勇带着两个从小一起长大的好兄弟复仇，却被阴狠毒辣的贩毒团伙头目刀鱼所制，何勇哥仨被从事正当生意的大老板天哥所救后，带着峰子与小新一起投奔天哥，做了其麾下豪情夜总会总经理，夜总会生意很有起色，刀鱼团伙想借助夜总会贩毒，被何勇拒绝，刀鱼设下圈套利用美色、赌局将小新拉下水，何勇在经历了兄弟背叛之后又深陷俄罗斯贩毒团伙阴谋当中，天哥助手肥江背叛天哥设下圈套，遭遇了俄罗斯黑帮的追杀身负重伤，被俄罗斯姑娘阿柳莎所救，何勇最后能否逢凶化吉，并抱得美人归\r\n                        \r\n                        \r\n\r\n', '0000-00-00 00:00:00');
INSERT INTO `yycms_vod` VALUES ('70', '哪吒之魔童降世', 'https://tu.tianzuida.com/pic/upload/vod/2019-07-26/201907261564124474.jpg', '吕艳婷,囧森瑟夫,瀚墨,陈浩,绿绮,张珈铭,杨卫', '0', '0', '1', '0', '', 'HD1280高清国语中字版$http://wuji.zhulong-zuida.com/20191010/10591_98f58691/index.m3u8', '天地灵气孕育出一颗能量巨大的混元珠，元始天尊将混元珠提炼成灵珠和魔丸，灵珠投胎为人，助周伐纣时可堪大用；而魔丸则会诞出魔王，为祸人间。元始天尊启动了天劫咒语，3年后天雷将会降临，摧毁魔丸。太乙受命将灵珠托生于陈塘关李靖家的儿子哪吒身上。然而阴差阳错，灵珠和魔丸竟然被掉包。本应是灵珠英雄的哪吒却成了混世大魔王。调皮捣蛋顽劣不堪的哪吒却徒有一颗做英雄的心。然而面对众人对魔丸的误解和即将来临的天雷的降临，哪吒是否命中注定会立地成魔？他将何去何从？', '0000-00-00 00:00:00');
INSERT INTO `yycms_vod` VALUES ('74', '攀登者', 'https://tu.tianzuida.com/pic/upload/vod/2019-09-30/201909301569841610.jpg', '吴京,章子怡,张译,井柏然,胡歌,王景春,何琳,陈龙,刘小锋,曲尼次仁,拉旺罗布,多布杰,成龙', '0', '0', '1', '0', '', 'HC清晰版$http://bili.meijuzuida.com/20191008/21609_9b3f1a41/index.m3u8', '1960年，中国登山队向珠峰发起冲刺，完成了世界首次北坡登顶这一不可能的任务。15 年后，方五洲和曲松林在气象学家徐缨的帮助下，带领李国梁、杨光等年轻队员再次挑战世界之巅。迎接他们的将是更加 严酷的现实，也是生与死的挑战......', '0000-00-00 00:00:00');
INSERT INTO `yycms_vod` VALUES ('76', '双子杀手', 'https://tu.tianzuida.com/pic/upload/vod/2019-10-08/201910081570510974.jpg', '威尔·史密斯,玛丽·伊丽莎白·温斯特德,克里夫·欧文,道格拉斯·霍奇斯,本尼迪克特·王,拉尔夫·布朗,西奥多拉·伍利,琳达·伊蒙,提姆·康纳利,安德里娅·舒,伊利亚·沃里克,E·J·博尼拉,大卫·莫拉蒂,比约恩·弗赖贝格,施奎塔·詹姆斯,肯尼·谢尔德,亚历山德拉·苏奇,费尔南达·多罗吉', '0', '', '1', '1', null, 'TC中字版$http://haoa.haozuida.com/20191009/uP6VIC1t/index.m3u8', '美国国防情报局特工亨利（威尔·史密斯饰），准备退休之际意外遭到一名神秘杀手的追杀，在两人的激烈较量中，他发现这名杀手竟然是年轻了20多岁的自己，一场我与我的对决旋即展开，而背后的真相也逐渐浮出水面。', '2019-10-15 10:25:47');
INSERT INTO `yycms_vod` VALUES ('77', '犯罪现场', 'https://tu.tianzuida.com/pic/upload/vod/2019-10-12/201910121570862385.jpg', '古天乐,宣萱,张继聪,谭耀文,姜皓文,李灿森,安志杰,刘心悠,薛凯琪,凌文龙,吴肇轩,颜卓灵,陈国邦,张松枝,蔡洁,徐广林,周祉君,张文杰,胡卓希', '0', '', '5', '1', null, 'HDTC中字版$http://haoa.haozuida.com/20191012/QYFcJZKk/index.m3u8', '当鹦鹉成为唯一的目击证人时，凶案究竟要如何破解?一名珠宝劫匪伏尸工厦单位内，所有赃物不翼而飞，警方断定是群匪分赃不均，当中嫌疑最大的莫非为匪帮首领汪新元。警官叶守正率领 一众警员展开调查，确定此案与三个月前的「利新珠宝劫案」有 关。怎料其他劫匪相继遇害，林法梁逐渐发现案中案......而能够解开「谁是凶手」这道谜题的，就只有当日在犯罪现场目击凶案的唯一「证人」:一只会说话的鹦鹉。', '2019-10-15 10:25:47');
INSERT INTO `yycms_vod` VALUES ('78', '我和我的祖国', 'https://tu.tianzuida.com/pic/upload/vod/2019-09-30/201909301569818836.jpg', '黄渤,张译,吴京,马伊琍,杜江,葛优,刘昊然,陈飞宇,宋佳,王千源,欧豪,辛柏青,魏晨,耿乐,姜武,胡军,梁静,佟大为,王天辰,任素汐,张嘉译,周冬雨,彭昱畅,罗海琼,郭丞,周依然,韩昊霖,刘涛,张建亚,樊雨洁,徐峥,邵汶,张芝华,段博文,朱一龙,惠英红,任达华,王洛勇,高亚麟,王道铁,王东,龚蓓苾,程禹森,马书良,田壮壮,江珊,景海鹏,陈冬,佟丽娅,韩东君,雷佳音,张子枫,王砚辉,陶虹,郭京飞,袁文康,贾晨飞', '0', '', '0', '1', null, '郎平回忆女排三连冠$http://wuji.zhulong-zuida.com/20191008/10418_9d3b1aaf/index.m3u8', '七位导演分别取材新中国成立70周年以来，祖国经历的无数个历史性经典瞬间。讲述普通人与国家之间息息相关密不可分的动人故事。聚焦大时代大事件下，小人物和国家之间，看似遥远实则密切的关联，唤醒全球华人共同回忆。', '2019-10-15 10:25:47');
INSERT INTO `yycms_vod` VALUES ('79', '中国机长', 'https://tu.tianzuida.com/pic/upload/vod/2019-09-30/201909301569852206.jpg', '张涵予,欧豪,杜江,袁泉,张天爱,李沁,雅玫,杨祺如,高戈,黄志忠,朱亚文,李现,杨颖,陈数,焦俊艳,吴樾,阚清子,余皑磊,刘浩,李岷城,冯文娟', '0', '', '5', '1', null, 'HC清晰版$http://bili.meijuzuida.com/20191008/21608_3b16270a/index.m3u8', '电影《中国机长》根据2018年5月14日四川航空3U8633航班机组成功处置特情真实事件改编：机组执行航班任务时，在万米高空突遇驾驶舱风挡玻璃爆裂脱落、座舱释压的极端罕见险情，生死关头，他们临危不乱、果断应对、正确处置，确保了机上全部人员的生命安全，创造了世界民航史上的奇迹。', '2019-10-15 10:25:47');
INSERT INTO `yycms_vod` VALUES ('80', '雪人奇缘', 'https://tu.tianzuida.com/pic/upload/vod/2019-09-29/201909291569733691.jpg', '汪可盈,阿尔伯特·蔡,艾迪·伊扎德,莎拉·保罗森,丹增·诺盖·特雷纳,周采芹,张子枫,陈飞宇,何向东,刘风,万茜,蔡明', '0', '', '10', '1', null, 'HDTC中字版$https://haoa.haozuida.com/20191001/7ZWHabsQ/index.m3u8', '珠穆朗玛峰的雪人是传说吗？不是！不仅不是传说，它还拥有令人着迷的魔力！少女小艺在天台上目睹了雪人大毛即将被抓的惨况，决定亲自护送大毛回家，她的小伙伴阿俊和鹏鹏也加入了护送队伍。一路上冒险小分队路经了千岛湖、黄山、乐山大佛等著名的中国景点，雪人大毛为了躲避抓捕者，也逐一展现了自己神奇的魔力。巨大化的蒲公英，一秒变大的蓝莓，油菜花海浪，还有什么是雪人大毛的魔力做不到的？而抓捕者也早已在他们的目的地珠峰等待着冒险小分队步入早已设好的圈套…', '2019-10-15 10:25:47');
INSERT INTO `yycms_vod` VALUES ('81', '急速逃脱', 'https://tu.tianzuida.com/pic/upload/vod/2019-10-08/201910081570510711.jpg', '克里斯蒂安娜·保罗,亚历山大·约瓦诺维奇,汉娜·赫茨施普龙,沃坦·维尔克·默林', '0', '2', '5', '1', '', 'HD1280高清中字版$http://bili.meijuzuida.com/20191008/21605_dbd98714/index.m3u8', '卡尔是一名建筑商人，某天送儿女上学时突然接到一通陌生电话，说车上安放了炸弹，一离开座椅炸弹就会爆炸，如果报警就摇控炸车。狭小的车内空间顿时将三人的不安和紧张感无限放大…中途剧情紧凑反转不断，而警察调查结果竟将犯罪嫌疑人锁定为卡尔自己，随着时间流逝，卡尔面临即将失去所有财富、性命甚至家庭的多重危机将如何解决？最终结局又会出现怎样的反转？', '2019-10-15 10:25:47');
INSERT INTO `yycms_vod` VALUES ('82', '战狼特攻队', 'http://pic.bjssmd.net/img/p1246206015.jpg', '主演: A.J. Drave, Steven Bauer ', '0', '0', '1', '0', '', 'HD$http://v3.bjssmd.net/20190902/VTFmZIAq/index.m3u8', 'None', '2019-10-16 10:37:27');

-- ----------------------------
-- Table structure for `yycms_vod_class`
-- ----------------------------
DROP TABLE IF EXISTS `yycms_vod_class`;
CREATE TABLE `yycms_vod_class` (
  `c_id` smallint(6) unsigned NOT NULL AUTO_INCREMENT,
  `c_name` varchar(64) NOT NULL DEFAULT '',
  `c_pid` smallint(6) NOT NULL DEFAULT '0',
  `c_sort` smallint(6) NOT NULL DEFAULT '0',
  `c_hide` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`c_id`),
  KEY `c_sort` (`c_sort`),
  KEY `c_pid` (`c_pid`),
  KEY `c_hide` (`c_hide`)
) ENGINE=MyISAM AUTO_INCREMENT=1002 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of yycms_vod_class
-- ----------------------------
INSERT INTO `yycms_vod_class` VALUES ('1', '科幻', '0', '1', '0');
INSERT INTO `yycms_vod_class` VALUES ('2', '惊悚', '0', '2', '0');
INSERT INTO `yycms_vod_class` VALUES ('3', '犯罪', '0', '3', '0');
INSERT INTO `yycms_vod_class` VALUES ('4', '战争', '0', '4', '0');
INSERT INTO `yycms_vod_class` VALUES ('12', '日韩剧', '0', '12', '0');
INSERT INTO `yycms_vod_class` VALUES ('5', '剧情', '0', '5', '0');
INSERT INTO `yycms_vod_class` VALUES ('6', '动作', '0', '6', '0');
INSERT INTO `yycms_vod_class` VALUES ('7', '爱情', '0', '7', '0');
INSERT INTO `yycms_vod_class` VALUES ('8', '动漫', '0', '8', '0');
INSERT INTO `yycms_vod_class` VALUES ('9', '喜剧', '0', '9', '0');
INSERT INTO `yycms_vod_class` VALUES ('10', '动漫', '0', '10', '0');
INSERT INTO `yycms_vod_class` VALUES ('11', '欧美剧', '0', '11', '0');

-- ----------------------------
-- Table structure for `yycms_wx`
-- ----------------------------
DROP TABLE IF EXISTS `yycms_wx`;
CREATE TABLE `yycms_wx` (
  `wx_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `wx_pingtai` varchar(12) DEFAULT NULL,
  `wx_url` varchar(111) DEFAULT '',
  `wx_appid` varchar(150) DEFAULT '',
  `wx_appsecret` varchar(150) DEFAULT '',
  `wx_token` varchar(11) DEFAULT '',
  `wx_hf` text,
  `wx_ts` text,
  PRIMARY KEY (`wx_id`),
  KEY `d_letter` (`wx_token`),
  KEY `d_name` (`wx_url`),
  KEY `d_enname` (`wx_appsecret`)
) ENGINE=MyISAM AUTO_INCREMENT=38 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of yycms_wx
-- ----------------------------
INSERT INTO `yycms_wx` VALUES ('1', '1', 'http://yycms.saonantv.com/', 'wxbe0a32b6499b', 'c9a7666817f884d', '1993', '欢迎加入xx影视公众号.回复你想看的影片关键词就行了', '资源没找到,请更改关键词,或者等待更新');

-- ----------------------------
-- Table structure for `yycms_yl`
-- ----------------------------
DROP TABLE IF EXISTS `yycms_yl`;
CREATE TABLE `yycms_yl` (
  `yl_id` int(11) NOT NULL AUTO_INCREMENT,
  `yl_name` varchar(10) NOT NULL,
  `yl_url` text NOT NULL,
  PRIMARY KEY (`yl_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of yycms_yl
-- ----------------------------
INSERT INTO `yycms_yl` VALUES ('4', '雨雨cms', 'http://yysq.saonantv.com/');

-- ----------------------------
-- Table structure for `yycms_zhifu`
-- ----------------------------
DROP TABLE IF EXISTS `yycms_zhifu`;
CREATE TABLE `yycms_zhifu` (
  `zf_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `zf_kg` int(10) DEFAULT NULL,
  `zf_user` varchar(11) NOT NULL DEFAULT '',
  `zf_pass` varchar(250) NOT NULL DEFAULT '',
  `zf_pay` text,
  PRIMARY KEY (`zf_id`),
  KEY `d_name` (`zf_user`),
  KEY `d_enname` (`zf_pay`(11))
) ENGINE=MyISAM AUTO_INCREMENT=38 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of yycms_zhifu
-- ----------------------------
INSERT INTO `yycms_zhifu` VALUES ('1', '1', '2507', 'BAhV7SvsBtQqc78Taa7q9Ww7S8ZBA997', '2');
