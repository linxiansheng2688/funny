<?php
//Mysql数据库信息
if(!defined('PCFINAL')) exit('Request Error!');
define('DATA_HOST', 'localhost');
define('DATA_USERNAME', 'ROOT');
define('DATA_PASSWORD', '123456');
define('DATA_NAME', '123');
?>