<?php
error_reporting(0); //雨雨CMS作者QQ:201232694
$yuming = $_SERVER['HTTP_HOST'];
//根据域名查询代理ID
$sql_jc = mysql_query("SELECT * FROM yycms_pintai WHERE a_url='$yuming'");
$row_jc   = mysql_fetch_array($sql_jc);
$pintaiid = $row_jc['id'];
$hxlpintai_id=isset($pintaiid) ? trim($pintaiid) : '1';
$file = (__DIR__).'/'.$hxlpintai_id.'.txt';
$expire = 86000; // 24 小时 (单位：秒)
if (file_exists($file) && 
filemtime($file) > (time() - $expire))
{
//取得缓存中的记录
//$records = unserialize(file_get_contents($file));
$records = unserialize(implode('',file($file)));
} else {
$result = mysql_query('select * from yycms_pintai where id = '.$hxlpintai_id.'');
while ($record = mysql_fetch_array($result) )
{
$records[] = $record;
}
unlink($file);
$OUTPUT = serialize($records);
$fp = fopen($file,"w"); // 以写权限的方式打开文件
fputs($fp, $OUTPUT);
fclose($fp);
$records = unserialize(implode('',file($file)));
}
$yycms_a_bt = $records[0]['a_bt'];//网站名字
$yycms_a_name = $records[0]['a_name'];//网站名字
$yycms_a_url = $records[0]['a_url'];//网站域名
$yycms_a_keywords = $records[0]['a_keywords'];//网站关键词
$yycms_a_description = $records[0]['a_description'];//网站关键描述
$yycms_a_bfqgg = $records[0]['a_bfqgg'];//播放器广告
$yycms_a_jzt = $records[0]['a_jzt'];//加载图
$yycms_a_hckg = $records[0]['a_hckg'];//缓存开关
$yycms_a_hcsj = $records[0]['a_hcsj'];//缓存时间
$yycms_a_logo = $records[0]['a_logo'];//网站logo
$yycms_a_fhkg = $records[0]['a_fhkg'];//仿红开关
$yycms_a_mrjx = $records[0]['a_mrjx'];//默认解析
$yycms_a_jxjk = $records[0]['a_jxjk'];//解析线路
$yycms_a_zyjk = $records[0]['a_zyjk'];//资源线路
$yycmszyjx=explode("\r\n",$yycms_a_zyjk);
$yycms_a_ggkg = $records[0]['a_ggkg'];//公告开关
$yycms_a_gg = $records[0]['a_gg'];//公告内容
$yycms_a_qqsp = $records[0]['a_qqsp'];//视频侵权
$yycms_a_bq = $records[0]['a_bq'];//底部版权
$yycms_a_tj = $records[0]['a_tj'];//统计内容
$yycms_a_dbdh = $records[0]['a_dbdh'];//底部导航
$yycms_a_dylb = $records[0]['a_dylb'];//电影轮播
$yycms_a_dst = $records[0]['a_dst'];//打赏二维码
$yycms_a_sfkg = $records[0]['a_sfkg'];//收费开关
$yycms_a_mb = $records[0]['a_mb'];//模板
$yycms_a_kg1 = $records[0]['a_kg1'];//抢先

$yycms_s_bftitle = $records[0]['s_bftitle'];
$yycms_s_bfkeywords = $records[0]['s_bfkeywords'];
$yycms_s_bfdescription = $records[0]['s_bfdescription'];
function YYCMSRS(){
$url="https://www.360kan.com/rank/index";
mkdir('./cache');
mkdir('./cache/sspm');
$gxpd=time()-filemtime('./cache/sspm/'.md5($url));
if($gxpd>10*60*60){
$data=file_get_contents($url);	
file_put_contents('./cache/sspm/'.md5($url),gzdeflate($data));
}
$info=gzinflate(file_get_contents('./cache/sspm/'.md5($url)));
$name='#<span class="p-cat-videoname" title="(.*)">(.*)</span>#';
preg_match_all($name, $info,$nr); 
for ($x=0; $x<=9; $x++){
$rmss.='<p><a class="text-333" href="/search-'.$nr[1][$x].'.html" title=""><span class="badge">'.($x+1).'</span> '.$nr[1][$x].'</a></p>';
}
return $rmss;
}
?>