<?php
if($yycms_a_sfkg==1){//开启收费模式
if(!isset($_COOKIE['user_name'])){
		alert_href('请登录后观看','/user/login.php');
	};
//判断会员等级
$result = mysql_query('select * from yycms_user where b_user="'.$_COOKIE['user_name'].'"');
$rowhy = mysql_fetch_array($result);
$dqsj = date('Y-m-d H:i:s');
	if ($dqsj > $rowhy['b_type']) {
		alert_href('对不起,您的会员已到期,请充值续费！','/user/buy.html');
}
}//后续功能在更新
?>