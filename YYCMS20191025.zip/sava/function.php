<?php
function yycmszcfh($C_url){//验证账号
    $str="/^[a-z0-9]+$/";  
    if (!preg_match($str,$C_url)){  
        return false;  
    }else{  
    return true;  
    }  }
function arrtoinsert($_var_74)//添加
{
	$_var_75 = '';
	$_var_76 = '';
	foreach ($_var_74 as $_var_77 => $_var_78) {
		$_var_79[] = '`' . $_var_77 . '`';
		$_var_80[] = '"' . $_var_78 . '"';
	}
	$_var_75 .= implode(',', $_var_79);
	$_var_76 .= implode(',', $_var_80);
	$_var_81[0] = $_var_75;
	$_var_81[1] = $_var_76;
	return $_var_81;
}
function page_handle($_var_8, $_var_9, $_var_10)
{
	if (isset($_GET[$_var_8])) {
		$_var_11 = $_GET[$_var_8];
		if (empty($_var_11) || $_var_11 < 1 || !is_numeric($_var_11)) {
			$_var_11 = 1;
		} else {
			$_var_11 = intval($_var_11);
		}
	} else {
		$_var_11 = 1;
	}
	if ($_var_10 == 0) {
		$_var_12 = 1;
	} else {
		$_var_12 = ceil($_var_10 / $_var_9);
	}
	if ($_var_11 > $_var_12) {
		$_var_11 = $_var_12;
	}
	$_var_13 = ($_var_11 - 1) * $_var_9;
	$_var_14 = array();
	$_var_14[0] = $_var_13;
	$_var_14[1] = $_var_9;
	$_var_14[2] = $_var_12;
	$_var_14[3] = $_var_11;
	$_var_14[4] = $_var_8;
	return $_var_14;
}
function page_show($_var_15, $_var_16, $_var_17, $_var_18)
{
	$_var_19 = $_var_15;
	$_var_20 = $_var_16;
	$_var_21 = $_var_17;
	$_var_22 = $_var_18;
	$_var_23 = '';
	$_var_24 = '';
	$_var_23 = $_var_20 - $_var_22;
	if ($_var_23 <= 0) {
		$_var_23 = 1;
		$_var_24 = $_var_23 + $_var_24;
	}
	$_var_24 = $_var_20 + $_var_22;
	if ($_var_24 > $_var_19) {
		$_var_24 = $_var_19;
	}
	$_var_25 = $_SERVER['REQUEST_URI'];
	$_var_26 = parse_url($_var_25);
	if (isset($_var_26['query'])) {
		$_var_27 = $_var_26['path'];
		$_var_28 = $_var_26['query'];
		parse_str($_var_28, $_var_29);
		unset($_var_29[$_var_21]);
		if (count($_var_29) != 0) {
			$_var_25 = $_var_27 . '?' . http_build_query($_var_29) . '&';
		} else {
			$_var_25 = $_var_27 . '?';
		}
	} else {
		$_var_25 = $_var_25 . '?';
	}
	$_var_30 = '';
	$_var_31 = '';
	$_var_32 = '';
	$_var_33 = '';
	$_var_34 = '';
	$_var_35 = '';
	if ($_var_20 > $_var_22 + 1) {
		//$_var_31 = '<a href="' . $_var_25 . $_var_21 . '=1" title="首页">1..</a>';
		$_var_31 = '<a class="indexPage" href="' . $_var_25 . $_var_21 . '">首页</a>';
	}
	if ($_var_20 == 1) {
		$_var_30 = '';
	} else {
		$_var_30 = '<a class="prePage" href="' . $_var_25 . $_var_21 . '=' . ($_var_20 - 1) . '" title="上一页">上一页</a>';
	}
	for ($_var_36 = $_var_23; $_var_36 <= $_var_24; $_var_36++) {
		if ($_var_36 == $_var_20) {
			$_var_32 = $_var_32 . '<strong>' . $_var_36 . '</strong>';
		} else {
			$_var_32 = $_var_32 . '<a href="' . $_var_25 . $_var_21 . '=' . $_var_36 . '" title="第' . $_var_36 . '页">' . $_var_36 . '</a>';
		}
	}
	if ($_var_20 < $_var_19 - $_var_22) {
		$_var_33 = '<a class="indexPage" href="' . $_var_25 . $_var_21 . '=' . $_var_19 . '" title="尾页">尾页</a>';
	}
	if ($_var_20 == $_var_19) {
		$_var_34 = '';
	} else {
		$_var_34 = '<a class="prePage" href="' . $_var_25 . $_var_21 . '=' . ($_var_20 + 1) . '" title="下一页">下一页</a>';
	}
	$_var_35 = $_var_35 . $_var_30 . $_var_31 . $_var_32 . $_var_33 . $_var_34 . '';
	return $_var_35;
}
function get_usergroup_name($_var_44)
{
	$_var_45 = mysql_query('select * from yycms_hy where ug_id=' . $_var_44 . '');
	if (!!($_var_46 = mysql_fetch_array($_var_45))) {
		return $_var_46['ug_name'];
	} else {
		return '';
	}
}
function hqur()
{
$http_type = ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https')) ? 'https://' : 'http://'; 
return $http_type . $_SERVER['HTTP_HOST'];
}
function arrtoupdate($_var_82)//修改
{
	$_var_83 = '';
	$_var_84 = '';
	foreach ($_var_82 as $_var_85 => $_var_86) {
		$_var_83 .= $_var_84 . '`' . $_var_85 . '` = "' . $_var_86 . '"';
		$_var_84 = ',';
	}
	return $_var_83;
}
function channel_hytc($_var_1, $_var_2, $_var_3)
{
	$_var_4 = '';
	$_var_5 = '';
	$_var_6 = $_var_1;
	$_var_7 = '';
	for ($_var_8 = 0; $_var_8 < $_var_6; $_var_8++) {
		$_var_5 = $_var_5 . '　';
	}
	$_var_7 = $_var_0 == 0 ? '' : '├';
	$_var_6 = $_var_6 + 1;
	$_var_9 = 'select * from yycms_hytc where tc_id <> ' . $_var_3 . ' order by tc_id asc , tc_id asc';
	$_var_10 = mysql_query($_var_9);
	while ($_var_11 = mysql_fetch_array($_var_10)) {
		$_var_12 = $_var_11['tc_type'] == $_var_2 ? 'selected="selected"' : '';
		$_var_4 .= '<option value="' . $_var_11['tc_type'] . '" ' . $_var_12 . '>' . $_var_5 . $_var_7 . $_var_11['tc_name'] . '</option>' . channel_select_list($_var_11['tc_id'], $_var_6, $_var_2, $_var_3);
	}
	return $_var_4;
}
function channel_select_list($_var_0, $_var_1, $_var_2, $_var_3)
{
	$_var_4 = '';
	$_var_5 = '';
	$_var_6 = $_var_1;
	$_var_7 = '';
	for ($_var_8 = 0; $_var_8 < $_var_6; $_var_8++) {
		$_var_5 = $_var_5 . '　';
	}
	$_var_7 = $_var_0 == 0 ? '' : '├';
	$_var_6 = $_var_6 + 1;
	$_var_9 = 'select * from yycms_vod_class where c_pid = ' . $_var_0 . ' and c_id <> ' . $_var_3 . ' order by c_sort asc , c_id asc';
	$_var_10 = mysql_query($_var_9);
	while ($_var_11 = mysql_fetch_array($_var_10)) {
		$_var_12 = $_var_11['c_id'] == $_var_2 ? 'selected="selected"' : '';
		$_var_4 .= '<option value="' . $_var_11['c_id'] . '" ' . $_var_12 . '>' . $_var_5 . $_var_7 . $_var_11['c_name'] . '</option>' . channel_select_list($_var_11['c_id'], $_var_6, $_var_2, $_var_3);
	}
	return $_var_4;
}
function channel_select_list1($_var_0, $_var_1, $_var_2, $_var_3)
{
	$_var_4 = '';
	$_var_5 = '';
	$_var_6 = $_var_1;
	$_var_7 = '';
	for ($_var_8 = 0; $_var_8 < $_var_6; $_var_8++) {
		$_var_5 = $_var_5 . '　';
	}
	$_var_7 = $_var_0 == 0 ? '' : '├';
	$_var_6 = $_var_6 + 1;
	$_var_9 = 'select * from yycms_pintai order by id asc';
	$_var_10 = mysql_query($_var_9);
	while ($_var_11 = mysql_fetch_array($_var_10)) {
		$_var_12 = $_var_11['id'] == $_var_2 ? 'selected="selected"' : '';
		$_var_4 .= '<option value="' . $_var_11['id'] . '" ' . $_var_12 . '>' . $_var_5 . $_var_7 . $_var_11['a_name'] . '</option>' . channel_select_list($_var_11['id'], $_var_6, $_var_2, $_var_3);
	}
	return $_var_4;
}
//提示后返回
function alert_back($_var_1)
{
	die('<script type="text/javascript">alert("' . $_var_1 . '");window.history.back();</script>');
}
//提示后跳转
function alert_href($_var_2, $_var_3)
{
	die('<script type="text/javascript">alert("' . $_var_2 . '");window.location.href="' . $_var_3 . '"</script>');
}
//空值返回
function null_back($_var_4, $_var_5)
{
	if ($_var_4 == '') {
		alert_back($_var_5);
	}
}
function curl_file_get_contents($durl){
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $durl);
	curl_setopt($ch, CURLOPT_TIMEOUT, 5);
	curl_setopt($ch, CURLOPT_USERAGENT, _USERAGENT_);
	curl_setopt($ch, CURLOPT_REFERER,_REFERER_);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	$r = curl_exec($ch);
	curl_close($ch);
	return $r;
 }
function gett($url)
{  //作者QQ 201232694 请保留联系.尊重成果
$user_agent = "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36";  
   $curl = curl_init(); 
   // 配置curl中的http协议->可配置的荐可以查PHP手册中的curl_  
   curl_setopt($curl, CURLOPT_URL, $url);  
   curl_setopt($curl, CURLOPT_USERAGENT,$user_agent);		   //模拟用户浏览器信息 
   curl_setopt($curl, CURLOPT_RETURNTRANSFER, TRUE);  
   curl_setopt($curl, CURLOPT_HEADER, FALSE); 
   curl_setopt($curl, CURLOPT_TIMEOUT,10);   //只需要设置一个秒的数量就可以  
      curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);            //返回字符串，而非直接输出到屏幕上
	curl_setopt($curl, CURLOPT_FOLLOWLOCATION,1);             //跟踪爬取重定向页面
   curl_setopt($curl, CURLOPT_SSL_VERIFYPEER,false);
   curl_setopt($curl, CURLOPT_SSL_VERIFYHOST,false); 
   	curl_setopt($curl, CURLOPT_ENCODING, '');	          //解决网页乱码问题
   // 执行这个请求  
   return curl_exec($curl);  
}
function  qwget($url,$timeout = 7) {  
    $user_agent = "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36";  
    $curl = curl_init();                                        //初始化 curl
    curl_setopt($curl, CURLOPT_URL, $url);                      //要访问网页 URL 地址
	curl_setopt($curl, CURLOPT_USERAGENT,$user_agent);		   //模拟用户浏览器信息 
    curl_setopt($curl, CURLOPT_REFERER,$url) ;               //伪装网页来源 URL
    curl_setopt($curl, CURLOPT_AUTOREFERER, 1);                //当Location:重定向时，自动设置header中的Referer:信息                   
    curl_setopt($curl, CURLOPT_TIMEOUT, $timeout);             //数据传输的最大允许时间 
    curl_setopt($curl, CURLOPT_HEADER, 0);                     //不返回 header 部分
   curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);            //返回字符串，而非直接输出到屏幕上
	curl_setopt($curl, CURLOPT_FOLLOWLOCATION,1);             //跟踪爬取重定向页面
	curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, '0');        //不检查 SSL 证书来源
	curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, '0');        //不检查 证书中 SSL 加密算法是否存在
	curl_setopt($curl, CURLOPT_ENCODING, '');	          //解决网页乱码问题
    return curl_exec($curl);  
}/*雨雨cms 咨询联系QQ 201232694*/  

function pagee_show($_var_60, $_var_61, $_var_62,$css1,$css2,$css3)
{
$cs1=$_GET['cid'];//类型
	$_var_63 = 5;
	$_var_60 = $_var_60 < 1 ? 1 : $_var_60;
	$_var_60 = $_var_60 > $_var_61 ? $_var_61 : $_var_60;
	$_var_61 = $_var_61 < $_var_60 ? $_var_60 : $_var_61;
	$_var_64 = $_var_60 - floor($_var_63 / 2);
	$_var_64 = $_var_64 < 1 ? 1 : $_var_64;
	$_var_65 = $_var_60 + floor($_var_63 / 2);
	$_var_65 = $_var_65 > $_var_61 ? $_var_61 : $_var_65;
	$_var_66 = $_var_65 - $_var_64 + 1;
	if ($_var_66 < $_var_63 && $_var_64 > 1) {
		$_var_64 = $_var_64 - ($_var_63 - $_var_66);
		$_var_64 = $_var_64 < 1 ? 1 : $_var_64;
		$_var_66 = $_var_65 - $_var_64 + 1;
	}
	if ($_var_66 < $_var_63 && $_var_65 < $_var_61) {
		$_var_65 = $_var_65 + ($_var_63 - $_var_66);
		$_var_65 = $_var_65 > $_var_61 ? $_var_61 : $_var_65;
	}
	if ($_var_60 > 1) {
		$_var_67 .= '<li><a  class="' . $css1 .'" title="首页" href="' . $_var_62 .'-' . $cs1 . '-1.html">首页</a></li>';
		$_var_67 .= '<li><a  class="' . $css1 .'" title="上一页" href="' . $_var_62 .'-' . $cs1 . '-' . ($_var_60 - 1) . '.html">上一页</a></li>';	
	}
	for ($_var_68 = $_var_64; $_var_68 <= $_var_65; $_var_68++) {
		if ($_var_68 == $_var_60) {
			$_var_67 .= '<li class="' . $css3 .'"><a class="' . $css2 .'" target="_self" class="on">' . $_var_60 . '</a></li>';
		} else {
			$_var_67 .= '<li class="' . $css3 .'" ><a class="' . $css1 .'" href="' . $_var_62 .'-' . $cs1 . '-' . $_var_68 . '.html">' . $_var_68 . '</a></li>';
		}
	}
	if ($_var_60 < $_var_65) {
		$_var_67 .= '<li><a class="' . $css1 .'" title="下一页" href="' . $_var_62 .'-' . $cs1 . '-' . ($_var_60 + 1) . '.html">下一页</a></li>';
		$_var_67 .= '<li><a class="' . $css1 .'" title="尾页" href="' . $_var_62 .'-' . $cs1 . '-' . $_var_61 . '.html">尾页</a></li>';
	}
	return $_var_67;
}
function yg_show($_var_60, $_var_61, $_var_62,$css1,$css2,$css3)
{
	$_var_63 = 5;
	$_var_60 = $_var_60 < 1 ? 1 : $_var_60;
	$_var_60 = $_var_60 > $_var_61 ? $_var_61 : $_var_60;
	$_var_61 = $_var_61 < $_var_60 ? $_var_60 : $_var_61;
	$_var_64 = $_var_60 - floor($_var_63 / 2);
	$_var_64 = $_var_64 < 1 ? 1 : $_var_64;
	$_var_65 = $_var_60 + floor($_var_63 / 2);
	$_var_65 = $_var_65 > $_var_61 ? $_var_61 : $_var_65;
	$_var_66 = $_var_65 - $_var_64 + 1;
	if ($_var_66 < $_var_63 && $_var_64 > 1) {
		$_var_64 = $_var_64 - ($_var_63 - $_var_66);
		$_var_64 = $_var_64 < 1 ? 1 : $_var_64;
		$_var_66 = $_var_65 - $_var_64 + 1;
	}
	if ($_var_66 < $_var_63 && $_var_65 < $_var_61) {
		$_var_65 = $_var_65 + ($_var_63 - $_var_66);
		$_var_65 = $_var_65 > $_var_61 ? $_var_61 : $_var_65;
	}
	if ($_var_60 > 1) {
		$_var_67 .= '<li><a  class="' . $css1 .'" title="首页" href="' . $_var_62 .'-1.html">首页</a></li>';
		$_var_67 .= '<li><a  class="' . $css1 .'" title="上一页" href="' . $_var_62 .'-' . ($_var_60 - 1) . '.html">上一页</a></li>';	
	}
	for ($_var_68 = $_var_64; $_var_68 <= $_var_65; $_var_68++) {
		if ($_var_68 == $_var_60) {
			$_var_67 .= '<li class="' . $css3 .'"><a class="' . $css2 .'" target="_self" class="on">' . $_var_60 . '</a></li>';
		} else {
			$_var_67 .= '<li class="' . $css3 .'" ><a class="' . $css1 .'" href="' . $_var_62 .'-' . $_var_68 . '.html">' . $_var_68 . '</a></li>';
		}
	}
	if ($_var_60 < $_var_65) {
		$_var_67 .= '<li><a class="' . $css1 .'" title="下一页" href="' . $_var_62 .'-' . ($_var_60 + 1) . '.html">下一页</a></li>';
		$_var_67 .= '<li><a class="' . $css1 .'" title="尾页" href="' . $_var_62 .'-' . $_var_61 . '.html">尾页</a></li>';
	}
	return $_var_67;
}

function getPageHtml($_var_60, $_var_61, $_var_62,$css1,$css2,$css3)
{
$cs0=$_GET['rank'];//火热
if($cs0=='')$cs0='rankhot';
$cs1=$_GET['cat'];//类型
$cs2=$_GET['area'];//地区
$cs3=$_GET['year'];//年份
$cs4=$_GET['act'];//主演
$cs5=$_GET['pageno'];//页数
	$_var_63 = 5;
	$_var_60 = $_var_60 < 1 ? 1 : $_var_60;
	$_var_60 = $_var_60 > $_var_61 ? $_var_61 : $_var_60;
	$_var_61 = $_var_61 < $_var_60 ? $_var_60 : $_var_61;
	$_var_64 = $_var_60 - floor($_var_63 / 2);
	$_var_64 = $_var_64 < 1 ? 1 : $_var_64;
	$_var_65 = $_var_60 + floor($_var_63 / 2);
	$_var_65 = $_var_65 > $_var_61 ? $_var_61 : $_var_65;
	$_var_66 = $_var_65 - $_var_64 + 1;
	if ($_var_66 < $_var_63 && $_var_64 > 1) {
		$_var_64 = $_var_64 - ($_var_63 - $_var_66);
		$_var_64 = $_var_64 < 1 ? 1 : $_var_64;
		$_var_66 = $_var_65 - $_var_64 + 1;
	}
	if ($_var_66 < $_var_63 && $_var_65 < $_var_61) {
		$_var_65 = $_var_65 + ($_var_63 - $_var_66);
		$_var_65 = $_var_65 > $_var_61 ? $_var_61 : $_var_65;
	}
	if ($_var_60 > 1) {
		$_var_67 .= '<li><a  class="' . $css1 .'" title="首页" href="' . $_var_62 .'_' . $cs0 . '_' . $cs1 . '_' . $cs2 . '_' . $cs3 . '_' . $cs4 . '_1_1.html">首页</a></li>';
		$_var_67 .= '<li><a  class="' . $css1 .'" title="上一页" href="' . $_var_62 .'_' . $cs0 . '_' . $cs1 . '_' . $cs2 . '_' . $cs3 . '_' . $cs4 . '_' . ($_var_60 - 1) . '_' . ($_var_60 - 1) . '.html">上一页</a></li>';	
	}
	for ($_var_68 = $_var_64; $_var_68 <= $_var_65; $_var_68++) {
		if ($_var_68 == $_var_60) {
			$_var_67 .= '<li class="' . $css3 .'"><a class="' . $css2 .'" target="_self" class="on">' . $_var_60 . '</a></li>';
		} else {
			$_var_67 .= '<li class="' . $css3 .'" ><a class="' . $css1 .'" href="' . $_var_62 .'_' . $cs0 . '_' . $cs1 . '_' . $cs2 . '_' . $cs3 . '_' . $cs4 . '_' . $_var_68 . '_' . $_var_68 . '.html">' . $_var_68 . '</a></li>';
		}
	}
	if ($_var_60 < $_var_65) {
		$_var_67 .= '<li><a class="' . $css1 .'" title="下一页" href="' . $_var_62 .'_' . $cs0 . '_' . $cs1 . '_' . $cs2 . '_' . $cs3 . '_' . $cs4 . '_' . ($_var_60 + 1) . '_' . ($_var_60 + 1) . '.html">下一页</a></li>';
		$_var_67 .= '<li><a class="' . $css1 .'" title="尾页" href="' . $_var_62 .'_' . $cs0 . '_' . $cs1 . '_' . $cs2 . '_' . $cs3 . '_' . $cs4 . '_' . $_var_61 . '_' . $_var_61 . '.html">尾页</a></li>';
	}
	return $_var_67;
}
function ggetPageHtml($_var_60, $_var_61, $_var_62,$css1,$css2,$css3)
{
$cs0=$_GET['rank'];//火热
if($cs0=='')$cs0='rankhot';
$cs1=$_GET['cat'];//类型
$cs2=$_GET['area'];//地区
$cs3=$_GET['year'];//年份
$cs5=$_GET['pageno'];//页数
	$_var_63 = 5;
	$_var_60 = $_var_60 < 1 ? 1 : $_var_60;
	$_var_60 = $_var_60 > $_var_61 ? $_var_61 : $_var_60;
	$_var_61 = $_var_61 < $_var_60 ? $_var_60 : $_var_61;
	$_var_64 = $_var_60 - floor($_var_63 / 2);
	$_var_64 = $_var_64 < 1 ? 1 : $_var_64;
	$_var_65 = $_var_60 + floor($_var_63 / 2);
	$_var_65 = $_var_65 > $_var_61 ? $_var_61 : $_var_65;
	$_var_66 = $_var_65 - $_var_64 + 1;
	if ($_var_66 < $_var_63 && $_var_64 > 1) {
		$_var_64 = $_var_64 - ($_var_63 - $_var_66);
		$_var_64 = $_var_64 < 1 ? 1 : $_var_64;
		$_var_66 = $_var_65 - $_var_64 + 1;
	}
	if ($_var_66 < $_var_63 && $_var_65 < $_var_61) {
		$_var_65 = $_var_65 + ($_var_63 - $_var_66);
		$_var_65 = $_var_65 > $_var_61 ? $_var_61 : $_var_65;
	}
	if ($_var_60 > 1) {
		$_var_67 .= '<li><a  class="' . $css1 .'" title="首页" href="' . $_var_62 .'_' . $cs0 . '_' . $cs1 . '_' . $cs2 . '_' . $cs3 . '_1_1.html">首页</a></li>';
		$_var_67 .= '<li><a  class="' . $css1 .'" title="上一页" href="' . $_var_62 .'_' . $cs0 . '_' . $cs1 . '_' . $cs2 . '_' . $cs3 . '_' . ($_var_60 - 1) . '_' . ($_var_60 - 1) . '.html">上一页</a></li>';	
	}
	for ($_var_68 = $_var_64; $_var_68 <= $_var_65; $_var_68++) {
		if ($_var_68 == $_var_60) {
			$_var_67 .= '<li class="' . $css3 .'"><a class="' . $css2 .'" target="_self" class="on">' . $_var_60 . '</a></li>';
		} else {
			$_var_67 .= '<li class="' . $css3 .'" ><a class="' . $css1 .'" href="' . $_var_62 .'_' . $cs0 . '_' . $cs1 . '_' . $cs2 . '_' . $cs3 . '_' . $_var_68 . '_' . $_var_68 . '.html">' . $_var_68 . '</a></li>';
		}
	}
	if ($_var_60 < $_var_65) {
		$_var_67 .= '<li><a class="' . $css1 .'" title="下一页" href="' . $_var_62 .'_' . $cs0 . '_' . $cs1 . '_' . $cs2 . '_' . $cs3 . '_' . ($_var_60 + 1) . '_' . ($_var_60 + 1) . '.html">下一页</a></li>';
		$_var_67 .= '<li><a class="' . $css1 .'" title="尾页" href="' . $_var_62 .'_' . $cs0 . '_' . $cs1 . '_' . $cs2 . '_' . $cs3 . '_' . $_var_61 . '_' . $_var_61 . '.html">尾页</a></li>';
	}
	return $_var_67;
}
function get_channel_name($_var_41)
{
	$_var_42 = mysql_query('select * from yycms_vod_class where c_id=' . $_var_41 . '');
	if (!!($_var_43 = mysql_fetch_array($_var_42))) {
		return $_var_43['c_name'];
	} else {
		return '';
	}
}
function yycmsget($url,$timeout = 7) {  
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $url);
  curl_setopt($ch, CURLOPT_TIMEOUT, 12);
  curl_setopt($ch, CURLOPT_USERAGENT, _USERAGENT_);
  curl_setopt($ch, CURLOPT_REFERER,_REFERER_);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  $r = curl_exec($ch);
  curl_close($ch);
   return $r; 
}
?>