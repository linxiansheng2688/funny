<script type="text/javascript" src="publics/layui/layui.js"></script>
<script type="text/javascript" src="js/alllist.js"></script>
<script type="text/javascript" src="js/yycms.js"></script>