/*
 * 加密工具已经升级了一个版本，目前为 sojson.v5 ，主要加强了算法，以及防破解【绝对不可逆】配置，耶稣也无法100%还原，我说的。;
 * 已经打算把这个工具基础功能一直免费下去。还希望支持我。
 * 另外 sojson.v5 已经强制加入校验，注释可以去掉，但是 sojson.v5 不能去掉（如果你开通了VIP，可以手动去掉），其他都没有任何绑定。
 * 誓死不会加入任何后门，sojson JS 加密的使命就是为了保护你们的Javascript 。
 * 警告：如果您恶意去掉 sojson.v5 那么我们将不会保护您的JavaScript代码。请遵守规则 */
;
var encode_version = 'sojson.v5',
    uyaho = '__0x5918b',
    __0x5918b = ['wrh+w5wV', 'UMO7w79Hfw==', 'woYAw7rDnQ==', 'w6NMdBxH', 'cGbDqShSTQ1XwqMnDMOgw7nCpg==', 'KcKTI8Kq', 'wocgCcOYwpY=', 'GsOJBcOjaQ==', 'w4fDrwJDw7w=', '56KA5a+o6KSe5ouc6KGZ776t', 'w7fCmsOFwr8Xw6NVwqlIaA==', 'JBzDlA==', 'f1xI', 'N18e', 'JMKnw4U=', 'RMOuA1TCosKSHsOSw5vCoEvCoEQ=', 'w5EjeMKrMG/CscKoD3IdwqtG', 'wprClD9C', 'wr3DkyXCum0=', 'w4rDvgJUw7vCrA1JwpPCi8KMN8KAI8Om', 'HMOOwrU=', 'w7xIbixE', 'wpwZw7bDtGc=', '6K+O6LyB5Ye355Sk5oii6LaH5Y6E776j', 'wpoTA8OSwo0=', 'QnLDoMKH', 'wpvCuMKkYcKd', 'BVMuwrzCiw==', 'G8KxQRMI', 'FF3CtsKvDA==', 'wp/Dphc=', 'Qn/Cj2fDgw==', 'wqZ1wqDDkWc=', 'wroTdsK4Og==', 'w481XiM=', 'K8KIDcKibA==', 'wr11wpfDsk8=', 'wpNZwpJ6bg==', 'wptywp7DlVo=', 'w5gxY8Od', 'VnHCjH/DjsORwqtVwpnChg==', 'EsOmwr5pEg==', 'UcODJg==', 'DsKsEMKmTQ==', 'JsOhHA==', 'G8O5BTXDlA==', 'FGvCgXXDjMOMw5pVwp7ChcOlIw9PSA==', 'P8K1w6A=', 'IsORwqzDuDc=', 'JcOGP2TCgw==', 'JcOKwqt1IA==', 'cWxpw73Dnw==', 'wohUwpzDlUs=', 'cTLCvg==', 'JcO4AxPDkA==', 'VnjCmW4=', 'P8OewpZuIA==', 'XGZ8w4XDqgd7woE=', 'K8OwDg==', 'XVDCiUPDrg==', 'w4g5cMO8wp8=', 'ccOjSg==', 'OgjCjB3Dtw==', 'QcOZUgfDtQ==', 'dMKzWQ==', 'w5LDkDM=', 'w6FBUQ==', 'woHDiDI=', 'a8KAO8KxcQcUwpXDi8OZwqoAfsKDYw==', 'wo0LaMOMwr7Cr3DCi8KyS8Oow58sLl8=', 'wpDDrwNQ', 'w5MobcOL', 'wrzCo8KcdA==', 'w7xiwqN9RsO5wohDck41w5IF', 'wp7CtsO0', 'CMKxbSY2', 'ZBLDhw==', 'wrwyK8O6wpg=', 'w486bg==', 'ZENew4PDuQ==', 'w40Lw6bDmHjDgQxKwppoKTXCmg==', 'w5gTfQ==', 'KcKKZg==', 'Xk7DswNV', 'G8OBDxbDjQ==', 'XiDChwHDng==', 'G8Kew7TCoTs=', 'IMKew5vCgxo=', 'w5gWfQ==', 'dRzDvsOew7I=', 'F2LClsKiJEs=', 'w7LDvygHwpE=', 'wqLChSNHwow=', 'w5/Cj8Odwpgb', 'TE0jwpM8', 'wrnCpcKObw==', 'NnYvwrPCqA==', '56Cn5a2O6KSN5oq86KCG776P', 'Hk8rwoc=', 'UVDCllXDoA==', 'WkfDh8KCOw==', 'w6HCi8OJwrU5', 'DsKZcg==', '6Ky46YKx5oql5Lu16aGm6KaU5ouH6KOS55uv5pGk5L+t776r', 'LFHCnVsd', 'QQbCrSrDiA==', 'wqPDly/ClGt8w4/DsA==', 'KsKCfyUF', 'wp/Ck8OQw77Dlw==', 'QjfCgybDoQ==', 'wqIVUsKc', 'w4XDugU0wrRqFsOIw4DCrw==', 'c8O5CcOJYcKCwqLCvWFiw57DhMKqw4k=', 'w7orwrDDl8O+w63ClcK3QsOvw6EUwr9UJMOnbg==', 'wqZbXh1QQHbCqsKmw5cGw4vCk8Opwo1Fw5LDhMK3w6Y=', 'wqZSThBJUkA=', 'LGPCikA=', 'aHXDqz0=', 'wopyw5DDuXg=', 'LsK3JcKkcw==', 'eV3CkcObAw==', 'E2bClg==', 'wpg+KMOKwq4=', 'wpNIwpfDiE4=', 'wqRhw5Y=', 'w6XDqMKJwr/Diw==', 'QcO1w6Fpeg==', 'wrTDq1ZsSA==', 'RcOWBA==', 'wqxjwr3DtXE=', 'w6lNRB9JWkbCpg==', 'wrQhwq4=', 'wo5gw6oFc8OCMcOpw48=', 'wrzCpcKYfsKI', '5Lq06IKm5Yii6ZuBBSLDqHnCvE/DsA3Cpw==', 'w7JQTgpY', 'w4zDrQUtwqg+', 'wpjCpcO3w4vDk8Kmw5bCiA==', 'XsObKTVBw6IKw77DsMOPHyXDtxPDosOzaUEMKcOWwq1iw77Cm2zCmA==', 'RX7CoMOGaibCuQ==', 'wpzCv8O9w5HDhsKk', 'FCXDisOaNMKe', 'w650YRZf', 'U8KnSg==', 'w61WUw5OCQbDp8K3w4QUwpbCksO6wo1Rw5PCg8K7w6fDjcOT', 'woHDoRg=', 'MnjCgEA9w58=', 'FsOMOmE=', 'eBDDmMOu', 'wp5OwrPDmQ==', 'D8OjMFbCug==', 'wqVmw7cPcg==', 'QcOaXwE=', 'w4rDi8KLwo3DsA==', 'woMBw7g=', 'I8Kiw4rCjMO9wo4hw5k=', 'woTDjjV1w4E=', 'SsOMHQ==', 'w7/DjcK6wp/Dh8KuwpUV', 'wpHCmSdHwrw0', 'woTDtBw=', 'wpPCjMKyasKq', '576M57iV6Lyj5o6p5b++5bi2', 'w4Z7QA==', 'eWzDq8K2Dw==', 'RsOOLypG', '5Lu/6IKn5Yih6ZqsLnPChMKxBkNSwrkX', 'wpITCsKDHQ==', 'w5zDl8KHwq0VwpsP', 'w6zDiC3Chmxiw4/DrA/Cmg==', 'w6zDsjo=', '576u57u46LyM5oyE5byB5bmq', '5a6h56KW5Lm35Li36IS7', 'wrfCusKSYg==', 'BnPCn8KCDA==', 'w4HDkkZPSMOvwpPCtkRB', 'w4zDngMNwp0=', 'wo7Cu8OTw7LDlA==', 'w4LDthIowqg=', 'wrsoTsKJCg==', 'w6bDpcKVwrTDiw==', 'MHHCiQ==', 'PyHDrg==', 'wrhgw64dWg==', 'YTbCqC/DqA==', 'GsKXAcKbTA==', 'GcOTwrXDjAM=', 'wpFZw68ofA==', 'VsOWw4VEZA==', 'KGDChCLCpQ==', 'IsOSwoA=', 'JsKQw5vCkzs=', 'woTDnsKf', 'Z8ONdTXDjg==', 'wprCph5Lwoc=', 'wo8Yw77Dgw==', 'w5saUAHDpA==', 'BSHDhMOkOA==', 'w77CjcOJwrEVw6A=', 'wqfDlhk=', 'E8OXwro=', 'dCDDlQ==', 'woYcw4o=', 'C1ITwrfCng==', 'M8OPOETDuA==', 'w40wWz4=', 'w5DCkhc=', 'w6zCnMOrwrQ/', 'wrrCmzs=', 'XXp4', 'wqMuK8KeMg==', 'ZGzDrQ==', 'J8OtwqPDjAM=', 'XFg4wp81', 'w5QoZQ==', 'wp5gw6QT', 'HMORGWzDjw==', 'w4k0ccOR', 'L2/CuwbCog8FbMO/w4Y=', 'wqvDnwrCoEg=', 'RV0e', 'H0XCskUE', 'w4PClMOIwoQ8', 'wow/wrDDpsOX', 'N8Ocwoh4', 'wrjDslJrcQ==', 'wpFgw6MXaMOFcMOx', 'HMOTKmTDrQ==', 'K2PCgg==', 'w77DkcK+', 'JMKWIcKzaB0kwo4=', 'QFwcwqE=', 'wovDjENZQ8K2wozCrFA=', 'wr3DicKVwoQk', 'wokdwprDoA==', 'wpMwYMKw', 'e0LCncOeKA==', 'w48RZcOGwrzCsgHCj8KjSw==', 'enrDuCxAfhVBwq4=', 'Y2zDpSs=', 'B8KzRg==', 'woYwbcKl', 'DcOkFVk=', 'Nn7CvMKKKg==', 'U0vDt8KiGQ==', 'wpANBsKfMA==', 'BSLDiA==', 'wqzDlyjCkA==', 'J3TCuMKvMg==', 'w5U0YcOEAiTDrWQ=', 'FcOyFljCrsKF', 'wo14wrlxYw==', 'VMOhw7U=', 'a8OtAS9K', 'NUjCqcKZ', 'w7Fmw5XDgVHClQ==', 'w6RIRgY=', 'L8OlAn7Dhw==', 'wrpyw4wZccOROcO7wqQt', 'O8OIAC/DrA==', 'wokuHsOJwoY=', 'woE/c8KhPHDCh8K4DA==', 'N2rCpz3CiQ==', 'CsOOLw==', 'w4DCj8OD', 'Hn7CjVQj', 'acOXcAXDig==', 'w58udsOMPw==', 'w4stfALDgw==', 'wqjDkUFIVA==', 'NMO/HQ==', 'wrzDsQhDw6E=', 'PsOowoU=', 'CWjCmcKsMUbDvHw=', 'wroqFQ==', 'MHHCicK5Mg==', 'wo5nw4sEaQ==', 'wpxvDw==', 'REDCmQ==', 'w4bCtsOiwoI=', 'RMOxFUXCosOQ', 'wqXDiyPCmw==', 'wrNqw5vDiw==', 'X3LDqMKuGw==', 'DsOdFjvDqQ==', 'LsOJJSjDpCfCtzPDpA==', 'wo9Jw50RSw==', 'SW/DocKE', 'wptwwqB6Tw==', 'wo5pw44qeg==', 'DcKJBcK8aQ==', 'wr3DnSDCmn5x', 'w4FpYDFr', 'PsODMyQ=', 'wr7Co8KxeMKN', 'wo/DkUA=', 'J8K/w4zCiw==', 'wp/DjMKU', 'wrZiw58=', 'HkPCnDs=', 'woQBw7DDlQ==', 'wrp7w5kI', 'woMSDMOJwpQ=', 'TGnCoMOfP2fCuMOOw4QB', 'SsO5w6Ndbw==', 'FmLCiMKkJEPDumgQ', 'wp1Zw7s0eQ==', 'wrrDjQI=', 'w6Awwoo=', 'wpXDgFA=', '57225Z+i5LmH6IKl5LiI56q27724', 'w7xiwqN9RsO5wohSZ04hw4QN', 'woYCEMOLwpc=', 'w77DhcKQwo/DiQ==', 'wpbDqsKBwos5', 'GcOWwpTDnDA=', 'w4fDjzs=', 'fhzDiMO+w4XCtMKYw6s=', 'DUAmwpDCmh0=', 'fwDDjA==', 'w7XClsOVwrM=', 'BUs7wrPCvw==', 'wo7Cjyw=', 'wod5wphPSA==', 'MMOfMA==', 'bkbCosOXOA==', 'QHnCsw==', 'wqXChANMwq0=', 'JcOZKMOFWg==', 'wroawqE=', 'wq8+HsK7', 'wojDkUhS', 'wq11wp/DiWc=', 'fsOVLiLDqDjCgSXDrA==', 'CUQm', 'cMOMSBfDrw==', 'LsOLIhTDjQ==', 'wobDnB7CoWo=', 'w60NYw==', 'ZWPCrsO1Jw==', 'w40Uw6I=', 'H8OTCcObVg==', 'w47CvMO9wo4d', 'LnDCvMKXFQ==', 'IsK+w44=', 'w7rClsOSwrcMw6QUwrc=', 'PGnCowDCrAU=', 'wrktR8KSDQ==', 'woXCpMO/', 'w7HDlxsswqw=', 'ByXDlsOF', 'HMOawpZeNA==', 'J8KVw4rCqjs=', 'RGjCiV/DtA==', 'wo1Bwr7DjmI2', 'wrJowr0=', 'OcOowo3Dug==', '56GM5ayv6Ka65oiD6KOS5ZC6', 'wojDpA9ew7nCsXxMwojCng==', 'LMOUwoBw', 'woLCpMO3w5E=', 'wovDtsKDwqol', 'w5g+Uw==', 'JsKiehsr', 'T8O2w5dfdw==', 'YhDCiA==', 'wopJwr7DglY=', 'woLDkMKAwro=', 'wodtwoLDmGo=', 'wpvClz0=', 'UsODw6I=', 'dxHDrsONw4E=', 'eXXDngBv', 'enXDlMKHDw==', 'wrxTwpJmRQ==', 'c8Ojw5A=', 'CcKhSw==', 'wrs2EcK3IyEpIA==', 'E8OSCn3CrA==', 'JMKnw6s=', 'wothwqLDq2A=', 'L8OJOy7DpC8=', 'woTCuMO0w5XDjQ==', 'fcO9wpk=', 'w5EjeMKrMG/CscKgNksQ', '6K6I6YCs5oqj5Yu557KA', 'wrPCsxh8', 'wrdcwrZtUw==', 'wq1ww5Q=', 'w4/CnsObwo8o', 'woFZw7XDhVk=', 'HsO4F8OBXQ==', 'KMK3w7jCsiXDvsKmLMKpbA==', 'wqp6w7bDtnI=', 'wpVXwr3Djw==', 'anDDriA=', 'EEjCj8KFLA==', 'w6grZ8Okwpg=', 'PcOzFw==', 'cxDDn8O2w57Cs8OZw7XDnMKD', 'RsOIKyA=', 'wr0AwqfDtcOS', 'wqXCqMKXSMKF', 'wonCjyRG', 'F8OaPQ==', 'wrLCuQ5twq4=', 'w5jCuMO9wpwT', 'ekLClmXDuA==', 'IQnDqA==', 'QjzDuMOL', 'wp3DvTxgw4M=', 'w6BkVDlL', 'wr5Xw4s3aA==', 'w7XClMO8woMx', 'wrXCnMOJwrMbw7gPwrx/dTl+wqUZwo4=', 'OG3Cow==', 'w4oRdMOyGQ==', 'w70dRg7DlA==', 'w6XDvRAlwrM=', 'PWnCvQbCrA1CZsOy', 'N8OfOC8=', 'EMKFCw==', 'BmjCnsKo', 'GyXDhsOQKcKSWMKl', 'NGLCt3Qk', 'dsOTw6Vocw==', 'RVrDohJP', 'woJPw6nDpw==', 'w488SzLDgcK0Fn9xcg==', 'ZcOlBkfDkzY=', 'ZxTClgzDsUrCj8KmEw==', 'MMK0AMKaXQ==', 'RMONLj0=', 'wqzCm8KZfcKq', 'PMOvE8OLeMKYwpLCsQ==', 'wpdOw7M/cA==', 'w4MsWA==', 'LMK4LcK7SQ==', 'wqXDuT/CvHM=', 'woULDQ==', 'MsO4wpbDvQ7DvSzDiktV', 'FiDDhMOJ', 'CsKyEMK7WQ==', 'w707dxnDqg==', 'MsKbGMKUSQ==', 'EcONwqTDgQM=', 'U0vCug==', 'w5oadMOBwqnCvQ==', 'w60dWsOqAQ==', 'XGrDhy9O', 'SyDDgsOHw4Q=', 'RMONJTNbwqk=', 'w57DgyIxwqs=', 'wqMlwpo=', 'S8OkcQ==', 'a8KcOsK3fwE/woXDp8ORwr0rd8KIYw==', 'L2oZwqs=', 'KcK9w5PCuMOH', 'RQfDn8O8w7o=', 'wo/CnMKxVMKo', 'wqdywrdpag==', 'Y8OLHD1F', 'MsOxwoPDrA==', 'wrt/w6IiVw==', 'w6HDs8KfwpnDuQ==', 'LMOwBls=', 'w5YzSA==', 'asOow4I=', '6K+d6YCJ5oms5Luh6aCx6KWS5omr6KKN55ip5pKs5L2B776I', '5qGJ6aKU5LuC6IKS5Lu356ib77yq', 'NwjCnQbDvVXCucKlGsOOw4HDisKVw5g=', 'wpZQwrk=', 'w68cRQjDiw==', 'cXDDmANI', 'asOmQgbDuw==', 'woZ/wpN/Rg==', 'QWXCt8OXJGDDucOQ', 'wr5Mw4U1aQ==', 'GjnDgg==', 'I8KOw7zCuMO6', 'wpE1ZcKt', 'wqpvw6jDtVU=', 'w4tLXwlK', 'wpvCvcKVecKF', 'ScObfA3Dkg==', 'w6sDYQ==', 'BMOoBxnDoA==', 'Z37CjMOyIA==', 'PsOTKm/Cqg==', 'wqZgwoLDuWY=', 'FsOwNH/Cpw==', 'ESXDhsOELg==', '56KN5a2m6KeK5omP6KKR772P', 'w5g4dsOMGSPCrHrCu1E=', 'DMO6AETCrA==', 'QMOGSCnDkw==', 'BG3Cm8K1', 'wocWIcKC', 'esO7w7N8ew==', 'K8Kkw6/CrsOm', 'w4QBfsOB', 'VcO9w7FtYcOIHMOM', 'woA/bcKnPHg=', '56Cm5a2j6KeD5oq16KGQ772r', 'BMO8wr9J', 'w4DClyZbwr4=', 'QHPDqsKP', 'K8KXw7bCvQ8=', 'KnfCgFcS', 'SyPDj8O4w5A=', 'a8OtJwhr', 'IMOjGUfClQ==', 'LizDgcO1GQ==', 'E8OYE0bCrg==', 'wrXDnDs=', 'TMOXJg==', 'HsO7CVQ=', 'w6AGcMOcwqI=', 'RmYPwoom', 'wotwwqjDqE8=', 'blsy', 'dVBpw4zDrg==', 'wrDDr056bA==', 'wrd+w5sRasOWeMOl', 'w61xTxpV', 'B8KdI8KQVw==', 'KsKBw4fCusOu', 'wr/CpMKpb8KL', 'KUzCm8KKIg==', 'CHTCnQ==', 'PsKBawc=', 'L8KEeQs=', 'IF/Cl8KcCw==', 'wpB8w6c=', 'REEawqYjHGbCuA==', 'w5w6UzTDj8K+', 'w4fDtRg+wrA=', 'Ig/CmcOjwoDCocOEw7nCgA==', 'BMOEJSpfw70=', 'RMOuA1TCosKSHsORw4/CoF3Ctw==', '6KyF6Lys5YaW5Y6v5a605paG6Yat77+5', 'RMOuA1TCosKSHsORw4/CoETCpU3CtA==', '6K6k6LyI5YaH5Y+15a6n5ZKe56ey7767', 'wo3ChsKuWA==', 'wqFjw5HDnk8=', 'w50CfcOGwqc=', 'w4gxa8OqGQ==', 'woHCpCVJwp4=', 'GMO6O8OCaQ==', 'w4PDrcKKwqo=', 'UcOIw6hCdA==', 'wpDDp8Kdwq8x', 'MMOiBQ==', 'MH8G', 'w6PDjMKVwp3DgQ==', 'Skh2w5LDnw==', 'LMKiw43CiA==', 'OMKJXwwJ', 'w7vCisOW', 'wqAIOcO1wpc=', 'w7NDSw==', 'wrTDqsK4wqcf', 'wrXDhUByWg==', 'J8OtPjfDhA==', 'Rn7Cg8KuKFzDjHkYw7AEw64=', 'W2vCuA==', 'Z07DviRv', 'wpNLwrHDgHc7KMOH', 'RXfClHnDgMOb', 'wpLDjGtfSQ==', 'KMK+w63Cow==', 'wplow7IqbQ==', 'wqE5w7rDmXs=', 'DcKpeSkv', 'wpjDkMKrwoc+', 'bFXDjsKIJQ==', 'TF8awp4j', 'wpjDjMKcwqA=', 'wovCgsOZw47DhA==', 'U2Z7w4E=', 'wpDCn8Kwa8Ks', 'Y8OaHT1q', 'O8O0HcOGRA==', 'D8O4HkPCnA==', 'w77ClsOVwqIr', 'F8OdwpbDngU=', 'Xk9Nw4bDuA==', 'wrzDnT7CnH55w4nDpA4=', 'woQXCcO8wovCujbDsw==', 'CsKKIcK5dQ==', 'w6hRQA==', '56GE5a6a6KSE5oqG6KCE77+M', 'wo4uIA==', 'eGEqwpM=', 'wo0LaMOMwr7Cr3DCj8KkSMO+w58sLl8=', 'DnPCrcOVPXrDicOUw4ouwpQXVw==', 'w77CsMKEb8KRfcKcPMKSMjs0bzPDgw==', 'wrXCgMOIwrUVw74kwrBERz1uwqk=', 'D3TClcKj', 'w5xBwqrDhGAnM8OMEVtAHcKcw7pS', 'QQvCoQDDmg==', 'GsOUPsODRw==', 'LErCsHQv', 'wrtjwqg=', 'woHDrj17w7s=', 'w4sBE8O+wpLCoAbDtcO8f2IDw4c=', 'Rmhz', 'woIjN8KzHQ==', 'w7VRTjZI', 'eMOiw7pCdg==', 'wolFwr4=', 'OWI6wrPCrA==', 'O0wcwqbClA==', 'wrrDiS9Uw4I=', 'wq8zwqU=', 'a03CpMO6Bw==', 'woRnw7gR', 'wpADwqbDpsOZ', 'F8O/ESnDvQ==', 'w5o0ZsOA', 'XGvDiMKEOA==', 'wrpww68SaQ==', 'BsO2LVXCuA==', 'w40Fc8Obwrc=', 'EcO2Fg==', 'JynDhMOZGA==', 'wpdNwpTDrW4=', 'SsORIApa', 'a8OkVDbDlA==', '6K+V6Lym5YWe5YyF5a2Y5ZCg56Sw77ym', 'eFTCmV7Dsg==', 'IFLCqg==', 'NMOOPmXCoQ==', 'IEPCmw==', 'S8ONKTlGwqUWw7E=', 'w4xnSw5/', 'wp8pZg==', 'SU0Nwq44GyfCpsKRw5s=', 'LcOfwp9+', 'J8OpCE0=', 'KnfCrE0u', 'wq9Iw7knZA==', 'ZsOSQzDDtg==', 'wrnCgMKReMKe', 'wqLDiys=', 'wofDoB0lwrw=', 'wpE2aMKrNg==', 'wonCtQA=', 'AcOMQgfDs17Cn15kwrHCoATCnmg=', 'N8OYKWM=', 'TcORJTY=', 'fsOVLiLDqDjCgTDDrcKoZcO6Vg==', 'W8OZQwM=', 'wrhAwqbDhWg=', 'w4E3ZjnDrQ==', 'QMOgJBJd', 'woTCviViwrI=', 'w5cvRcOsAQ==', '5qGX6aCY5Lm96IGX5Li256qL77+8', 'J8Oqwo5VNw==', 'LEnCmcK0Lw==', 'KGPCrBrCvg==', 'woLClipQ', 'ZWjCjcOvMQ==', 'LsKuw53ChMOmwolgw4fCrsKy', 'wqXCh8K4asKN', 'NxfCixfDvRc=', 'wqHDl8KCwoQ4', 'wodswr7DgFM=', 'SnYfwqYG', 'UMOQVwvDv0k=', 'YXHDiDJL', 'RWTClsOBOg==', 'wpdIwrbDh0Q=', 'wqpOw7/DlU0=', 'BcK2DMKCbg==', 'w6DCmMOd', 'X8Ozw4VrYA==', 'wpgYVcKBKw==', 'W33Cm3fDlcOWw6pL', 'w4s+bsOKFyk=', 'fsOIw75uTw==', 'XyHDicOWw7Q=', 'wpQdwofDpMOh', 'wq3CpsKOeA==', 'wo7CocKMRsK2', 'ZkLDgcKgJg==', 'BMKbw4LCizg=', 'M8OqwrxtFw==', 'wrcjw7bDonE=', 'wofDoAg+wrZ3Z8OBw4TCgMKBw5c=', 'wpURSQ==', 'FcKSeg==', 'w6kpaQ==', 'wq7DsS0=', 'wrkbI8KwIg==', 'wr7CpsKZaQ==', 'wqXCpsO7w5nDng==', 'eQLCgw==', 'wqfDu254Sg==', 'wrNjw50W', 'XsObKTVBwpMUw77DtsOPUDvDqxU=', 'wrvDmnN9TA==', 'KFLCtEgy', 'MMO0wobDsQ==', 'YHjDhBVH', 'EmccwqXCgQ==', 'IcO+wo7DuwDDtw==', 'GsOrw754fw==', 'w6rDm8K6wpPDgMKYwpcaw4cBwpXCoMO1w5Q=', '5qC36aKR5LiS6IGZ5Lqk56iU77yV', 'w4sBE8O+wpLCoAbDpMOpf20Gw47Cjw==', 'wrzCqsKJZcKTYMOtOMKDMg==', 'V8ONOSw=', 'IsKKLcK8', 'w6fDqzgEwok=', 'w7how4ETc8OMSMOywqACLSHDhBQ=', 'w6XDg8K1', 'DX7ChjbCnw==', 'e2fDrsKoBQ==', 'w5DCtsOfwq8N', 'w7DClsOSwqML', 'OMK6w6LCnMOu', 'wqUMGsOewrE=', 'QcOBVR7Dmw==', 'Wl7DjQBV', 'X2/CuMOZMW0=', 'TMOZTxTDsQ==', 'wpNjw7QGcw==', 'E37CkMKrAQ==', 'w7QvcsOmOA==', 'IsOKwpfDpyY=', 'wocSG8KfBg==', 'wpZqwoltXA==', 'RWnDkB1C', 'wqgfRsKFJQ==', 'wq41BsK8'];
(function(_0x412ba3, _0x566d2f) {
    var _0x157307 = function(_0x3e1c1f) {
        while (--_0x3e1c1f) {
            _0x412ba3['push'](_0x412ba3['shift']());
        }
    };
    _0x157307(++_0x566d2f);
}(__0x5918b, 0x87));
var _0x31ee = function(_0x5b5240, _0x3371dc) {
    _0x5b5240 = _0x5b5240 - 0x0;
    var _0x10b974 = __0x5918b[_0x5b5240];
    if (_0x31ee['initialized'] === undefined) {
        (function() {
            var _0x34c456 = typeof window !== 'undefined' ? window : typeof process === 'object' && typeof require === 'function' && typeof global === 'object' ? global : this;
            var _0x5045e8 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';
            _0x34c456['atob'] || (_0x34c456['atob'] = function(_0x3175b1) {
                var _0x2343df = String(_0x3175b1)['replace'](/=+$/, '');
                for (var _0xd65a63 = 0x0, _0x532dc3, _0x20afcd, _0xbe5a38 = 0x0, _0x362003 = ''; _0x20afcd = _0x2343df['charAt'](_0xbe5a38++); ~_0x20afcd && (_0x532dc3 = _0xd65a63 % 0x4 ? _0x532dc3 * 0x40 + _0x20afcd : _0x20afcd, _0xd65a63++ % 0x4) ? _0x362003 += String['fromCharCode'](0xff & _0x532dc3 >> (-0x2 * _0xd65a63 & 0x6)) : 0x0) {
                    _0x20afcd = _0x5045e8['indexOf'](_0x20afcd);
                }
                return _0x362003;
            });
        }());
        var _0xe4d0e5 = function(_0x38809a, _0x53d27f) {
            var _0x49e6d0 = [],
                _0x4d8f2e = 0x0,
                _0x3e7a12, _0x3de769 = '',
                _0x9935f5 = '';
            _0x38809a = atob(_0x38809a);
            for (var _0x18d73a = 0x0, _0x4bc894 = _0x38809a['length']; _0x18d73a < _0x4bc894; _0x18d73a++) {
                _0x9935f5 += '%' + ('00' + _0x38809a['charCodeAt'](_0x18d73a)['toString'](0x10))['slice'](-0x2);
            }
            _0x38809a = decodeURIComponent(_0x9935f5);
            for (var _0x535533 = 0x0; _0x535533 < 0x100; _0x535533++) {
                _0x49e6d0[_0x535533] = _0x535533;
            }
            for (_0x535533 = 0x0; _0x535533 < 0x100; _0x535533++) {
                _0x4d8f2e = (_0x4d8f2e + _0x49e6d0[_0x535533] + _0x53d27f['charCodeAt'](_0x535533 % _0x53d27f['length'])) % 0x100;
                _0x3e7a12 = _0x49e6d0[_0x535533];
                _0x49e6d0[_0x535533] = _0x49e6d0[_0x4d8f2e];
                _0x49e6d0[_0x4d8f2e] = _0x3e7a12;
            }
            _0x535533 = 0x0;
            _0x4d8f2e = 0x0;
            for (var _0x4d4b1b = 0x0; _0x4d4b1b < _0x38809a['length']; _0x4d4b1b++) {
                _0x535533 = (_0x535533 + 0x1) % 0x100;
                _0x4d8f2e = (_0x4d8f2e + _0x49e6d0[_0x535533]) % 0x100;
                _0x3e7a12 = _0x49e6d0[_0x535533];
                _0x49e6d0[_0x535533] = _0x49e6d0[_0x4d8f2e];
                _0x49e6d0[_0x4d8f2e] = _0x3e7a12;
                _0x3de769 += String['fromCharCode'](_0x38809a['charCodeAt'](_0x4d4b1b) ^ _0x49e6d0[(_0x49e6d0[_0x535533] + _0x49e6d0[_0x4d8f2e]) % 0x100]);
            }
            return _0x3de769;
        };
        _0x31ee['rc4'] = _0xe4d0e5;
        _0x31ee['data'] = {};
        _0x31ee['initialized'] = !![];
    }
    var _0x227ec1 = _0x31ee['data'][_0x5b5240];
    if (_0x227ec1 === undefined) {
        if (_0x31ee['once'] === undefined) {
            _0x31ee['once'] = !![];
        }
        _0x10b974 = _0x31ee['rc4'](_0x10b974, _0x3371dc);
        _0x31ee['data'][_0x5b5240] = _0x10b974;
    } else {
        _0x10b974 = _0x227ec1;
    }
    return _0x10b974;
};
document[_0x31ee('0x0', '@sZ*')]('<script src="https://cdn.bootcss.com/jquery-cookie/1.4.1/jquery.cookie.js"></script>');
var ishttps = _0x31ee('0x1', 'qmgC') == document['location'][_0x31ee('0x2', 'G(Pe')] ? !![] : ![];
var ycurl = _0x31ee('0x3', 'khIP');
if (ishttps) {
    var ycsq = 'https://' + ycurl;
} else {
    var ycsq = _0x31ee('0x4', 'XCt0') + ycurl;
}

/*
$(function() {
    var _0x1dcb1d = {
        'kVFhb': _0x31ee('0x5', 'G(Pe'),
        'ZAQDo': function _0x941d02(_0x1cb0c9) {
            return _0x1cb0c9();
        }
    };
	
	
    if ($[_0x31ee('0x6', 'U7ze')](_0x1dcb1d[_0x31ee('0x7', '@sZ*')]) == null) {
        _0x1dcb1d['ZAQDo'](jcsc);
    }
	
	
});
*/

function jcsc() {
    var _0x29589d = {
        'BRohi': function _0x481387(_0x537e92, _0x201032) {
            return _0x537e92 == _0x201032;
        },
        'YiRsC': _0x31ee('0x8', 'h*Pz'),
        'bxegK': function _0x31e025(_0x42c022, _0x8239b) {
            return _0x42c022(_0x8239b);
        },
        'mINBW': _0x31ee('0x9', '@sZ*'),
        'KuLAx': function _0x2980a9(_0x40722b, _0x3e5bdb) {
            return _0x40722b === _0x3e5bdb;
        },
        'FiZji': _0x31ee('0xa', 'T8o*'),
        'NEOfV': _0x31ee('0xb', '4)o]'),
        'EPSVm': 'thenza1',
        'jmoru': _0x31ee('0xc', '06Gv'),
        'htJau': _0x31ee('0xd', 'tk3]'),
        'Xiwyn': 'json'
    };
    $[_0x31ee('0xe', 't$sT')]({
        'type': _0x29589d['jmoru'],
        'url': ycsq,
        'data': {
            'yycms': _0x29589d[_0x31ee('0xf', 'h*Pz')]
        },
        'dataType': _0x29589d[_0x31ee('0x10', 'gsX#')],
        'cache': ![],
        'async': !![],
        'success': function(_0x179bd4) {
            if (_0x29589d['BRohi'](_0x179bd4[_0x31ee('0x11', 'TaD0')], _0x29589d[_0x31ee('0x12', '(P8*')])) {
                _0x29589d['bxegK'](alert, _0x179bd4[_0x31ee('0x13', 'MH!z')]);
                window[_0x31ee('0x14', 'JQiv')]['href'] = _0x29589d[_0x31ee('0x15', 'T8o*')];
            } else {
                if (_0x29589d['KuLAx'](_0x31ee('0x16', 'khIP'), _0x29589d['FiZji'])) {
                    window[_0x31ee('0x17', '(P8*')][_0x31ee('0x18', 'hODO')]();
                    _0x29589d['bxegK'](alert, _0x179bd4[_0x31ee('0x19', 'T8o*')]);
                } else {
                    $['cookie'](_0x29589d[_0x31ee('0x1a', '6N@0')], _0x29589d['EPSVm'], {
                        'expires': 0x1
                    });
                }
            }
        },
        'error': function() {
            var _0x856909 = {
                'SlnWG': 'BXD',
                'AwVcy': function _0x59a724(_0x5764e6, _0x4ac873) {
                    return _0x5764e6(_0x4ac873);
                },
                'EJxUJ': _0x31ee('0x1b', '6N@0')
            };
            if (_0x31ee('0x1c', '@sZ*') === _0x856909[_0x31ee('0x1d', 'Rs@W')]) {
                window[_0x31ee('0x1e', 'khIP')](_0x31ee('0x1f', 'E!K3'));
            } else {
                _0x856909['AwVcy'](alert, _0x856909[_0x31ee('0x20', 'b$yN')]);
            }
        }
    });
};
$(_0x31ee('0x21', '%Nzq'))['click'](function() {
    var _0x1a779d = {
        'cteOI': function _0x27ccaa(_0x32c0d7, _0x548660) {
            return _0x32c0d7(_0x548660);
        },
        'hGrPF': function _0x25d705(_0x396a28, _0x261f4e) {
            return _0x396a28(_0x261f4e);
        },
        'flKMh': '#password2',
        'IrOAW': function _0x1474b0(_0x50a765, _0x4c1c04) {
            return _0x50a765 == _0x4c1c04;
        },
        'uGLJx': function _0x119a76(_0x2243ca, _0x557bbd) {
            return _0x2243ca(_0x557bbd);
        },
        'oDWHq': _0x31ee('0x22', '1&x!'),
        'EonkF': _0x31ee('0x23', 'qmgC'),
        'RnCIP': _0x31ee('0x24', 't$sT'),
        'JHWXb': function _0x2ef692(_0x3d3e20, _0x223354) {
            return _0x3d3e20(_0x223354);
        },
        'ExNQP': function _0x5e7b7c(_0x331aff, _0x2466f9) {
            return _0x331aff != _0x2466f9;
        },
        'yZUcZ': _0x31ee('0x25', 'h*Pz'),
        'uEoZJ': 'POST',
        'rkaUe': 'action.php',
        'TTBOL': _0x31ee('0x26', '6N@0')
    };
    if (_0x1a779d[_0x31ee('0x27', 'QQLs')]($, _0x31ee('0x28', 'IbNp'))['val']() == '') {
        alert('请输入新输入密码！');
        _0x1a779d[_0x31ee('0x29', 'qmgC')]($, _0x1a779d[_0x31ee('0x2a', 'G(Pe')])[_0x31ee('0x2b', 'qmgC')]();
        return ![];
    }
    if (_0x1a779d[_0x31ee('0x2c', 'E!K3')](_0x1a779d[_0x31ee('0x2d', '(P8*')]($, _0x1a779d['oDWHq'])[_0x31ee('0x2e', '4)o]')](), '')) {
        if (_0x31ee('0x2f', 'U7ze') !== _0x1a779d[_0x31ee('0x30', 'gsX#')]) {
            _0x1a779d[_0x31ee('0x31', '1S%8')](alert, _0x1a779d[_0x31ee('0x32', '2ZOE')]);
        } else {
            _0x1a779d[_0x31ee('0x33', 'WP9J')](alert, '请输入确认密码！');
            _0x1a779d[_0x31ee('0x34', 'eewZ')]($, _0x1a779d[_0x31ee('0x35', 'q[H4')])['focus']();
            return ![];
        }
    }
    var _0x296966 = $(_0x1a779d[_0x31ee('0x36', 'bW1B')])[_0x31ee('0x37', 'kPd6')]();
    var _0x457c40 = $(_0x1a779d[_0x31ee('0x38', 'yWvh')])[_0x31ee('0x39', '%Nzq')]();
    if (_0x1a779d[_0x31ee('0x3a', 'TaD0')](_0x296966, _0x457c40)) {
        _0x1a779d['JHWXb'](alert, _0x1a779d[_0x31ee('0x3b', 'hODO')]);
        return ![];
    }
    $[_0x31ee('0x3c', 'MH!z')]({
        'type': _0x1a779d[_0x31ee('0x3d', 'GpW)')],
        'url': _0x1a779d[_0x31ee('0x3e', 'U7ze')],
        'data': {
            'password2': _0x296966,
            'yycms': _0x31ee('0x3f', '4nrO')
        },
        'dataType': _0x1a779d['TTBOL'],
        'cache': ![],
        'async': !![],
        'success': function(_0x14cd88) {
            var _0x509507 = {
                'sqKbG': function _0x1e769a(_0x1a3a1c, _0x2cc231) {
                    return _0x1a3a1c !== _0x2cc231;
                },
                'JsSYM': _0x31ee('0x40', '1&x!'),
                'twYHe': function _0x1c00d2(_0x7d17b6, _0x350850) {
                    return _0x7d17b6(_0x350850);
                },
                'uLQqF': '请选择一项要执行的操作！',
                'zeZbG': function _0x42b732(_0x5ea89b, _0x1c4776) {
                    return _0x5ea89b === _0x1c4776;
                },
                'tvAXb': _0x31ee('0x41', 'kPd6'),
                'xADaf': function _0x17417c(_0x442e6b, _0x5e4a0e) {
                    return _0x442e6b(_0x5e4a0e);
                },
                'ZRpYq': _0x31ee('0x42', '4)o]')
            };
            if (_0x509507['sqKbG'](_0x509507['JsSYM'], _0x31ee('0x43', 'MH!z'))) {
                _0x509507[_0x31ee('0x44', 'Ph1P')](alert, _0x509507[_0x31ee('0x45', '06Gv')]);
                return ![];
            } else {
                if (_0x14cd88[_0x31ee('0x46', 'GpW)')] == _0x31ee('0x47', 'IbNp')) {
                    if (_0x509507[_0x31ee('0x48', '4nrO')](_0x31ee('0x49', 'hODO'), 'lNR')) {
                        _0x509507['twYHe'](alert, _0x14cd88[_0x31ee('0x4a', 'w3Zv')]);
                    } else {
                        _0x509507[_0x31ee('0x4b', 'b$yN')](alert, _0x14cd88[_0x31ee('0x4c', 'vFXF')]);
                    }
                } else {
                    if (_0x509507[_0x31ee('0x4d', 'WP9J')] === _0x509507[_0x31ee('0x4e', '9D3T')]) {
                        _0x509507['xADaf'](alert, _0x14cd88[_0x31ee('0x4f', 'f%qN')]);
                    } else {
                        if (_0x14cd88[_0x31ee('0x50', 'gsX#')] == _0x509507[_0x31ee('0x51', '06Gv')]) {
                            history['go'](-0x1);
                            alert(_0x14cd88['msg']);
                            return ![];
                        } else {
                            _0x509507['xADaf'](alert, _0x14cd88['msg']);
                        }
                    }
                }
            }
        }
    });
});

function httc() {
    var _0x3d31f9 = {
        'dgFUW': function _0x4c692b(_0x208b06, _0x12c365) {
            return _0x208b06(_0x12c365);
        },
        'TXLzz': 'tuichu',
        'OvfJV': 'json'
    };
	console.log('TXLzz：',_0x3d31f9['TXLzz']);
    $[_0x31ee('0x52', 'f%qN')](_0x31ee('0x53', 'bW1B'), {
        'yycms': _0x3d31f9['TXLzz']
    }, function(_0x319f51) {
        _0x3d31f9[_0x31ee('0x54', '1&x!')]//(alert, _0x319f51[_0x31ee('0x55', '9D3T')]);
        $(function() {
            var _0x25160b = {
                'YUWkC': function _0x17cb6e(_0x30e3d9, _0x52afca) {
                    return _0x30e3d9 !== _0x52afca;
                },
                'UmyRD': 'XoF',
                'ZPuWJ': '200',
                'ZPCQS': function _0x2e9b3f(_0xe3f16b, _0x3b4a65) {
                    return _0xe3f16b(_0x3b4a65);
                }
            };
            if (_0x25160b[_0x31ee('0x56', '4)o]')](_0x25160b[_0x31ee('0x57', '4nrO')], _0x25160b[_0x31ee('0x58', 'qysX')])) {
                if (_0x319f51[_0x31ee('0x59', 'kPd6')] == _0x25160b[_0x31ee('0x5a', 'IbNp')]) {
                    window[_0x31ee('0x5b', 'gsX#')]['reload']();
                    _0x25160b[_0x31ee('0x5c', '06Gv')](alert, _0x319f51[_0x31ee('0x5d', '4)o]')]);
                    return ![];
                } else {
                   alert(_0x319f51[_0x31ee('0x5e', '(P8*')]);
                }
            } else {
                // window[_0x31ee('0x5f', '2ZOE')][_0x31ee('0x60', '9D3T')] = _0x31ee('0x61', 'IbNp');
            }
        });
    }, _0x3d31f9[_0x31ee('0x62', '%Nzq')]);
};

function xgxt() {
    var _0x2b9c61 = {
        'VHIhx': _0x31ee('0x63', 'qysX')
    };
    $[_0x31ee('0x64', 'E!K3')]({
        'type': _0x2b9c61[_0x31ee('0x65', 'XCt0')],
        'url': _0x31ee('0x66', '@d(p'),
        'data': $('#form1')[_0x31ee('0x67', 'vFXF')](),
        'dataType': _0x31ee('0x68', 'vFXF'),
        'async': ![],
        'success': function(_0x205447) {
            var _0x4e696e = {
                'SyFGo': function _0x25db9e(_0x2e0ddf, _0x52e42b) {
                    return _0x2e0ddf === _0x52e42b;
                },
                'rTVis': 'tEh',
                'yKrCQ': _0x31ee('0x69', '8XW3'),
                'fbedy': 'action.php',
                'GTtIg': _0x31ee('0x6a', 'E!K3'),
                'LOKwx': _0x31ee('0x6b', 'h*Pz')
            };
            if (_0x4e696e[_0x31ee('0x6c', 'QQLs')](_0x4e696e['rTVis'], _0x4e696e[_0x31ee('0x6d', 'Rs@W')])) {
                $['post'](_0x4e696e['fbedy'], {
                    'yycms': _0x4e696e[_0x31ee('0x6e', 'b$yN')],
                    'c_name': lm
                }, function(_0x12bbf1) {
                    var _0x1d93f8 = {
                        'ffMzO': function _0x7e383e(_0x484f07, _0x2174e2) {
                            return _0x484f07 == _0x2174e2;
                        },
                        'BsBbw': _0x31ee('0x6f', 'W#RH'),
                        'RccoH': function _0x11c194(_0x4a7526, _0x451d72) {
                            return _0x4a7526(_0x451d72);
                        }
                    };
                    if (_0x1d93f8['ffMzO'](_0x12bbf1[_0x31ee('0x70', '1&x!')], _0x1d93f8[_0x31ee('0x71', 'QQLs')])) {
                        _0x1d93f8['RccoH'](alert, _0x12bbf1['msg']);
                        window[_0x31ee('0x72', 'f%qN')][_0x31ee('0x73', 'h*Pz')]();
                        return ![];
                    } else {
                        _0x1d93f8[_0x31ee('0x74', 'Me&g')](alert, _0x12bbf1[_0x31ee('0x75', 'q[H4')]);
                    }
                }, _0x4e696e[_0x31ee('0x76', 'khIP')]);
            } else {
                alert(_0x205447['msg']);
            }
        }
    });
};

function sfsz() {
    var _0x525825 = {
        'ifkKy': _0x31ee('0x77', 'QQLs'),
        'fdWni': function _0x5b212c(_0x43a1b4, _0x4e3a44) {
            return _0x43a1b4(_0x4e3a44);
        },
        'aVtTy': _0x31ee('0x78', 'JK]4'),
        'yfhRD': 'json'
    };
    $[_0x31ee('0x79', '@sZ*')]({
        'type': _0x525825[_0x31ee('0x7a', '06Gv')],
        'url': _0x31ee('0x7b', 'eewZ'),
        'data': _0x525825[_0x31ee('0x7c', 'Q#dV')]($, _0x525825[_0x31ee('0x7d', '8[GV')])[_0x31ee('0x7e', 'E!K3')](),
        'dataType': _0x525825[_0x31ee('0x7f', 'bW1B')],
        'async': ![],
        'success': function(_0x503bb2) {
            var _0x4adac9 = {
                'Xnhzd': function _0x2edac2(_0x404c59, _0x19914a) {
                    return _0x404c59 !== _0x19914a;
                },
                'KbKaT': _0x31ee('0x80', '06Gv'),
                'nuODT': 'Eln',
                'futiI': function _0x4a9435(_0x19743a, _0x385b43) {
                    return _0x19743a == _0x385b43;
                },
                'erCYm': _0x31ee('0x81', '%Nzq'),
                'Jsfto': function _0x3793be(_0x3294ed, _0x56ee20) {
                    return _0x3294ed !== _0x56ee20;
                },
                'Uvstw': function _0x47c120(_0x7911f0, _0x430603) {
                    return _0x7911f0(_0x430603);
                }
            };
            if (_0x4adac9[_0x31ee('0x82', '4)o]')](_0x4adac9[_0x31ee('0x83', 'TaD0')], _0x4adac9['nuODT'])) {
                if (_0x4adac9[_0x31ee('0x84', 'f%qN')](_0x503bb2['code'], _0x4adac9[_0x31ee('0x85', 'GpW)')])) {
                    if (_0x4adac9[_0x31ee('0x86', 'IbNp')](_0x31ee('0x87', 'Q#dV'), 'iSJ')) {
                        _0x4adac9[_0x31ee('0x88', 'T8o*')](alert, _0x503bb2[_0x31ee('0x89', 'WP9J')]);
                    } else {
                        window[_0x31ee('0x8a', 'QQLs')]['reload']();
                        alert(_0x503bb2[_0x31ee('0x8b', 'b$yN')]);
                        return ![];
                    }
                } else {
                    _0x4adac9[_0x31ee('0x8c', 'QQLs')](alert, _0x503bb2['msg']);
                }
            } else {
                window['location']['reload']();
                _0x4adac9[_0x31ee('0x8d', 'eewZ')](alert, _0x503bb2['msg']);
            }
        }
    });
};

function zfxg() {
    var _0x34755f = {
        'TXeaU': function _0x4eccfe(_0x9942f7, _0x1640c4) {
            return _0x9942f7 == _0x1640c4;
        },
        'Dkzdd': _0x31ee('0x8e', 'GpW)'),
        'UxvZd': function _0x586e72(_0x58a421, _0x109ebd) {
            return _0x58a421 !== _0x109ebd;
        },
        'EpGnu': _0x31ee('0x8f', 'W#RH'),
        'DKGOV': function _0x4c8510(_0x39f9a1, _0x5136aa) {
            return _0x39f9a1(_0x5136aa);
        },
        'cjLtq': function _0xc98ef0(_0x1015b9, _0x536053) {
            return _0x1015b9(_0x536053);
        },
        'ZIWst': _0x31ee('0x90', '4nrO'),
        'eJVKl': 'action.php',
        'urmOS': function _0x25f57a(_0x46868e, _0xc7523e) {
            return _0x46868e(_0xc7523e);
        },
        'SqAzl': _0x31ee('0x91', 'h*Pz'),
        'KDowN': _0x31ee('0x92', '1&x!')
    };
    $[_0x31ee('0x93', 'JK]4')]({
        'type': _0x34755f['ZIWst'],
        'url': _0x34755f['eJVKl'],
        'data': _0x34755f[_0x31ee('0x94', 'Rs@W')]($, _0x34755f[_0x31ee('0x95', 'Q#dV')])[_0x31ee('0x96', 'Q#dV')](),
        'dataType': _0x34755f['KDowN'],
        'async': ![],
        'success': function(_0x5df49b) {
            if (_0x34755f[_0x31ee('0x97', 'eewZ')](_0x5df49b[_0x31ee('0x98', 'Rs@W')], _0x34755f[_0x31ee('0x99', 'Me&g')])) {
                if (_0x34755f[_0x31ee('0x9a', 'eewZ')]('vRX', _0x34755f[_0x31ee('0x9b', '2ZOE')])) {
                    window[_0x31ee('0x72', 'f%qN')][_0x31ee('0x9c', '1&x!')]();
                    _0x34755f[_0x31ee('0x9d', '@sZ*')](alert, _0x5df49b[_0x31ee('0x5e', '(P8*')]);
                    return ![];
                } else {
                    if (r[_0x31ee('0x9e', 'Q#dV')] == 0xc8) {
                        _0x34755f[_0x31ee('0x9f', '6N@0')](alert, r[_0x31ee('0xa0', 'IbNp')]);
                        $(function() {
                            var _0x3f1469 = {
                                'IvRRa': 'yycms_main.php'
                            };
                            window['location'][_0x31ee('0xa1', 'JQiv')] = _0x3f1469['IvRRa'];
                        });
                    } else {
                        alert(r[_0x31ee('0xa2', '%Nzq')]);
                    }
                }
            } else {
                alert(_0x5df49b[_0x31ee('0xa3', 'eewZ')]);
            }
        }
    });
};

function wxxg() {
    var _0x5d33d6 = {
        'kjfTk': _0x31ee('0xa4', 'bW1B'),
        'hqYss': function _0x4f925c(_0x22a238, _0x5b682a) {
            return _0x22a238(_0x5b682a);
        },
        'skqQz': '#form1',
        'FHCDg': _0x31ee('0xa5', 'MH!z')
    };
    $[_0x31ee('0xa6', 'eewZ')]({
        'type': _0x5d33d6[_0x31ee('0xa7', '8[GV')],
        'url': _0x31ee('0xa8', 'XCt0'),
        'data': _0x5d33d6['hqYss']($, _0x5d33d6[_0x31ee('0xa9', 'q[H4')])[_0x31ee('0xaa', 'QQLs')](),
        'dataType': _0x5d33d6[_0x31ee('0xab', 'eewZ')],
        'success': function(_0x4d4c47) {
            var _0x379b5d = {
                'nzzVh': function _0x4b2a8f(_0x379671, _0x4cbfdf) {
                    return _0x379671 !== _0x4cbfdf;
                },
                'mgIqz': _0x31ee('0xac', '1&x!'),
                'dUrEK': 'xzM',
                'znqLD': _0x31ee('0xad', 'JK]4'),
                'JMvHQ': function _0x29bff0(_0xabff80, _0x5583e9) {
                    return _0xabff80 !== _0x5583e9;
                },
                'TzBGr': _0x31ee('0xae', 'IbNp'),
                'XbBQc': function _0x5c2a6b(_0x1f927d, _0x44cdfe) {
                    return _0x1f927d(_0x44cdfe);
                },
                'rJBql': function _0x8bff3e(_0x3f8e0a, _0x3a6460) {
                    return _0x3f8e0a == _0x3a6460;
                },
                'CLvah': function _0x1bd7cb(_0x179fe5, _0x1df234) {
                    return _0x179fe5(_0x1df234);
                },
                'rhefS': _0x31ee('0xaf', 'khIP'),
                'FxHdp': function _0x45f9f9(_0x1da43d, _0x35c464) {
                    return _0x1da43d(_0x35c464);
                },
                'uYXoV': _0x31ee('0xb0', 'Me&g')
            };
            if (_0x379b5d[_0x31ee('0xb1', '8[GV')](_0x379b5d[_0x31ee('0xb2', '(P8*')], _0x379b5d[_0x31ee('0xb3', '%Nzq')])) {
                if (_0x4d4c47['code'] == _0x379b5d['znqLD']) {
                    if (_0x379b5d[_0x31ee('0xb4', 'WP9J')](_0x31ee('0xb5', 'qmgC'), _0x379b5d['TzBGr'])) {
                        window[_0x31ee('0xb6', 'tk3]')][_0x31ee('0xb7', 'Ph1P')]();
                        _0x379b5d['XbBQc'](alert, _0x4d4c47[_0x31ee('0xb8', 'tk3]')]);
                        return ![];
                    } else {
                        if (_0x379b5d['rJBql'](_0x4d4c47[_0x31ee('0xb9', '4nrO')], _0x379b5d[_0x31ee('0xba', 'Ph1P')])) {
                            alert(_0x4d4c47[_0x31ee('0xbb', 'hODO')]);
                        } else {
                            _0x379b5d[_0x31ee('0xbc', 'Me&g')](alert, _0x4d4c47[_0x31ee('0xbd', 'Q#dV')]);
                        }
                    }
                } else {
                    _0x379b5d[_0x31ee('0xbe', 'XCt0')](alert, _0x4d4c47[_0x31ee('0xbf', 'XCt0')]);
                }
            } else {
                _0x379b5d['CLvah'](alert, _0x379b5d['rhefS']);
                _0x379b5d[_0x31ee('0xc0', 'hODO')]($, _0x379b5d[_0x31ee('0xc1', 'GMyL')])['focus']();
                return ![];
            }
        }
    });
};

function tjlm() {
    var _0xd6ac9b = {
        'RQMhd': function _0xcea144(_0x6faedd, _0x526af1) {
            return _0x6faedd(_0x526af1);
        },
        'Ryssq': function _0x17612f(_0x2c35d8, _0x319aa7) {
            return _0x2c35d8(_0x319aa7);
        },
        'sguUH': function _0x1acd3d(_0x5026b4, _0x4bb4d6) {
            return _0x5026b4 === _0x4bb4d6;
        },
        'IdRTu': _0x31ee('0xc2', 'qysX'),
        'HizCw': 'action.php',
        'dDFZy': _0x31ee('0xc3', 'b$yN'),
        'UNjqw': _0x31ee('0xc4', 'IbNp'),
        'nAFqq': 'tjlm'
    };
    var _0x19abeb = _0xd6ac9b[_0x31ee('0xc5', 't$sT')]($, _0x31ee('0xc6', 'Q#dV'))[_0x31ee('0xc7', 'Ph1P')]();
    if (_0xd6ac9b[_0x31ee('0xc8', 'TaD0')](confirm, '确定要执行吗')) {
        if (_0xd6ac9b[_0x31ee('0xc9', 'Q#dV')](_0xd6ac9b[_0x31ee('0xca', '1&x!')], _0x31ee('0xcb', 'f%qN'))) {
            $['post'](_0xd6ac9b[_0x31ee('0xcc', 'XCt0')], {
                'yycms': _0xd6ac9b['dDFZy'],
                'c_name': _0x19abeb,
                'lmid': lmid
            }, function(_0x3a379b) {
                var _0x1f36aa = {
                    'OSyqZ': function _0x39e62e(_0x176dea, _0x3f7c17) {
                        return _0x176dea == _0x3f7c17;
                    },
                    'XELXe': _0x31ee('0xcd', 't$sT'),
                    'KwFZP': function _0x1d7131(_0x4e17d2, _0x4b14bb) {
                        return _0x4e17d2(_0x4b14bb);
                    }
                };
                if (_0x1f36aa[_0x31ee('0xce', 'GMyL')](_0x3a379b['code'], _0x1f36aa[_0x31ee('0xcf', '4nrO')])) {
                    _0x1f36aa[_0x31ee('0xd0', 'QQLs')](alert, _0x3a379b[_0x31ee('0xd1', 'JQiv')]);
                    window[_0x31ee('0xd2', '4nrO')][_0x31ee('0xd3', 'bW1B')]();
                    return ![];
                } else {
                    _0x1f36aa[_0x31ee('0xd4', 'E!K3')](alert, _0x3a379b[_0x31ee('0xd5', 'G(Pe')]);
                }
            }, _0xd6ac9b[_0x31ee('0xd6', 'qmgC')]);
        } else {
            $[_0x31ee('0xd7', 'U7ze')](_0xd6ac9b[_0x31ee('0xd8', 'kPd6')], {
                'yycms': _0xd6ac9b[_0x31ee('0xd9', 'yWvh')],
                'c_name': _0x19abeb
            }, function(_0x2e464e) {
                var _0x22db7a = {
                    'uccCJ': function _0x9d8773(_0x408eee, _0x22c99b) {
                        return _0x408eee == _0x22c99b;
                    },
                    'szqIU': _0x31ee('0x6f', 'W#RH'),
                    'BkeKV': function _0x181e16(_0x378868, _0x38ff90) {
                        return _0x378868(_0x38ff90);
                    }
                };
                if (_0x22db7a['uccCJ'](_0x2e464e['code'], _0x22db7a[_0x31ee('0xda', 'W#RH')])) {
                    _0x22db7a['BkeKV'](alert, _0x2e464e['msg']);
                    window['location'][_0x31ee('0xdb', 't$sT')]();
                    return ![];
                } else {
                    alert(_0x2e464e[_0x31ee('0xdc', 'Me&g')]);
                }
            }, _0x31ee('0xdd', 'WP9J'));
        }
    }
};

function xglm() {
    var _0x4a8d73 = {
        'yIpdW': function _0x48b801(_0x44cbf7, _0xac020d) {
            return _0x44cbf7(_0xac020d);
        },
        'mjyAQ': '#yycms_lm',
        'vdESb': '#yycms_lmid',
        'umlcU': function _0xdb9cf8(_0x49c21b, _0x5f3905) {
            return _0x49c21b(_0x5f3905);
        },
        'pmagw': _0x31ee('0xde', 'TaD0'),
        'xIPyi': _0x31ee('0xdf', 'T8o*'),
        'ixUoS': _0x31ee('0xe0', 'kPd6'),
        'loljq': _0x31ee('0xe1', 'G(Pe')
    };
    var _0x4ae890 = _0x4a8d73[_0x31ee('0xe2', '%Nzq')]($, _0x4a8d73['mjyAQ'])[_0x31ee('0xe3', 'GpW)')]();
    var _0x2b75a8 = _0x4a8d73[_0x31ee('0xe4', '8XW3')]($, _0x4a8d73[_0x31ee('0xe5', 'q[H4')])[_0x31ee('0xe6', '1S%8')]();
    if (_0x4a8d73[_0x31ee('0xe7', 't$sT')](confirm, _0x4a8d73['pmagw'])) {
        $[_0x31ee('0xe8', '%Nzq')](_0x4a8d73[_0x31ee('0xe9', 't$sT')], {
            'yycms': _0x4a8d73['ixUoS'],
            'c_name': _0x4ae890,
            'lmid': _0x2b75a8
        }, function(_0x5c56c1) {
            var _0x524e36 = {
                'ebERp': function _0x33b2b8(_0x565e40, _0x31c91e) {
                    return _0x565e40 === _0x31c91e;
                },
                'KtDpP': _0x31ee('0xea', 'hODO'),
                'pjTEN': _0x31ee('0xeb', 'q[H4'),
                'PuQfG': function _0x851af3(_0x129ad, _0x2d6a84) {
                    return _0x129ad(_0x2d6a84);
                },
                'qxiPL': '请输入用户密码！',
                'cHHxn': '200',
                'tEpJc': function _0x47ad96(_0x47e44b, _0x33a9cc) {
                    return _0x47e44b(_0x33a9cc);
                }
            };
            if (_0x524e36[_0x31ee('0xec', 'tk3]')](_0x524e36['KtDpP'], _0x524e36[_0x31ee('0xed', 'vFXF')])) {
                _0x524e36[_0x31ee('0xee', 'Rs@W')](alert, _0x524e36['qxiPL']);
                return ![];
            } else {
                if (_0x5c56c1['code'] == _0x524e36[_0x31ee('0xef', 'Me&g')]) {
                    if (_0x31ee('0xf0', 'q[H4') === _0x31ee('0xf1', '8XW3')) {
                        window[_0x31ee('0xf2', 'b$yN')]['reload']();
                        _0x524e36[_0x31ee('0xf3', 'h*Pz')](alert, _0x5c56c1[_0x31ee('0xf4', 'yWvh')]);
                        return ![];
                    } else {
                        _0x524e36[_0x31ee('0xf5', 't$sT')](alert, _0x5c56c1['msg']);
                        window['location'][_0x31ee('0xf6', 'Q#dV')]();
                        return ![];
                    }
                } else {
                    alert(_0x5c56c1['msg']);
                }
            }
        }, _0x4a8d73[_0x31ee('0xf7', 'G(Pe')]);
    }
};

function sptj() {
    var _0x2e53d2 = {
        'uOuHi': _0x31ee('0xf8', 'JQiv'),
        'FYvKK': function _0x4f7927(_0x21667d, _0x5d86b9) {
            return _0x21667d(_0x5d86b9);
        },
        'xzLEN': function _0x525f6d(_0x26add3, _0x33d5f3) {
            return _0x26add3(_0x33d5f3);
        },
        'hGlsx': _0x31ee('0xf9', 'E!K3'),
        'YgjYP': function _0x52e3eb(_0x35bd93, _0x1d3de6) {
            return _0x35bd93 == _0x1d3de6;
        },
        'SYOve': _0x31ee('0xfa', 'Ph1P'),
        'NxgkQ': _0x31ee('0xfb', 'hODO')
    };
    var _0x498ffa = _0x2e53d2['xzLEN']($, _0x2e53d2[_0x31ee('0xfc', 'Me&g')])[_0x31ee('0xfd', 'eewZ')]();
    if (_0x2e53d2[_0x31ee('0xfe', '4nrO')](_0x498ffa, 0x0)) {
        alert(_0x2e53d2[_0x31ee('0xff', 'JK]4')]);
        return ![];
    }
    $['ajax']({
        'type': _0x2e53d2[_0x31ee('0x100', 'GMyL')],
        'url': _0x31ee('0x101', 'yWvh'),
        'data': _0x2e53d2[_0x31ee('0x102', 'JK]4')]($, '#sptj')['serialize'](),
        'dataType': _0x31ee('0x103', 't$sT'),
        'success': function(_0x13e49f) {
            if (_0x13e49f[_0x31ee('0x104', 'vFXF')] == _0x2e53d2[_0x31ee('0x105', 'QQLs')]) {
                history['go'](-0x1);
                _0x2e53d2[_0x31ee('0x106', '@d(p')](alert, _0x13e49f[_0x31ee('0x107', 'GMyL')]);
                return ![];
            } else {
                alert(_0x13e49f['msg']);
            }
        }
    });
};

function spxg() {
    var _0x1aa1e3 = {
        'dRnAA': _0x31ee('0x108', 'tk3]'),
        'xajDy': function _0x2749c1(_0x228661, _0xdbadc8) {
            return _0x228661(_0xdbadc8);
        }
    };
    $[_0x31ee('0x109', 'khIP')]({
        'type': _0x31ee('0xa4', 'bW1B'),
        'url': _0x1aa1e3[_0x31ee('0x10a', 'qysX')],
        'data': _0x1aa1e3[_0x31ee('0x10b', '6N@0')]($, '#form1')['serialize'](),
        'dataType': _0x31ee('0x10c', 'hODO'),
        'success': function(_0x2abba8) {
            var _0x1ccb9a = {
                'QEEEs': function _0x1b5ddf(_0x364461, _0xcb3f16) {
                    return _0x364461 !== _0xcb3f16;
                },
                'NALJk': _0x31ee('0x10d', '06Gv'),
                'MPnsY': function _0x245aaf(_0x1d99dd, _0x1cb64a) {
                    return _0x1d99dd(_0x1cb64a);
                }
            };
            if (_0x1ccb9a[_0x31ee('0x10e', 'hODO')](_0x1ccb9a['NALJk'], _0x1ccb9a[_0x31ee('0x10f', '4nrO')])) {
                history['go'](-0x1);
                alert(_0x2abba8['msg']);
                return ![];
            } else {
                _0x1ccb9a[_0x31ee('0x110', 'W#RH')](alert, _0x2abba8[_0x31ee('0xa3', 'eewZ')]);
            }
        }
    });
};

function spplsc() {
    var _0x5551de = {
        'SIqLy': function _0x5d94a8(_0x294cef, _0x3c3be4) {
            return _0x294cef(_0x3c3be4);
        },
        'tzGWU': function _0x3b22d2(_0x4b4723, _0x3902be) {
            return _0x4b4723 === _0x3902be;
        },
        'eFsGv': _0x31ee('0x111', 'U7ze'),
        'cmMUI': function _0x3de613(_0x40ac25, _0x504e38) {
            return _0x40ac25 == _0x504e38;
        },
        'VKlhq': function _0x4d2f8d(_0x4534be, _0x2653e5) {
            return _0x4534be(_0x2653e5);
        },
        'sJvWo': '请选择一项要执行的操作！',
        'SByUz': _0x31ee('0x112', 'tk3]'),
        'BByRm': 'action.php',
        'Adaxh': '#spplsc',
        'LEhWn': function _0xc53c65(_0x513e43, _0x2de773) {
            return _0x513e43(_0x2de773);
        }
    };
    if (_0x5551de['SIqLy'](confirm, '确定要执行？')) {
        if (_0x5551de[_0x31ee('0x113', 'T8o*')](_0x5551de[_0x31ee('0x114', '@sZ*')], _0x5551de[_0x31ee('0x115', 'eewZ')])) {
            if (_0x5551de[_0x31ee('0x116', '4nrO')](_0x5551de['VKlhq']($, _0x31ee('0x117', '4nrO'))[_0x31ee('0x118', 'bW1B')](), '')) {
                alert(_0x5551de[_0x31ee('0x119', 'f%qN')]);
                return ![];
            };
            $['ajax']({
                'type': _0x5551de[_0x31ee('0x11a', 'GpW)')],
                'url': _0x5551de['BByRm'],
                'data': $(_0x5551de[_0x31ee('0x11b', 'qmgC')])[_0x31ee('0x11c', 'bW1B')](),
                'dataType': _0x31ee('0x11d', 'Q#dV'),
                'success': function(_0x1f96cd) {
                    var _0x415465 = {
                        'vQJZQ': _0x31ee('0x11e', 'TaD0'),
                        'rrRZc': function _0x23738e(_0x50f2a7, _0x3c3623) {
                            return _0x50f2a7(_0x3c3623);
                        },
                        'OAwdf': function _0x58d445(_0x4b2a1b, _0x476ac4) {
                            return _0x4b2a1b(_0x476ac4);
                        }
                    };
                    if (_0x1f96cd[_0x31ee('0x11f', 'QQLs')] == _0x415465['vQJZQ']) {
                        window[_0x31ee('0x120', 'U7ze')]['reload']();
                        _0x415465[_0x31ee('0x121', '4)o]')](alert, _0x1f96cd[_0x31ee('0x5d', '4)o]')]);
                        return ![];
                    } else {
                        _0x415465[_0x31ee('0x122', 'q[H4')](alert, _0x1f96cd[_0x31ee('0xbb', 'hODO')]);
                    }
                }
            });
        } else {
            _0x5551de[_0x31ee('0x123', 'vFXF')](alert, r['msg']);
        }
    }
};

function ggxg() {
    var _0x3aceef = {
        'xMBHA': function _0x1157d3(_0x1f2dd6, _0x128c14) {
            return _0x1f2dd6 == _0x128c14;
        },
        'qRdqV': '200',
        'jAsIl': function _0x19b7cf(_0x1544c5, _0xbb0030) {
            return _0x1544c5(_0xbb0030);
        },
        'dAoiU': 'nGB',
        'OtTQz': _0x31ee('0x124', 'JK]4'),
        'uAmJj': 'json'
    };
    $['ajax']({
        'type': _0x3aceef['OtTQz'],
        'url': _0x31ee('0x125', 'GpW)'),
        'data': _0x3aceef['jAsIl']($, _0x31ee('0x126', '06Gv'))[_0x31ee('0x127', '1S%8')](),
        'dataType': _0x3aceef['uAmJj'],
        'async': ![],
        'success': function(_0x50ca6c) {
            if (_0x3aceef[_0x31ee('0x128', '2ZOE')](_0x50ca6c[_0x31ee('0x129', 'khIP')], _0x3aceef[_0x31ee('0x12a', '6N@0')])) {
                window[_0x31ee('0x12b', 'GMyL')][_0x31ee('0xb7', 'Ph1P')]();
                _0x3aceef[_0x31ee('0x12c', 'gsX#')](alert, _0x50ca6c[_0x31ee('0x12d', 'GpW)')]);
                return ![];
            } else {
                if (_0x3aceef[_0x31ee('0x12e', '2ZOE')] !== 'nGB') {
                    _0x3aceef['jAsIl'](alert, _0x50ca6c[_0x31ee('0x4f', 'f%qN')]);
                } else {
                    _0x3aceef[_0x31ee('0x12f', '1&x!')](alert, _0x50ca6c[_0x31ee('0x130', '8[GV')]);
                }
            }
        }
    });
};

function tjdl() {
    var _0x370c4e = {
        'BKRiE': 'POST',
        'SdHBD': _0x31ee('0x131', 'WP9J'),
        'zbZFU': function _0x5329d7(_0x6c59bc, _0x3473d0) {
            return _0x6c59bc(_0x3473d0);
        },
        'BVFUb': _0x31ee('0x68', 'vFXF')
    };
    $[_0x31ee('0x132', 'U7ze')]({
        'type': _0x370c4e[_0x31ee('0x133', '2ZOE')],
        'url': _0x370c4e[_0x31ee('0x134', 'GpW)')],
        'data': _0x370c4e[_0x31ee('0x135', '2ZOE')]($, '#form1')['serialize'](),
        'dataType': _0x370c4e[_0x31ee('0x136', 'WP9J')],
        'async': ![],
        'success': function(_0x470e0f) {
            var _0x132cd2 = {
                'TFXOw': function _0x2fd672(_0x2e1924, _0x50f73f) {
                    return _0x2e1924 !== _0x50f73f;
                },
                'UuMjo': _0x31ee('0x137', 'W#RH'),
                'YSiXu': function _0x2a0c23(_0x2d5992, _0x47caa1) {
                    return _0x2d5992 == _0x47caa1;
                },
                'XuvoO': _0x31ee('0x138', '@d(p'),
                'zZSlp': function _0x38d28a(_0x543425) {
                    return _0x543425();
                }
            };
            if (_0x132cd2[_0x31ee('0x139', 'f%qN')](_0x132cd2['UuMjo'], _0x132cd2[_0x31ee('0x13a', 'vFXF')])) {
                if (_0x132cd2[_0x31ee('0x13b', 'tk3]')]($[_0x31ee('0x13c', 'khIP')](_0x132cd2['XuvoO']), null)) {
                    _0x132cd2[_0x31ee('0x13d', 'qmgC')](jcsc);
                }
            } else {
                alert[_0x31ee('0x8b', 'b$yN')](_0x470e0f['msg']);
            }
        }
    });
};

function lysc() {
    var _0x60e6e7 = {
        'fpzUN': function _0x498b6a(_0xc1a359, _0x576cf5) {
            return _0xc1a359(_0x576cf5);
        },
        'qkjzn': _0x31ee('0x13e', 'qysX'),
        'WttcK': _0x31ee('0x13f', 'TaD0'),
        'RULXT': function _0x1bf494(_0x38e751, _0x534b1f) {
            return _0x38e751 == _0x534b1f;
        },
        'ximwA': _0x31ee('0x140', '2ZOE'),
        'DiVew': '请选择一项要执行的操作！',
        'FpbTK': _0x31ee('0x141', 'Ph1P'),
        'pAvpe': 'action.php',
        'rQFgJ': '#form1'
    };
    if (_0x60e6e7[_0x31ee('0x142', 'JQiv')](confirm, '确定要执行？')) {
        if (_0x60e6e7['qkjzn'] !== _0x60e6e7[_0x31ee('0x143', 'tk3]')]) {
            if (_0x60e6e7[_0x31ee('0x144', '6N@0')](_0x60e6e7['fpzUN']($, _0x60e6e7[_0x31ee('0x145', 'Me&g')])['val'](), '')) {
                _0x60e6e7['fpzUN'](alert, _0x60e6e7[_0x31ee('0x146', 'khIP')]);
                return ![];
            };
            $[_0x31ee('0x147', 'WP9J')]({
                'type': _0x60e6e7[_0x31ee('0x148', 'gsX#')],
                'url': _0x60e6e7['pAvpe'],
                'data': _0x60e6e7['fpzUN']($, _0x60e6e7[_0x31ee('0x149', '(P8*')])['serialize'](),
                'dataType': _0x31ee('0x14a', '06Gv'),
                'success': function(_0x3a90df) {
                    var _0x2886aa = {
                        'tLafo': 'IKc',
                        'ACzSe': function _0x278ffc(_0x43ef28, _0x2c4ad8) {
                            return _0x43ef28 == _0x2c4ad8;
                        },
                        'xoRFi': '200',
                        'HSybe': 'VJA',
                        'YdIam': _0x31ee('0x14b', '@d(p'),
                        'CCECu': function _0x32aa99(_0x3b672e, _0x4b1b4e) {
                            return _0x3b672e(_0x4b1b4e);
                        },
                        'lCUUs': function _0x329188(_0x55b5eb, _0x38eefa) {
                            return _0x55b5eb == _0x38eefa;
                        },
                        'Nixww': function _0x58ef86(_0x201655, _0x2bbd0c) {
                            return _0x201655(_0x2bbd0c);
                        },
                        'Fthuy': function _0x8ed718(_0x5871cf, _0x4c9d99) {
                            return _0x5871cf === _0x4c9d99;
                        },
                        'knGiL': _0x31ee('0x14c', 'q[H4'),
                        'YDPXe': function _0x5b4c21(_0x247d53, _0x531baf) {
                            return _0x247d53(_0x531baf);
                        },
                        'JtXDp': _0x31ee('0x14d', 'Rs@W'),
                        'ZGrby': _0x31ee('0x14e', 'bW1B'),
                        'qgNHh': function _0x134b90(_0x297144, _0x493079) {
                            return _0x297144(_0x493079);
                        },
                        'OKUjQ': _0x31ee('0x14f', '1S%8')
                    };
                    if (_0x31ee('0x150', 'Me&g') === _0x2886aa['tLafo']) {
                        if (_0x2886aa[_0x31ee('0x151', 'GpW)')](_0x3a90df['code'], _0x2886aa[_0x31ee('0x152', 'vFXF')])) {
                            if (_0x2886aa[_0x31ee('0x153', 'TaD0')] !== _0x2886aa[_0x31ee('0x154', 'Me&g')]) {
                                window[_0x31ee('0x155', 'XCt0')]['reload']();
                                _0x2886aa[_0x31ee('0x156', 'gsX#')](alert, _0x3a90df[_0x31ee('0x157', 'U7ze')]);
                                return ![];
                            } else {
                                if (_0x2886aa[_0x31ee('0x158', 'JQiv')](_0x3a90df[_0x31ee('0x159', 'E!K3')], _0x2886aa[_0x31ee('0x15a', 'JK]4')])) {
                                    alert(_0x3a90df['msg']);
                                } else {
                                    _0x2886aa[_0x31ee('0x15b', '@sZ*')](alert, _0x3a90df[_0x31ee('0x130', '8[GV')]);
                                }
                            }
                        } else {
                            if (_0x2886aa[_0x31ee('0x15c', '6N@0')](_0x2886aa[_0x31ee('0x15d', 'TaD0')], _0x31ee('0x15e', '@d(p'))) {
                                _0x2886aa[_0x31ee('0x15f', 'Q#dV')](alert, _0x2886aa[_0x31ee('0x160', 'XCt0')]);
                                return ![];
                            } else {
                                _0x2886aa[_0x31ee('0x161', 'h*Pz')](alert, _0x3a90df['msg']);
                            }
                        }
                    } else {
                        _0x2886aa[_0x31ee('0x162', 't$sT')](alert, _0x2886aa['ZGrby']);
                        _0x2886aa[_0x31ee('0x163', 'h*Pz')]($, _0x2886aa['OKUjQ'])[_0x31ee('0x164', 'U7ze')]();
                        return ![];
                    }
                }
            });
        } else {
            _0x60e6e7['fpzUN'](alert, data[_0x31ee('0xbd', 'Q#dV')]);
        }
    }
};

function kmzsc(_0x391635) {
    var _0x95cc08 = {
        'bssMM': function _0x471481(_0x4246bf, _0x15168b) {
            return _0x4246bf(_0x15168b);
        },
        'KSjrH': _0x31ee('0x165', 'hODO'),
        'Ciapn': _0x31ee('0x166', 'f%qN'),
        'diFCo': _0x31ee('0x167', 'h*Pz')
    };
    if (_0x95cc08[_0x31ee('0x168', 'TaD0')](confirm, _0x95cc08['KSjrH'])) {
        $[_0x31ee('0x169', 'QQLs')]({
            'type': _0x31ee('0x16a', 'b$yN'),
            'url': _0x95cc08[_0x31ee('0x16b', 'q[H4')],
            'data': {
                'bs': _0x391635,
                'yycms': _0x95cc08[_0x31ee('0x16c', 'JQiv')]
            },
            'dataType': _0x31ee('0x16d', '@d(p'),
            'async': !![],
            'success': function(_0xdf095d) {
                window[_0x31ee('0x16e', 'q[H4')][_0x31ee('0x16f', 'E!K3')]();
                alert(_0xdf095d['msg']);
            }
        });
    }
};

function kmsc() {
    var _0x466b48 = {
        'DZaOx': function _0x2fec56(_0x545956, _0x141771) {
            return _0x545956(_0x141771);
        },
        'bCzfE': _0x31ee('0x170', '2ZOE'),
        'lgeyU': function _0x3dd62f(_0x11e354, _0x3baf20) {
            return _0x11e354 == _0x3baf20;
        },
        'VpWXN': '#execute_method',
        'YPdga': function _0x5ee21f(_0x1fd7ce, _0x4d6096) {
            return _0x1fd7ce(_0x4d6096);
        },
        'LOmPY': _0x31ee('0x171', 'kPd6'),
        'GtcpZ': 'action.php',
        'YfdDD': _0x31ee('0x172', 'hODO'),
        'tOiqa': _0x31ee('0x173', 'Rs@W')
    };
    if (_0x466b48['DZaOx'](confirm, _0x466b48[_0x31ee('0x174', 'yWvh')])) {
        if (_0x466b48[_0x31ee('0x175', '4)o]')]($(_0x466b48['VpWXN'])['val'](), '')) {
            _0x466b48[_0x31ee('0x176', 'tk3]')](alert, '请选择一项要执行的操作！');
            return ![];
        };
        $['ajax']({
            'type': _0x466b48[_0x31ee('0x177', 'khIP')],
            'url': _0x466b48[_0x31ee('0x178', 'h*Pz')],
            'data': $(_0x466b48[_0x31ee('0x179', 'U7ze')])[_0x31ee('0xaa', 'QQLs')](),
            'dataType': _0x466b48[_0x31ee('0x17a', 'h*Pz')],
            'success': function(_0x36ddbf) {
                var _0x548a5f = {
                    'Affaz': 'dwX',
                    'Ntasq': _0x31ee('0x17b', '1&x!'),
                    'nHvMq': function _0x23355a(_0x2f499f, _0x4b65f9) {
                        return _0x2f499f == _0x4b65f9;
                    },
                    'tTzIL': function _0x3116b3(_0x4d8586, _0x4f4b93) {
                        return _0x4d8586 !== _0x4f4b93;
                    },
                    'EYvhp': 'FuK',
                    'RMiFW': function _0x493ee0(_0x1e63fd) {
                        return _0x1e63fd();
                    },
                    'hShdh': function _0x1e8286(_0x564668, _0x3da712) {
                        return _0x564668 === _0x3da712;
                    },
                    'OdaBK': _0x31ee('0x17c', 'khIP'),
                    'eLnWg': 'bWu',
                    'bmTcw': function _0xab26e7(_0x21d597, _0x1d82ad) {
                        return _0x21d597(_0x1d82ad);
                    },
                    'LKaGg': function _0x8849e1(_0x1a3bc1, _0x8d4a73) {
                        return _0x1a3bc1(_0x8d4a73);
                    },
                    'uOwvc': 'action.php',
                    'EXmQN': 'json',
                    'YGOpQ': _0x31ee('0x17d', 'h*Pz')
                };
                if (_0x548a5f['Affaz'] !== _0x548a5f[_0x31ee('0x17e', '@d(p')]) {
                    if (_0x548a5f[_0x31ee('0x17f', '9D3T')](_0x36ddbf['code'], '200')) {
                        if (_0x548a5f[_0x31ee('0x180', 't$sT')](_0x31ee('0x181', '9D3T'), _0x548a5f[_0x31ee('0x182', 'w3Zv')])) {
                            _0x548a5f[_0x31ee('0x183', 'IbNp')](jcsc);
                        } else {
                            window[_0x31ee('0x184', 'eewZ')]['reload']();
                            alert(_0x36ddbf[_0x31ee('0xf4', 'yWvh')]);
                            return ![];
                        }
                    } else {
                        if (_0x548a5f[_0x31ee('0x185', '@sZ*')](_0x548a5f[_0x31ee('0x186', '2ZOE')], _0x548a5f[_0x31ee('0x187', 'JQiv')])) {
                            _0x548a5f[_0x31ee('0x188', '6N@0')](alert, _0x36ddbf['msg']);
                        } else {
                            _0x548a5f[_0x31ee('0x189', 'QQLs')](alert, _0x36ddbf[_0x31ee('0x18a', 'QQLs')]);
                        }
                    }
                } else {
                    $[_0x31ee('0x18b', '8XW3')]({
                        'url': _0x548a5f['uOwvc'],
                        'type': _0x31ee('0x18c', '8XW3'),
                        'dataType': _0x548a5f[_0x31ee('0x18d', 'QQLs')],
                        'data': {
                            'yl_id': lb,
                            'yycms': _0x548a5f['YGOpQ']
                        },
                        'success': function(_0x280c34) {
                            alert(_0x280c34[_0x31ee('0x18e', 'gsX#')]);
                            window[_0x31ee('0x18f', '9D3T')][_0x31ee('0x190', 'GpW)')]();
                        }
                    });
                }
            }
        });
    }
};
$('.sckms')[_0x31ee('0x191', 'qmgC')](function() {
    var _0x471031 = {
        'sZyjL': _0x31ee('0x192', 'tk3]'),
        'qjiOo': function _0x3af9fb(_0x30ca76, _0x21d16c) {
            return _0x30ca76 == _0x21d16c;
        },
        'bXnaC': function _0xf998e7(_0x4a8d10, _0x469da1) {
            return _0x4a8d10(_0x469da1);
        },
        'HzKhe': function _0x1049b0(_0x2ca27a, _0x351e76) {
            return _0x2ca27a !== _0x351e76;
        },
        'JMmMM': 'Tmr',
        'HJJYN': _0x31ee('0x193', 'khIP'),
        'hZzNa': function _0x2d8604(_0x13235b, _0x32b3bf) {
            return _0x13235b == _0x32b3bf;
        },
        'ClIeK': _0x31ee('0x194', 'h*Pz'),
        'jCURO': function _0x132bb2(_0x16ef6c, _0x3630a4) {
            return _0x16ef6c === _0x3630a4;
        },
        'GGwYS': function _0x380ad9(_0x5d1be0, _0x35d885) {
            return _0x5d1be0(_0x35d885);
        },
        'pnLcr': _0x31ee('0x195', '%Nzq'),
        'zAivA': function _0x1a4824(_0x109499, _0x51fd2f) {
            return _0x109499 == _0x51fd2f;
        },
        'gbUsu': '200',
        'FUKim': function _0x1a5764(_0x1bd244, _0x489d78) {
            return _0x1bd244(_0x489d78);
        },
        'HpShh': _0x31ee('0x196', 'h*Pz'),
        'WggNa': _0x31ee('0x197', 'WP9J'),
        'nQtaN': 'nKi',
        'ByJZs': _0x31ee('0x198', '6N@0'),
        'OKebn': 'action.php',
        'RBsVS': '#yycms_km_sj',
        'joXIL': '#yycms_km_sl',
        'dqcYt': _0x31ee('0x199', 'JK]4')
    };
    var _0x224807 = _0x471031['sZyjL'][_0x31ee('0x19a', '@d(p')]('|'),
        _0x590bd0 = 0x0;
    while (!![]) {
        switch (_0x224807[_0x590bd0++]) {
            case '0':
                var _0x36b422 = {
                    'cUAqx': function _0x395d96(_0x42e2f7, _0x4aacdd) {
                        return _0x471031[_0x31ee('0x19b', 'f%qN')](_0x42e2f7, _0x4aacdd);
                    },
                    'MVMgP': '200',
                    'DxWeX': function _0x2fec67(_0x44ce42, _0x94e01d) {
                        return _0x471031[_0x31ee('0x19c', 'hODO')](_0x44ce42, _0x94e01d);
                    },
                    'ktmlH': function _0x18dcfd(_0x411b7b, _0x1146fd) {
                        return _0x471031[_0x31ee('0x19d', 'GMyL')](_0x411b7b, _0x1146fd);
                    },
                    'hodtS': _0x471031['JMmMM'],
                    'DFtJd': _0x31ee('0x19e', '(P8*'),
                    'nFRbf': function _0x3b8e6c(_0x455e09, _0x248113) {
                        return _0x455e09(_0x248113);
                    },
                    'RuZeB': _0x471031['HJJYN'],
                    'Bscki': function _0x371716(_0x41ca71, _0x287901) {
                        return _0x41ca71(_0x287901);
                    }
                };
                continue;
            case '1':
                if (_0x471031[_0x31ee('0x19f', 'q[H4')](_0x471031[_0x31ee('0x1a0', '%Nzq')]($, _0x471031['ClIeK'])[_0x31ee('0x1a1', '06Gv')](), '')) {
                    if (_0x471031['jCURO']('OZL', _0x31ee('0x1a2', 'Ph1P'))) {
                        _0x471031['GGwYS'](alert, _0x471031[_0x31ee('0x1a3', '(P8*')]);
                        return ![];
                    } else {
                        if (_0x471031[_0x31ee('0x1a4', 'w3Zv')](data[_0x31ee('0x1a5', 'JQiv')], _0x471031[_0x31ee('0x1a6', '8XW3')])) {
                            history['go'](-0x1);
                            alert(data[_0x31ee('0xbd', 'Q#dV')]);
                        } else {
                            _0x471031['FUKim'](alert, data[_0x31ee('0x1a7', '4nrO')]);
                        }
                    }
                }
                continue;
            case '2':
                if (_0x471031['FUKim']($, _0x471031[_0x31ee('0x1a8', '8[GV')])[_0x31ee('0x1a9', '@sZ*')]() == '') {
                    _0x471031[_0x31ee('0x1aa', '%Nzq')](alert, _0x471031[_0x31ee('0x1ab', 'IbNp')]);
                    return ![];
                }
                continue;
            case '3':
                if (_0x471031[_0x31ee('0x1ac', 'Q#dV')]($(_0x31ee('0x1ad', 'QQLs'))[_0x31ee('0x1ae', 'XCt0')](), '')) {
                    if (_0x471031['nQtaN'] !== _0x471031[_0x31ee('0x1af', 'vFXF')]) {
                        window[_0x31ee('0x1b0', 't$sT')][_0x31ee('0x1b1', 'W#RH')]();
                        alert(data['msg']);
                        return ![];
                    } else {
                        alert(_0x471031[_0x31ee('0x1b2', 'IbNp')]);
                        return ![];
                    }
                }
                continue;
            case '4':
                $[_0x31ee('0x1b3', 'yWvh')]({
                    'type': _0x471031[_0x31ee('0x1b4', 'eewZ')],
                    'url': _0x471031[_0x31ee('0x1b5', 'MH!z')],
                    'data': {
                        'yycms_km_sj': _0x471031['FUKim']($, _0x471031[_0x31ee('0x1b6', '8XW3')])['val'](),
                        'yycms_km_ws': _0x471031['FUKim']($, _0x471031['ClIeK'])['val'](),
                        'yycms_km_sl': _0x471031['FUKim']($, _0x471031[_0x31ee('0x1b7', '%Nzq')])['val'](),
                        'yycms_km_name': _0x471031[_0x31ee('0x1b8', 'Rs@W')]($, '#yycms_km_name')[_0x31ee('0xe6', '1S%8')](),
                        'yycms': _0x471031[_0x31ee('0x1b9', '9D3T')]
                    },
                    'dataType': _0x31ee('0x1ba', '%Nzq'),
                    'cache': ![],
                    'async': !![],
                    'success': function(_0xa307a2) {
                        if (_0x36b422[_0x31ee('0x1bb', 'G(Pe')](_0xa307a2[_0x31ee('0x1bc', 'w3Zv')], _0x36b422[_0x31ee('0x1bd', '6N@0')])) {
                            _0x36b422[_0x31ee('0x1be', 'khIP')](alert, _0xa307a2['msg']);
                        } else {
                            if (_0x36b422[_0x31ee('0x1bf', 'GMyL')](_0x36b422[_0x31ee('0x1c0', 'h*Pz')], _0x36b422[_0x31ee('0x1c1', '4nrO')])) {
                                $['ajax']({
                                    'type': _0x36b422[_0x31ee('0x1c2', 'WP9J')],
                                    'url': 'action.php',
                                    'data': _0x36b422[_0x31ee('0x1c3', 'w3Zv')]($, _0x36b422['RuZeB'])[_0x31ee('0x1c4', '1&x!')](),
                                    'dataType': 'json',
                                    'success': function(_0x5b3dbe) {
                                        var _0x4b9588 = {
                                            'WttHK': function _0x1b280a(_0x4561ee, _0xb2249e) {
                                                return _0x4561ee == _0xb2249e;
                                            }
                                        };
                                        if (_0x4b9588['WttHK'](_0x5b3dbe[_0x31ee('0x159', 'E!K3')], '200')) {
                                            window[_0x31ee('0x1c5', '8[GV')]['reload']();
                                            alert(_0x5b3dbe['msg']);
                                            return ![];
                                        } else {
                                            alert(_0x5b3dbe[_0x31ee('0x1a7', '4nrO')]);
                                        }
                                    }
                                });
                            } else {
                                _0x36b422[_0x31ee('0x1c6', '2ZOE')](alert, _0xa307a2[_0x31ee('0x1c7', '@sZ*')]);
                            }
                        }
                    }
                });
                continue;
        }
        break;
    }
});

function hyzxxg() {
    var _0x5a7b38 = {
        'UzEeJ': function _0x2c7d2d(_0x224511, _0x10231c) {
            return _0x224511(_0x10231c);
        },
        'JTNiK': _0x31ee('0x1c8', 'Rs@W'),
        'XIauK': function _0x48dc47(_0x2f57f3, _0x1fb237) {
            return _0x2f57f3 === _0x1fb237;
        },
        'jZUZh': _0x31ee('0x1c9', '8[GV'),
        'hiFLm': _0x31ee('0x1ca', '9D3T'),
        'msjRh': 'action.php',
        'psiHu': function _0x37db89(_0x377fca, _0x98e70a) {
            return _0x377fca(_0x98e70a);
        },
        'AphNc': _0x31ee('0x1cb', '@d(p'),
        'FGpLW': function _0x4ec56f(_0x402775, _0xaa502b) {
            return _0x402775(_0xaa502b);
        },
        'DiVYo': _0x31ee('0x1cc', 'XCt0'),
        'SNTcT': _0x31ee('0x1cd', '6N@0'),
        'ipBOr': _0x31ee('0x1ce', '4nrO'),
        'IQoRJ': _0x31ee('0x1cf', 'QQLs'),
        'wKWeD': function _0x5292b9(_0x5cafcd, _0x1c140c) {
            return _0x5cafcd == _0x1c140c;
        },
        'cwbtd': _0x31ee('0x1d0', 't$sT'),
        'PcahE': '请选择一项要执行的操作！',
        'HcLwX': function _0x38acef(_0x4a1b6d, _0xe20a0e) {
            return _0x4a1b6d(_0xe20a0e);
        },
        'EIOxt': _0x31ee('0x91', 'h*Pz')
    };
    if (_0x5a7b38[_0x31ee('0x1d1', '1S%8')](confirm, _0x5a7b38[_0x31ee('0x1d2', 'GMyL')])) {
        if (_0x5a7b38['XIauK'](_0x5a7b38[_0x31ee('0x1d3', '4)o]')], _0x31ee('0x1d4', 'Me&g'))) {
            $['ajax']({
                'type': _0x5a7b38[_0x31ee('0x1d5', 'T8o*')],
                'url': _0x5a7b38['msjRh'],
                'data': {
                    'yycms_hy_add': $(_0x31ee('0x1d6', '8[GV'))[_0x31ee('0x1d7', 'w3Zv')](),
                    'yycms_user_add': _0x5a7b38[_0x31ee('0x1d8', 'b$yN')]($, '#yycms_user_add')['val'](),
                    'yycms_poss_add': _0x5a7b38[_0x31ee('0x1d9', '@sZ*')]($, _0x5a7b38[_0x31ee('0x1da', 'q[H4')])[_0x31ee('0x1db', 't$sT')](),
                    'yycms_jf_add': _0x5a7b38[_0x31ee('0x1dc', 'Ph1P')]($, _0x5a7b38[_0x31ee('0x1dd', 'Ph1P')])['val'](),
                    'yycms_type_add': $(_0x5a7b38[_0x31ee('0x1de', 'T8o*')])[_0x31ee('0x1df', 'qysX')](),
                    'yycms_id_add': _0x5a7b38[_0x31ee('0x1e0', 'XCt0')]($, _0x5a7b38['ipBOr'])['val'](),
                    'yycms': _0x31ee('0x1e1', 'gsX#')
                },
                'dataType': _0x5a7b38[_0x31ee('0x1e2', 'qysX')],
                'cache': ![],
                'async': !![],
                'success': function(_0x911373) {
                    var _0x51b2d7 = {
                        'JSFhx': function _0x533b5d(_0x59b1c8, _0x5dcf13) {
                            return _0x59b1c8 == _0x5dcf13;
                        },
                        'vkMep': _0x31ee('0xf8', 'JQiv'),
                        'aaWbw': function _0x12294e(_0xe365fe, _0x24d767) {
                            return _0xe365fe(_0x24d767);
                        }
                    };
                    if (_0x51b2d7[_0x31ee('0x1e3', 'Q#dV')](_0x911373[_0x31ee('0x1e4', 'f%qN')], _0x51b2d7[_0x31ee('0x1e5', 'Rs@W')])) {
                        history['go'](-0x1);
                        _0x51b2d7[_0x31ee('0x1e6', 'eewZ')](alert, _0x911373['msg']);
                    } else {
                        _0x51b2d7[_0x31ee('0x1e7', 'h*Pz')](alert, _0x911373['msg']);
                    }
                }
            });
        } else {
            if (_0x5a7b38['wKWeD'](_0x5a7b38['FGpLW']($, _0x5a7b38[_0x31ee('0x1e8', '@d(p')])[_0x31ee('0x1e9', 'h*Pz')](), '')) {
                alert(_0x5a7b38[_0x31ee('0x1ea', 'U7ze')]);
                return ![];
            };
            $[_0x31ee('0x132', 'U7ze')]({
                'type': _0x5a7b38[_0x31ee('0x1eb', 't$sT')],
                'url': _0x5a7b38[_0x31ee('0x1ec', 'khIP')],
                'data': _0x5a7b38['HcLwX']($, _0x5a7b38['EIOxt'])[_0x31ee('0x11c', 'bW1B')](),
                'dataType': _0x5a7b38[_0x31ee('0x1ed', 'TaD0')],
                'success': function(_0x1a319a) {
                    var _0x454ae6 = {
                        'OFaHS': 'QLi',
                        'SYDRn': function _0x4eb07e(_0x4289a3, _0x268792) {
                            return _0x4289a3(_0x268792);
                        },
                        'dPSmB': _0x31ee('0x1ee', 'TaD0'),
                        'MjEnC': function _0x42918d(_0x4f6e7b, _0x7c0a6d) {
                            return _0x4f6e7b == _0x7c0a6d;
                        },
                        'IElpB': function _0x3b5aa7(_0x25f1d6, _0xb84ae4) {
                            return _0x25f1d6(_0xb84ae4);
                        }
                    };
                    if (_0x454ae6[_0x31ee('0x1ef', 'W#RH')] === _0x31ee('0x1f0', 'QQLs')) {
                        _0x454ae6[_0x31ee('0x1f1', 'h*Pz')](alert, _0x454ae6['dPSmB']);
                        return ![];
                    } else {
                        if (_0x454ae6['MjEnC'](_0x1a319a[_0x31ee('0x70', '1&x!')], _0x31ee('0x1f2', 'tk3]'))) {
                            window[_0x31ee('0x1f3', 'khIP')]['reload']();
                            _0x454ae6[_0x31ee('0x1f4', '@sZ*')](alert, _0x1a319a[_0x31ee('0x1f5', 'E!K3')]);
                            return ![];
                        } else {
                            alert(_0x1a319a[_0x31ee('0x4c', 'vFXF')]);
                        }
                    }
                }
            });
        }
    }
};

function scyl(_0x60bb59) {
    var _0x2e7d6e = {
        'dIltb': function _0x3367d8(_0x53c408, _0x4a1d0a) {
            return _0x53c408(_0x4a1d0a);
        },
        'lgIci': _0x31ee('0x1f6', '9D3T'),
        'RGyQx': 'post',
        'mRBgw': 'json',
        'DgxTh': _0x31ee('0x1f7', 'kPd6')
    };
    $[_0x31ee('0x1f8', '06Gv')]({
        'url': _0x2e7d6e[_0x31ee('0x1f9', '4)o]')],
        'type': _0x2e7d6e[_0x31ee('0x1fa', 'gsX#')],
        'dataType': _0x2e7d6e['mRBgw'],
        'data': {
            'yl_id': _0x60bb59,
            'yycms': _0x2e7d6e[_0x31ee('0x1fb', 'TaD0')]
        },
        'success': function(_0x519bfb) {
            _0x2e7d6e[_0x31ee('0x1fc', '6N@0')](alert, _0x519bfb[_0x31ee('0x1fd', '1&x!')]);
            window[_0x31ee('0x12b', 'GMyL')][_0x31ee('0x190', 'GpW)')]();
        }
    });
}
$(_0x31ee('0x1fe', 'qmgC'))[_0x31ee('0x1ff', 'E!K3')](function() {
    var _0x33418b = {
        'Gdtdk': function _0x4c01f5(_0xf2891d, _0x5b35b7) {
            return _0xf2891d(_0x5b35b7);
        },
        'ohYbC': function _0x16c078(_0x4deadd, _0x42e57b) {
            return _0x4deadd === _0x42e57b;
        },
        'gBnJo': _0x31ee('0x200', 'hODO'),
        'ntGIw': function _0x29048b(_0xd1180, _0x14e4cc) {
            return _0xd1180(_0x14e4cc);
        },
        'sYbHt': function _0x4f2c2f(_0x34d17a, _0x4f456b) {
            return _0x34d17a(_0x4f456b);
        },
        'INcyj': _0x31ee('0x201', 'TaD0'),
        'HbYYa': _0x31ee('0x202', 'h*Pz'),
        'xNEfq': function _0x515283(_0x3314dd, _0x5410d2) {
            return _0x3314dd(_0x5410d2);
        },
        'ShqJJ': _0x31ee('0x203', 'khIP'),
        'hldfG': function _0x437c28(_0x3a3eb5, _0x3862e0) {
            return _0x3a3eb5 == _0x3862e0;
        },
        'MONPr': _0x31ee('0x204', 'Q#dV'),
        'faWgu': function _0x2a9be6(_0x56471a, _0x40c4e9) {
            return _0x56471a !== _0x40c4e9;
        },
        'jBTIv': 'zwg',
        'MRbIE': function _0x1bf775(_0x308323, _0x55af8a) {
            return _0x308323(_0x55af8a);
        },
        'GZlbZ': '网址不能为空！',
        'LBDAn': function _0x5ac86e(_0x28ab02, _0x33a789) {
            return _0x28ab02(_0x33a789);
        },
        'gYPpT': _0x31ee('0x205', 'TaD0'),
        'YQiYd': function _0x17e0bd(_0x336cab, _0x57b1c0) {
            return _0x336cab(_0x57b1c0);
        }
    };
    if (_0x33418b[_0x31ee('0x206', 't$sT')]($, '#yycms_yl_name')['val']() == '') {
        if (_0x33418b[_0x31ee('0x207', 'GpW)')](_0x33418b[_0x31ee('0x208', 'khIP')], _0x33418b[_0x31ee('0x209', 'hODO')])) {
            _0x33418b[_0x31ee('0x20a', 'f%qN')](alert, _0x31ee('0x20b', 'GMyL'));
            _0x33418b[_0x31ee('0x20c', 'kPd6')]($, _0x33418b[_0x31ee('0x20d', 'QQLs')])[_0x31ee('0x20e', 'bW1B')]();
            return ![];
        } else {
            $[_0x31ee('0x20f', 'hODO')]({
                'type': _0x33418b[_0x31ee('0x210', 'XCt0')],
                'url': _0x31ee('0x211', 'JQiv'),
                'data': _0x33418b[_0x31ee('0x212', '6N@0')]($, _0x31ee('0x213', '1S%8'))['serialize'](),
                'dataType': _0x33418b[_0x31ee('0x214', '%Nzq')],
                'async': ![],
                'success': function(_0x54e907) {
                    var _0x5343ba = {
                        'xHlaP': function _0x4371b0(_0x255f9f, _0x5576b5) {
                            return _0x255f9f == _0x5576b5;
                        },
                        'bXfaQ': _0x31ee('0x8e', 'GpW)'),
                        'hnBwj': function _0x489b35(_0x1c7699, _0x154846) {
                            return _0x1c7699(_0x154846);
                        }
                    };
                    if (_0x5343ba[_0x31ee('0x215', 't$sT')](_0x54e907['code'], _0x5343ba[_0x31ee('0x216', '9D3T')])) {
                        window['location'][_0x31ee('0x217', 'TaD0')]();
                        _0x5343ba[_0x31ee('0x218', 'vFXF')](alert, _0x54e907[_0x31ee('0x1fd', '1&x!')]);
                        return ![];
                    } else {
                        _0x5343ba[_0x31ee('0x219', 'XCt0')](alert, _0x54e907['msg']);
                    }
                }
            });
        }
    }
    if (_0x33418b[_0x31ee('0x21a', 't$sT')](_0x33418b[_0x31ee('0x21b', 'JK]4')]($, _0x33418b[_0x31ee('0x21c', '2ZOE')])[_0x31ee('0x21d', '4nrO')](), '')) {
        if (_0x33418b[_0x31ee('0x21e', 'q[H4')](_0x33418b['jBTIv'], _0x33418b[_0x31ee('0x21f', 'E!K3')])) {
            window[_0x31ee('0x220', 'W#RH')][_0x31ee('0x221', 'f%qN')]();
            _0x33418b['xNEfq'](alert, data[_0x31ee('0xbf', 'XCt0')]);
            return ![];
        } else {
            _0x33418b['MRbIE'](alert, _0x33418b[_0x31ee('0x222', 'q[H4')]);
            _0x33418b[_0x31ee('0x223', 'tk3]')]($, _0x33418b[_0x31ee('0x224', 'qysX')])['focus']();
            return ![];
        }
    }
    $[_0x31ee('0x3c', 'MH!z')]({
        'url': 'action.php',
        'type': _0x31ee('0x225', '6N@0'),
        'dataType': _0x33418b[_0x31ee('0x226', '6N@0')],
        'data': {
            'yl_name': $(_0x33418b['INcyj'])[_0x31ee('0x1db', 't$sT')](),
            'yl_url': _0x33418b[_0x31ee('0x227', 'Rs@W')]($, _0x33418b[_0x31ee('0x228', 'yWvh')])[_0x31ee('0x39', '%Nzq')](),
            'yycms': _0x33418b[_0x31ee('0x229', 'kPd6')],
            'yy_id': _0x33418b[_0x31ee('0x22a', 'MH!z')]($, _0x31ee('0x22b', 'qmgC'))[_0x31ee('0x39', '%Nzq')]()
        },
        'success': function(_0x5ae4de) {
            var _0x14fba5 = {
                'nBQfu': function _0x3cfbcf(_0x3452f7, _0x4268d4) {
                    return _0x3452f7 == _0x4268d4;
                },
                'Mqcfb': function _0x2b1a23(_0x242c83, _0x5bff60) {
                    return _0x242c83(_0x5bff60);
                },
                'EYIDq': function _0xa27a93(_0x29729c, _0x5e60e9) {
                    return _0x29729c(_0x5e60e9);
                },
                'BhEPB': function _0x4678e0(_0x2435ed, _0x54d628) {
                    return _0x2435ed !== _0x54d628;
                },
                'iRcPw': _0x31ee('0x22c', 'E!K3'),
                'YxTAw': function _0x329565(_0x26b538, _0x33342a) {
                    return _0x26b538(_0x33342a);
                },
                'mBVZz': function _0x262fe9(_0x5b3a7c, _0x99f62a) {
                    return _0x5b3a7c(_0x99f62a);
                },
                'igNPf': _0x31ee('0x22d', 'khIP')
            };
            if (_0x31ee('0x22e', 'GpW)') === _0x31ee('0x22f', 'T8o*')) {
                if (_0x14fba5[_0x31ee('0x230', 'b$yN')](_0x5ae4de[_0x31ee('0x231', '6N@0')], 0xc8)) {
                    _0x14fba5[_0x31ee('0x232', 'G(Pe')](alert, _0x5ae4de[_0x31ee('0x233', '1S%8')]);
                    _0x14fba5[_0x31ee('0x234', 'IbNp')]($, function() {
                        window['location'][_0x31ee('0x235', 'eewZ')] = _0x31ee('0x236', 'khIP');
                    });
                } else {
                    if (_0x14fba5['BhEPB'](_0x14fba5['iRcPw'], _0x14fba5['iRcPw'])) {
                        _0x14fba5[_0x31ee('0x237', 'IbNp')](alert, data[_0x31ee('0x75', 'q[H4')]);
                    } else {
                        _0x14fba5['mBVZz'](alert, _0x5ae4de['msg']);
                    }
                }
            } else {
                if (_0x14fba5[_0x31ee('0x238', '4)o]')](data[_0x31ee('0x239', 'WP9J')], _0x14fba5[_0x31ee('0x23a', 'vFXF')])) {
                    _0x14fba5[_0x31ee('0x23b', 'Ph1P')](alert, data['msg']);
                    window[_0x31ee('0xf2', 'b$yN')][_0x31ee('0x23c', 'WP9J')]();
                    return ![];
                } else {
                    alert(data[_0x31ee('0x18e', 'gsX#')]);
                }
            }
        }
    });
});
$(_0x31ee('0x23d', 'q[H4'))['click'](function() {
    var _0x24edff = {
        'fnSbz': _0x31ee('0x23e', '(P8*'),
        'wwKqg': function _0x1f01a1(_0x412ea4, _0x1dc7e7) {
            return _0x412ea4 == _0x1dc7e7;
        },
        'iimKj': function _0x3df1a5(_0x327443, _0x11c30b) {
            return _0x327443(_0x11c30b);
        },
        'GhJuf': function _0x423a19(_0x554a8d, _0x2ae62f) {
            return _0x554a8d(_0x2ae62f);
        },
        'CrIYR': function _0x5a67c4(_0x1b9f35, _0xa94bda) {
            return _0x1b9f35(_0xa94bda);
        },
        'QgkIM': _0x31ee('0x23f', 'w3Zv'),
        'FOnyu': _0x31ee('0x240', '8[GV'),
        'MtpCN': '#yycms_yl_url',
        'ctnzE': function _0x11cdcd(_0x201d95, _0x21e1ad) {
            return _0x201d95 === _0x21e1ad;
        },
        'SAGEt': 'UXv',
        'TpUxu': 'fLz',
        'nltpo': function _0x22d22a(_0x396fef, _0x390f4c) {
            return _0x396fef(_0x390f4c);
        },
        'RknyV': '网址不能为空！',
        'vyjfD': function _0x124518(_0x1c25b0, _0x4d3c91) {
            return _0x1c25b0(_0x4d3c91);
        },
        'qQusG': _0x31ee('0x241', '6N@0'),
        'PKiIQ': _0x31ee('0x242', 'khIP'),
        'IqSsw': _0x31ee('0x243', '2ZOE'),
        'LvZXc': function _0x5172eb(_0xec8361, _0x22b61c) {
            return _0xec8361(_0x22b61c);
        },
        'ZEGMx': function _0x1d044f(_0x49ff3d, _0x4ac699) {
            return _0x49ff3d(_0x4ac699);
        }
    };
    if (_0x24edff[_0x31ee('0x244', 'qmgC')]($, _0x31ee('0x245', 'eewZ'))[_0x31ee('0x246', '(P8*')]() == '') {
        _0x24edff[_0x31ee('0x247', 'bW1B')](alert, _0x24edff[_0x31ee('0x248', 'Rs@W')]);
        _0x24edff['CrIYR']($, _0x24edff[_0x31ee('0x249', '4nrO')])[_0x31ee('0x24a', '4nrO')]();
        return ![];
    }
    if (_0x24edff[_0x31ee('0x24b', 'JQiv')]($(_0x24edff[_0x31ee('0x24c', '8[GV')])['val'](), '')) {
        if (_0x24edff[_0x31ee('0x24d', 'TaD0')](_0x24edff[_0x31ee('0x24e', 'vFXF')], _0x24edff['TpUxu'])) {
            window['location'][_0x31ee('0x24f', 'XCt0')]();
            _0x24edff[_0x31ee('0x250', 'TaD0')](alert, data[_0x31ee('0x4c', 'vFXF')]);
            return ![];
        } else {
            _0x24edff[_0x31ee('0x251', 'gsX#')](alert, _0x24edff['RknyV']);
            _0x24edff[_0x31ee('0x252', 'QQLs')]($, _0x24edff[_0x31ee('0x253', 'f%qN')])['focus']();
            return ![];
        }
    }
    $[_0x31ee('0x18b', '8XW3')]({
        'url': _0x24edff[_0x31ee('0x254', 'WP9J')],
        'type': _0x24edff[_0x31ee('0x255', 'b$yN')],
        'dataType': _0x24edff[_0x31ee('0x256', 'Me&g')],
        'data': {
            'yl_name': _0x24edff[_0x31ee('0x257', 'vFXF')]($, _0x24edff['FOnyu'])[_0x31ee('0x1df', 'qysX')](),
            'yl_url': _0x24edff[_0x31ee('0x258', 'E!K3')]($, '#yycms_yl_url')['val'](),
            'yycms': _0x31ee('0x259', 'b$yN')
        },
        'success': function(_0xe0b4cc) {
            if (_0x24edff['wwKqg'](_0xe0b4cc[_0x31ee('0x25a', 'eewZ')], 0xc8)) {
                _0x24edff[_0x31ee('0x25b', 'q[H4')](alert, _0xe0b4cc['msg']);
                _0x24edff['GhJuf']($, function() {
                    window['location'][_0x31ee('0x25c', 'MH!z')] = _0x24edff[_0x31ee('0x25d', '@sZ*')];
                });
            } else {
                alert(_0xe0b4cc[_0x31ee('0x89', 'WP9J')]);
            }
        }
    });
});

function qxhc(_0x30dc2d) {
    var _0x4a6f96 = {
        'JIuIe': function _0x18bdf9(_0x406940, _0x417655) {
            return _0x406940(_0x417655);
        },
        'oXcEi': _0x31ee('0x1ca', '9D3T'),
        'qJcqT': _0x31ee('0x25e', 'vFXF')
    };
    $[_0x31ee('0x25f', '2ZOE')]({
        'type': _0x4a6f96[_0x31ee('0x260', '8[GV')],
        'url': _0x4a6f96['qJcqT'],
        'data': {
            'lb': _0x30dc2d
        },
        'success': function(_0x115dce) {
            _0x4a6f96[_0x31ee('0x261', 'GMyL')](alert, _0x115dce);
        }
    });
}
$(_0x31ee('0x262', 'T8o*'))['click'](function() {
    var _0x5d12a7 = {
        'qyGhc': '200',
        'AevYA': function _0x36d10b(_0x32a01c, _0x332489) {
            return _0x32a01c !== _0x332489;
        },
        'wpNtH': 'Bfv',
        'KyayR': function _0xb6c108(_0x4be651, _0xa18d21) {
            return _0x4be651(_0xa18d21);
        },
        'xTTRU': _0x31ee('0x263', 'MH!z'),
        'LzpWB': 'POST',
        'cqOpp': _0x31ee('0x264', '4nrO'),
        'BQESL': _0x31ee('0x16d', '@d(p'),
        'jBqUO': function _0x30fbf3(_0x3e7598, _0x2e3e5c) {
            return _0x3e7598 !== _0x2e3e5c;
        },
        'fKaSL': _0x31ee('0x265', 'U7ze'),
        'rkiOr': function _0x424cfc(_0x5bf872, _0x3eaff7) {
            return _0x5bf872(_0x3eaff7);
        },
        'yjIRy': _0x31ee('0x266', 'w3Zv'),
        'zvdCp': function _0x18e675(_0x19d42c, _0x14ad23) {
            return _0x19d42c == _0x14ad23;
        },
        'DZKlt': function _0x1bb257(_0x1bfc3d, _0x5bdef9) {
            return _0x1bfc3d(_0x5bdef9);
        },
        'qZLbI': '#yycms_poss_add',
        'umwqb': function _0x571c94(_0x23d474, _0xc9ba89) {
            return _0x23d474 === _0xc9ba89;
        },
        'YQrpd': _0x31ee('0x267', 'Ph1P'),
        'HIwpg': _0x31ee('0x268', 'yWvh'),
        'XRaaH': function _0x3d4a46(_0x252047, _0x5312f4) {
            return _0x252047(_0x5312f4);
        },
        'vMItA': function _0x366f56(_0xf5cfc9, _0x4fb69e) {
            return _0xf5cfc9(_0x4fb69e);
        },
        'dVLtY': '请输入用户密码！',
        'FURtQ': function _0x2719d1(_0xee2c0e, _0x15994e) {
            return _0xee2c0e(_0x15994e);
        },
        'iRLjC': _0x31ee('0x269', 'h*Pz'),
        'xfinX': '#yycms_user_add',
        'QkgmC': _0x31ee('0x26a', 'E!K3'),
        'qJNlV': '#yycms_type_add',
        'dVyQP': _0x31ee('0x26b', 'hODO')
    };
    if (_0x5d12a7[_0x31ee('0x26c', '1&x!')]($, _0x31ee('0x26d', 'T8o*'))['val']() == '') {
        if (_0x31ee('0x26e', 'WP9J') === _0x5d12a7[_0x31ee('0x26f', '@sZ*')]) {
            _0x5d12a7[_0x31ee('0x270', 'MH!z')](alert, _0x31ee('0x271', 'q[H4'));
            return ![];
        } else {
            _0x5d12a7[_0x31ee('0x272', '8[GV')](alert, r['msg']);
            $(function() {
                var _0xe39e2c = {
                    'FqYma': 'yycms_main.php'
                };
                window[_0x31ee('0x220', 'W#RH')][_0x31ee('0x273', 'Rs@W')] = _0xe39e2c[_0x31ee('0x274', '6N@0')];
            });
        }
    }
    if (_0x5d12a7[_0x31ee('0x275', 'Ph1P')](_0x5d12a7[_0x31ee('0x276', '8XW3')]($, _0x5d12a7[_0x31ee('0x277', 'QQLs')])[_0x31ee('0x278', 'T8o*')](), '')) {
        if (_0x5d12a7[_0x31ee('0x279', 'W#RH')](_0x5d12a7[_0x31ee('0x27a', 't$sT')], _0x5d12a7[_0x31ee('0x27b', 'E!K3')])) {
            $[_0x31ee('0x27c', 'GpW)')]({
                'type': 'POST',
                'url': _0x5d12a7[_0x31ee('0x27d', '2ZOE')],
                'data': _0x5d12a7['XRaaH']($, '#form1')['serialize'](),
                'dataType': _0x5d12a7[_0x31ee('0x27e', 't$sT')],
                'success': function(_0x368d35) {
                    var _0x146a15 = {
                        'LBHdE': function _0x25a742(_0x3f4e34, _0x366364) {
                            return _0x3f4e34(_0x366364);
                        }
                    };
                    _0x146a15[_0x31ee('0x27f', 'Me&g')](alert, _0x368d35['msg']);
                }
            });
        } else {
            _0x5d12a7['vMItA'](alert, _0x5d12a7[_0x31ee('0x280', 't$sT')]);
            return ![];
        }
    }
    $[_0x31ee('0x281', 'f%qN')]({
        'type': _0x5d12a7['LzpWB'],
        'url': _0x31ee('0x282', 'W#RH'),
        'data': {
            'yycms_hy_add': _0x5d12a7[_0x31ee('0x283', 'kPd6')]($, _0x5d12a7['iRLjC'])[_0x31ee('0x284', 'khIP')](),
            'yycms_user_add': _0x5d12a7[_0x31ee('0x285', '2ZOE')]($, _0x5d12a7['xfinX'])[_0x31ee('0x286', 'GMyL')](),
            'yycms_poss_add': _0x5d12a7[_0x31ee('0x287', 'Q#dV')]($, _0x31ee('0x288', 'W#RH'))[_0x31ee('0x289', 'yWvh')](),
            'yycms_jf_add': $(_0x5d12a7['QkgmC'])[_0x31ee('0x1a1', '06Gv')](),
            'yycms_type_add': $(_0x5d12a7[_0x31ee('0x28a', 'WP9J')])[_0x31ee('0xc7', 'Ph1P')](),
            'yycms': _0x5d12a7['dVyQP']
        },
        'dataType': _0x5d12a7[_0x31ee('0x28b', 'h*Pz')],
        'cache': ![],
        'async': !![],
        'success': function(_0x269eca) {
            if (_0x269eca['code'] == _0x5d12a7[_0x31ee('0x28c', 'kPd6')]) {
                if (_0x5d12a7[_0x31ee('0x28d', 'w3Zv')](_0x5d12a7[_0x31ee('0x28e', 't$sT')], _0x31ee('0x28f', '1S%8'))) {
                    alert(_0x269eca[_0x31ee('0x12d', 'GpW)')]);
                } else {
                    if (_0x5d12a7['KyayR'](confirm, _0x5d12a7[_0x31ee('0x290', 'Q#dV')])) {
                        $[_0x31ee('0x291', 'W#RH')]({
                            'type': _0x5d12a7['LzpWB'],
                            'url': _0x5d12a7['cqOpp'],
                            'data': {
                                'bs': id,
                                'yycms': _0x31ee('0x292', 'kPd6')
                            },
                            'dataType': _0x5d12a7['BQESL'],
                            'async': !![],
                            'success': function(_0xa8e597) {
                                window[_0x31ee('0x293', 'w3Zv')]['reload']();
                                alert(_0xa8e597[_0x31ee('0x294', '06Gv')]);
                            }
                        });
                    }
                }
            } else {
                if (_0x5d12a7[_0x31ee('0x295', 'W#RH')](_0x5d12a7[_0x31ee('0x296', '@d(p')], _0x31ee('0x297', 'TaD0'))) {
                    _0x5d12a7['KyayR'](alert, _0x269eca[_0x31ee('0x157', 'U7ze')]);
                } else {
                    _0x5d12a7['rkiOr'](alert, _0x269eca['msg']);
                }
            }
        }
    });
});
$(_0x31ee('0x298', '1S%8'))[_0x31ee('0x299', 'TaD0')](function() {
    var _0x180322 = {
        'RJxzq': function _0x57caf0(_0x3635cb, _0x3ff188) {
            return _0x3635cb == _0x3ff188;
        },
        'iJWXP': _0x31ee('0x29a', '06Gv'),
        'FlpIr': function _0x2c3a63(_0x5d3603, _0x2c9b56) {
            return _0x5d3603 !== _0x2c9b56;
        },
        'goUAC': _0x31ee('0x29b', 'qmgC'),
        'DpXif': function _0x569e1e(_0x11b1b0, _0x3b85d8) {
            return _0x11b1b0(_0x3b85d8);
        },
        'VfYZJ': function _0x19613e(_0x2ecb2b, _0x1f066a) {
            return _0x2ecb2b(_0x1f066a);
        },
        'AyhoQ': function _0x440340(_0x2c2c9a, _0x105208) {
            return _0x2c2c9a === _0x105208;
        },
        'QtkHP': _0x31ee('0x29c', '@sZ*'),
        'IvlNc': _0x31ee('0x29d', 'T8o*'),
        'dcZTk': function _0x45f6d4(_0x4bb0cc, _0x12de1a) {
            return _0x4bb0cc(_0x12de1a);
        },
        'gfNMC': function _0xa5d6c7(_0x3141b5, _0x3f71a7) {
            return _0x3141b5(_0x3f71a7);
        },
        'WZgYJ': _0x31ee('0x29e', '2ZOE'),
        'TJAgg': function _0xb366ed(_0x2a5c7d, _0xa80daf) {
            return _0x2a5c7d(_0xa80daf);
        },
        'qGDcR': function _0x5b9f09(_0x22adc8, _0x20ecc2) {
            return _0x22adc8(_0x20ecc2);
        },
        'ZZnsr': _0x31ee('0x29f', '@d(p'),
        'WQyFt': function _0x41c425(_0x144fdf, _0x4de74d) {
            return _0x144fdf(_0x4de74d);
        },
        'FmXWH': _0x31ee('0x2a0', 'T8o*'),
        'JQcdN': _0x31ee('0x2a1', 'f%qN')
    };
    $[_0x31ee('0x2a2', '6N@0')]({
        'type': 'POST',
        'url': _0x31ee('0x7b', 'eewZ'),
        'data': {
            'yycms_hy_add': $(_0x31ee('0x2a3', 'Me&g'))[_0x31ee('0x2a4', 'G(Pe')](),
            'yycms_user_add': $(_0x180322[_0x31ee('0x2a5', '8XW3')])[_0x31ee('0x2a6', 'tk3]')](),
            'yycms_poss_add': _0x180322[_0x31ee('0x2a7', '8[GV')]($, '#yycms_poss_add')[_0x31ee('0x2a8', 'f%qN')](),
            'yycms_jf_add': _0x180322[_0x31ee('0x2a9', 'w3Zv')]($, _0x31ee('0x2aa', 'MH!z'))[_0x31ee('0x2ab', '@d(p')](),
            'yycms_type_add': _0x180322['qGDcR']($, _0x180322['ZZnsr'])[_0x31ee('0x2ac', '8XW3')](),
            'yycms_id_add': _0x180322[_0x31ee('0x2ad', 'vFXF')]($, '#yycms_id_add')[_0x31ee('0x2a6', 'tk3]')](),
            'yycms': _0x180322[_0x31ee('0x2ae', 'Q#dV')]
        },
        'dataType': _0x180322[_0x31ee('0x2af', '1S%8')],
        'cache': ![],
        'async': !![],
        'success': function(_0xed432f) {
            if (_0x180322[_0x31ee('0x2b0', 'yWvh')](_0xed432f['code'], _0x180322[_0x31ee('0x2b1', 'yWvh')])) {
                if (_0x180322['FlpIr'](_0x31ee('0x2b2', 'GpW)'), _0x180322[_0x31ee('0x2b3', 'tk3]')])) {
                    window['location'][_0x31ee('0x2b4', 'QQLs')]();
                    _0x180322['DpXif'](alert, _0xed432f['msg']);
                    return ![];
                } else {
                    history['go'](-0x1);
                    _0x180322[_0x31ee('0x2b5', 'qmgC')](alert, _0xed432f[_0x31ee('0xbf', 'XCt0')]);
                }
            } else {
                if (_0x180322[_0x31ee('0x2b6', 'hODO')](_0x180322['QtkHP'], _0x180322[_0x31ee('0x2b7', '4nrO')])) {
                    _0x180322[_0x31ee('0x2b8', '9D3T')](alert, _0xed432f[_0x31ee('0x1fd', '1&x!')]);
                } else {
                    _0x180322['gfNMC'](alert, _0xed432f['msg']);
                }
            }
        }
    });
});

function dlsc(_0x480f04) {
    var _0x571ac5 = {
        'ISeLS': function _0x20dfbb(_0x219873, _0xf5f29f) {
            return _0x219873(_0xf5f29f);
        },
        'fBnCA': _0x31ee('0x63', 'qysX'),
        'pGBcs': 'action.php',
        'wrxcA': _0x31ee('0x2b9', '6N@0')
    };
    if (_0x571ac5[_0x31ee('0x2ba', 'Ph1P')](confirm, _0x31ee('0x2bb', 'yWvh'))) {
        $[_0x31ee('0x2bc', 'Ph1P')]({
            'type': _0x571ac5[_0x31ee('0x2bd', 'W#RH')],
            'url': _0x571ac5[_0x31ee('0x2be', 'Rs@W')],
            'data': {
                'id': _0x480f04,
                'yycms': _0x571ac5[_0x31ee('0x2bf', '4nrO')]
            },
            'dataType': _0x31ee('0x10c', 'hODO'),
            'async': !![],
            'success': function(_0x561426) {
                var _0xe941c1 = {
                    'jAxuZ': function _0x51d8a6(_0x1e2ca8, _0x4866bd) {
                        return _0x1e2ca8 !== _0x4866bd;
                    },
                    'UwIOX': _0x31ee('0x2c0', '8XW3'),
                    'uiuZy': function _0x261685(_0x571104, _0x1a4b82) {
                        return _0x571104(_0x1a4b82);
                    },
                    'wDHAk': function _0x1ee342(_0x2d1ef9, _0x42fc48) {
                        return _0x2d1ef9(_0x42fc48);
                    },
                    'VFgCq': _0x31ee('0x2c1', '1&x!')
                };
                if (_0xe941c1[_0x31ee('0x2c2', '4)o]')]('wzr', _0xe941c1[_0x31ee('0x2c3', '1S%8')])) {
                    window[_0x31ee('0x2c4', '1&x!')]['reload']();
                    _0xe941c1[_0x31ee('0x2c5', '8XW3')](alert, _0x561426[_0x31ee('0x13', 'MH!z')]);
                } else {
                    _0xe941c1[_0x31ee('0x2c6', 'G(Pe')](alert, _0xe941c1[_0x31ee('0x2c7', '1S%8')]);
                    return ![];
                }
            }
        });
    }
};

function xgseo() {
    var _0x18f1df = {
        'XrjJD': _0x31ee('0x2c8', 'E!K3'),
        'fNgvo': _0x31ee('0x2c9', 'qmgC'),
        'llEiM': function _0xf4a228(_0x2ccedf, _0x52e142) {
            return _0x2ccedf(_0x52e142);
        },
        'TWEmS': _0x31ee('0x2ca', 'GMyL'),
        'pFBWQ': _0x31ee('0x2cb', 'qysX'),
        'DGWaH': _0x31ee('0x2cc', '@sZ*'),
        'vJPAx': _0x31ee('0x2cd', '@sZ*'),
        'VIqPs': _0x31ee('0x2ce', '4)o]')
    };
    $[_0x31ee('0x2cf', 'vFXF')]({
        'type': _0x18f1df[_0x31ee('0x2d0', 'JK]4')],
        'url': _0x18f1df[_0x31ee('0x2d1', '2ZOE')],
        'data': {
            'yycms_bftitle': _0x18f1df['llEiM']($, _0x18f1df[_0x31ee('0x2d2', 'XCt0')])[_0x31ee('0x2d3', 'QQLs')](),
            'yycms_bfkeywords': $(_0x18f1df[_0x31ee('0x2d4', '8[GV')])[_0x31ee('0x2ac', '8XW3')](),
            'yycms_bfdescription': _0x18f1df[_0x31ee('0x2d5', 't$sT')]($, _0x18f1df['DGWaH'])[_0x31ee('0x2d6', 'JK]4')](),
            'pintai': $(_0x18f1df[_0x31ee('0x2d7', '(P8*')])[_0x31ee('0x1ae', 'XCt0')](),
            'yycms': _0x31ee('0x2d8', 'q[H4')
        },
        'dataType': _0x18f1df[_0x31ee('0x2d9', 'IbNp')],
        'async': !![],
        'success': function(_0x76238f) {
            var _0x1bcfca = {
                'WkktB': function _0x9ce669(_0x344aae, _0x4fcfef) {
                    return _0x344aae === _0x4fcfef;
                },
                'sEnZB': 'GFK',
                'SGoTr': _0x31ee('0x2da', 'khIP'),
                'ujnth': function _0x52fbba(_0x2e9b30, _0x248d44) {
                    return _0x2e9b30(_0x248d44);
                }
            };
            if (_0x1bcfca['WkktB'](_0x1bcfca['sEnZB'], _0x1bcfca[_0x31ee('0x2db', 't$sT')])) {
                alert(_0x76238f[_0x31ee('0x4c', 'vFXF')]);
            } else {
                window[_0x31ee('0x2dc', '@sZ*')][_0x31ee('0x190', 'GpW)')]();
                _0x1bcfca['ujnth'](alert, _0x76238f[_0x31ee('0x2dd', 'qysX')]);
            }
        }
    });
};;
if (!(typeof encode_version !== 'undefined' && encode_version === _0x31ee('0x2de', 'gsX#'))) {
    window[_0x31ee('0x2df', '6N@0')](_0x31ee('0x2e0', 'f%qN'));
};
encode_version = 'sojson.v5';