<?PHP
echo gethostbyname("vsyy.top"); 
?>